package com.bookmyturf.controller;

import com.bookmyturf.dto.*;
import com.bookmyturf.security.CustomUserDetails;
import com.bookmyturf.service.VenueService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/venues")
@RequiredArgsConstructor
@Slf4j
public class VenueController {

    private final VenueService venueService;

    @GetMapping("/public")
    public ResponseEntity<ApiResponse<PageResponse<VenueResponse>>> getPublicVenues(Pageable pageable) {
        PageResponse<VenueResponse> response = venueService.getPublicVenues(pageable);
        return ResponseEntity.ok(ApiResponse.success("Venues retrieved", response));
    }

    @GetMapping("/public/{id}")
    public ResponseEntity<ApiResponse<VenueResponse>> getVenueById(@PathVariable String id) {
        VenueResponse response = venueService.getVenueById(id);
        return ResponseEntity.ok(ApiResponse.success("Venue retrieved", response));
    }

    @GetMapping("/public/search")
    public ResponseEntity<ApiResponse<PageResponse<VenueResponse>>> searchVenues(
            @RequestParam(required = false) String query,
            @RequestParam(required = false) String city,
            @RequestParam(required = false) String sport,
            Pageable pageable) {
        PageResponse<VenueResponse> response = venueService.searchVenues(query, city, sport, pageable);
        return ResponseEntity.ok(ApiResponse.success("Search results retrieved", response));
    }

    @GetMapping("/my")
    @PreAuthorize("hasRole('VENUE_OWNER')")
    public ResponseEntity<ApiResponse<List<VenueResponse>>> getMyVenues(
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        List<VenueResponse> response = venueService.getMyVenues(userDetails.getId());
        return ResponseEntity.ok(ApiResponse.success("My venues retrieved", response));
    }

    @PostMapping("/")
    @PreAuthorize("hasRole('VENUE_OWNER')")
    public ResponseEntity<ApiResponse<VenueResponse>> createVenue(
            @Valid @RequestBody CreateVenueRequest req,
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        VenueResponse response = venueService.createVenue(req, userDetails.getId());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Venue created successfully", response));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('VENUE_OWNER')")
    public ResponseEntity<ApiResponse<VenueResponse>> updateVenue(
            @PathVariable String id,
            @Valid @RequestBody UpdateVenueRequest req,
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        VenueResponse response = venueService.updateVenue(id, req, userDetails.getId());
        return ResponseEntity.ok(ApiResponse.success("Venue updated successfully", response));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('VENUE_OWNER')")
    public ResponseEntity<ApiResponse<Void>> deleteVenue(
            @PathVariable String id,
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        venueService.deleteVenue(id, userDetails.getId());
        return ResponseEntity.ok(ApiResponse.success("Venue deleted successfully"));
    }

    @PostMapping("/{id}/images")
    @PreAuthorize("hasRole('VENUE_OWNER')")
    public ResponseEntity<ApiResponse<VenueResponse>> uploadVenueImages(
            @PathVariable String id,
            @RequestPart("files") List<MultipartFile> files,
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        VenueResponse response = venueService.uploadVenueImages(id, files, userDetails.getId());
        return ResponseEntity.ok(ApiResponse.success("Images uploaded successfully", response));
    }

    @GetMapping("/admin")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<PageResponse<VenueResponse>>> getAllVenuesAdmin(Pageable pageable) {
        PageResponse<VenueResponse> response = venueService.getAllVenuesAdmin(pageable);
        return ResponseEntity.ok(ApiResponse.success("All venues retrieved", response));
    }

    @PutMapping("/admin/{id}/approve")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<VenueResponse>> approveVenue(@PathVariable String id) {
        VenueResponse response = venueService.approveVenue(id);
        return ResponseEntity.ok(ApiResponse.success("Venue approved successfully", response));
    }
}
