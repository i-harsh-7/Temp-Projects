package com.bookmyturf.service;

import com.bookmyturf.dto.*;
import com.bookmyturf.entity.Booking;
import com.bookmyturf.entity.Turf;
import com.bookmyturf.entity.Venue;
import com.bookmyturf.exception.BadRequestException;
import com.bookmyturf.exception.ConflictException;
import com.bookmyturf.exception.ResourceNotFoundException;
import com.bookmyturf.exception.UnauthorizedException;
import com.bookmyturf.mapper.BookingMapper;
import com.bookmyturf.redis.RedisLockService;
import com.bookmyturf.repository.BookingRepository;
import com.bookmyturf.repository.TurfRepository;
import com.bookmyturf.repository.UserRepository;
import com.bookmyturf.repository.VenueRepository;
import com.bookmyturf.util.BookingUtils;
import com.bookmyturf.util.SecurityUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class BookingService {

    private final BookingRepository bookingRepository;
    private final TurfRepository turfRepository;
    private final VenueRepository venueRepository;
    private final UserRepository userRepository;
    private final BookingMapper bookingMapper;
    private final RedisLockService redisLockService;

    public BookingResponse createBooking(CreateBookingRequest req, String userId) {
        log.info("Creating booking for user: {}, turf: {}", userId, req.getTurfId());

        if (req.getBookingDate().isBefore(LocalDate.now())) {
            throw new BadRequestException("Booking date cannot be in the past");
        }

        if (!req.getEndTime().isAfter(req.getStartTime())) {
            throw new BadRequestException("End time must be after start time");
        }

        Turf turf = turfRepository.findById(req.getTurfId())
                .orElseThrow(() -> new ResourceNotFoundException("Turf", "id", req.getTurfId()));
        if (!turf.isActive()) {
            throw new BadRequestException("Turf is not active");
        }

        if (req.getStartTime().isBefore(turf.getOpeningTime()) || req.getEndTime().isAfter(turf.getClosingTime())) {
            throw new BadRequestException("Booking time must be within turf operating hours: "
                    + turf.getOpeningTime() + " - " + turf.getClosingTime());
        }

        Venue venue = venueRepository.findById(req.getVenueId())
                .orElseThrow(() -> new ResourceNotFoundException("Venue", "id", req.getVenueId()));
        if (!venue.isActive()) {
            throw new BadRequestException("Venue is not active");
        }
        if (!venue.isApproved()) {
            throw new BadRequestException("Venue is not approved");
        }

        if (!turf.getVenueId().equals(req.getVenueId())) {
            throw new BadRequestException("Turf does not belong to the specified venue");
        }

        List<Booking> overlapping = bookingRepository.findOverlappingBookings(
                req.getTurfId(), req.getBookingDate(), req.getStartTime(), req.getEndTime());
        boolean hasConflict = overlapping.stream()
                .anyMatch(b -> b.getBookingStatus() != Booking.BookingStatus.CANCELLED);
        if (hasConflict) {
            throw new ConflictException("Slot is already booked for the selected time");
        }

        boolean lockAcquired = redisLockService.acquireSlotLock(
                req.getTurfId(), req.getBookingDate(), req.getStartTime(), req.getEndTime());
        if (!lockAcquired) {
            throw new ConflictException("Slot temporarily locked. Please try again in a moment.");
        }

        long hours = Duration.between(req.getStartTime(), req.getEndTime()).toHours();
        BigDecimal amount = turf.getPricePerHour().multiply(BigDecimal.valueOf(hours));

        String bookingNumber = BookingUtils.generateBookingNumber();

        Booking booking = Booking.builder()
                .bookingNumber(bookingNumber)
                .userId(userId)
                .venueId(req.getVenueId())
                .turfId(req.getTurfId())
                .bookingDate(req.getBookingDate())
                .startTime(req.getStartTime())
                .endTime(req.getEndTime())
                .amount(amount)
                .paymentStatus(Booking.PaymentStatus.PENDING)
                .bookingStatus(Booking.BookingStatus.PENDING)
                .build();

        booking = bookingRepository.save(booking);
        log.info("Booking created: {} for user: {}", bookingNumber, userId);
        return enrichBookingResponse(booking);
    }

    public BookingResponse confirmBooking(String bookingId) {
        log.info("Confirming booking: {}", bookingId);
        Booking booking = getBookingEntityById(bookingId);

        booking.setBookingStatus(Booking.BookingStatus.CONFIRMED);
        booking.setPaymentStatus(Booking.PaymentStatus.PAID);
        booking = bookingRepository.save(booking);

        redisLockService.releaseSlotLock(
                booking.getTurfId(), booking.getBookingDate(),
                booking.getStartTime(), booking.getEndTime());

        log.info("Booking confirmed: {}", bookingId);
        return enrichBookingResponse(booking);
    }

    public BookingResponse cancelBooking(String bookingId, String userId) {
        log.info("Cancelling booking: {} by user: {}", bookingId, userId);
        Booking booking = getBookingEntityById(bookingId);

        boolean isAdmin = SecurityUtils.hasRole("ADMIN");
        if (!booking.getUserId().equals(userId) && !isAdmin) {
            throw new UnauthorizedException("You do not have permission to cancel this booking");
        }

        if (booking.getBookingStatus() == Booking.BookingStatus.CONFIRMED
                && booking.getBookingDate().isBefore(LocalDate.now())) {
            throw new BadRequestException("Cannot cancel a confirmed booking after its date has passed");
        }

        if (booking.getBookingStatus() == Booking.BookingStatus.CANCELLED) {
            throw new BadRequestException("Booking is already cancelled");
        }

        Booking.PaymentStatus prevPaymentStatus = booking.getPaymentStatus();
        booking.setBookingStatus(Booking.BookingStatus.CANCELLED);
        booking = bookingRepository.save(booking);

        if (prevPaymentStatus == Booking.PaymentStatus.PENDING) {
            redisLockService.releaseSlotLock(
                    booking.getTurfId(), booking.getBookingDate(),
                    booking.getStartTime(), booking.getEndTime());
        }

        if (prevPaymentStatus == Booking.PaymentStatus.PAID) {
            log.info("REFUND NEEDED for booking: {} with amount: {}", bookingId, booking.getAmount());
        }

        log.info("Booking cancelled: {}", bookingId);
        return enrichBookingResponse(booking);
    }

    public BookingResponse getBookingById(String bookingId, String userId) {
        log.debug("Fetching booking: {} for user: {}", bookingId, userId);
        Booking booking = getBookingEntityById(bookingId);

        boolean isAdmin = SecurityUtils.hasRole("ADMIN");
        boolean isOwner = isVenueOwnerOfBooking(booking, userId);

        if (!booking.getUserId().equals(userId) && !isAdmin && !isOwner) {
            throw new UnauthorizedException("You do not have permission to view this booking");
        }

        return enrichBookingResponse(booking);
    }

    public PageResponse<BookingResponse> getMyBookings(String userId, Pageable pageable) {
        log.debug("Fetching bookings for user: {}", userId);
        List<Booking> all = bookingRepository.findByUserId(userId);
        return toPageResponse(all, pageable);
    }

    public PageResponse<BookingResponse> getVenueBookings(String venueId, String ownerId, Pageable pageable) {
        log.debug("Fetching bookings for venue: {} by owner: {}", venueId, ownerId);
        Venue venue = venueRepository.findById(venueId)
                .orElseThrow(() -> new ResourceNotFoundException("Venue", "id", venueId));
        if (!venue.getOwnerId().equals(ownerId)) {
            throw new UnauthorizedException("You do not have permission to view bookings for this venue");
        }

        List<Booking> all = bookingRepository.findByVenueId(venueId);
        return toPageResponse(all, pageable);
    }

    public PageResponse<BookingResponse> getAllBookingsAdmin(Pageable pageable) {
        log.debug("Admin fetching all bookings");
        Page<Booking> page = bookingRepository.findAll(pageable);
        List<BookingResponse> content = page.getContent().stream()
                .map(this::enrichBookingResponse)
                .toList();
        return PageResponse.<BookingResponse>builder()
                .content(content)
                .page(page.getNumber())
                .size(page.getSize())
                .totalElements(page.getTotalElements())
                .totalPages(page.getTotalPages())
                .last(page.isLast())
                .build();
    }

    private Booking getBookingEntityById(String id) {
        return bookingRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Booking", "id", id));
    }

    private BookingResponse enrichBookingResponse(Booking booking) {
        BookingResponse response = bookingMapper.toResponse(booking);

        venueRepository.findById(booking.getVenueId())
                .ifPresent(v -> response.setVenueName(v.getName()));
        turfRepository.findById(booking.getTurfId())
                .ifPresent(t -> response.setTurfName(t.getName()));
        userRepository.findById(booking.getUserId())
                .ifPresent(u -> response.setUserName(u.getName()));

        return response;
    }

    private boolean isVenueOwnerOfBooking(Booking booking, String userId) {
        return venueRepository.findById(booking.getVenueId())
                .map(v -> v.getOwnerId().equals(userId))
                .orElse(false);
    }

    private PageResponse<BookingResponse> toPageResponse(List<Booking> all, Pageable pageable) {
        int start = (int) pageable.getOffset();
        int end = Math.min(start + pageable.getPageSize(), all.size());
        List<Booking> pageContent = start >= all.size() ? List.of() : all.subList(start, end);

        List<BookingResponse> content = pageContent.stream()
                .map(this::enrichBookingResponse)
                .toList();

        return PageResponse.<BookingResponse>builder()
                .content(content)
                .page(pageable.getPageNumber())
                .size(pageable.getPageSize())
                .totalElements(all.size())
                .totalPages((int) Math.ceil((double) all.size() / pageable.getPageSize()))
                .last(end >= all.size())
                .build();
    }
}
