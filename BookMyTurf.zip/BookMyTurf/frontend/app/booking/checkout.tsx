import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { WebView } from 'react-native-webview';
import Toast from 'react-native-toast-message';
import { useCreateBooking } from '@/hooks/useBookings';
import { useCreateOrder, useVerifyPayment } from '@/hooks/usePayment';
import { useTurfById } from '@/hooks/useTurfs';
import { useVenueById } from '@/hooks/useVenues';
import { RAZORPAY_KEY_ID } from '@/utils/constants';
import { formatCurrency, formatDate, formatTime } from '@/utils/helpers';

interface RazorpaySuccessData {
  razorpay_order_id: string;
  razorpay_payment_id: string;
  razorpay_signature: string;
}

type CheckoutStep = 'summary' | 'payment' | 'verifying';

export default function CheckoutScreen() {
  const params = useLocalSearchParams<{
    turfId: string;
    venueId: string;
    bookingDate: string;
    startTime: string;
    endTime: string;
    amount: string;
  }>();

  const { turfId, venueId, bookingDate, startTime, endTime, amount } = params;

  const [step, setStep] = useState<CheckoutStep>('summary');
  const [razorpayHtml, setRazorpayHtml] = useState('');
  const [currentBookingId, setCurrentBookingId] = useState('');
  const webViewRef = useRef<WebView>(null);

  const { data: turf } = useTurfById(turfId ?? '');
  const { data: venue } = useVenueById(venueId ?? '');

  const createBookingMutation = useCreateBooking();
  const createOrderMutation = useCreateOrder();
  const verifyPaymentMutation = useVerifyPayment();

  const isLoading =
    createBookingMutation.isPending ||
    createOrderMutation.isPending ||
    step === 'verifying';

  const buildRazorpayHtml = (
    orderId: string,
    orderAmount: number,
    bookingId: string,
    keyId: string
  ): string => {
    return `<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <style>
    body { background: #0F0F0F; margin:0; padding:0; }
  </style>
</head>
<body>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
  var options = {
    key: "${keyId}",
    amount: ${orderAmount},
    currency: "INR",
    name: "BookMyTurf",
    description: "Turf Booking",
    order_id: "${orderId}",
    prefill: {},
    theme: { color: "#1DB954" },
    handler: function(response) {
      window.ReactNativeWebView.postMessage(JSON.stringify({
        type: "SUCCESS",
        razorpay_order_id: response.razorpay_order_id,
        razorpay_payment_id: response.razorpay_payment_id,
        razorpay_signature: response.razorpay_signature,
        bookingId: "${bookingId}"
      }));
    },
    modal: {
      ondismiss: function() {
        window.ReactNativeWebView.postMessage(JSON.stringify({ type: "DISMISS" }));
      }
    }
  };
  var rzp = new Razorpay(options);
  rzp.on("payment.failed", function(response) {
    window.ReactNativeWebView.postMessage(JSON.stringify({
      type: "FAILED",
      error: response.error.description
    }));
  });
  rzp.open();
</script>
</body>
</html>`;
  };

  const handleConfirmAndPay = async () => {
    if (!turfId || !venueId || !bookingDate || !startTime || !endTime) {
      Toast.show({ type: 'error', text1: 'Missing booking details' });
      return;
    }

    try {
      // Step 1: Create booking
      const bookingRes = await createBookingMutation.mutateAsync({
        turfId,
        venueId,
        bookingDate,
        startTime,
        endTime,
      });

      const booking = bookingRes.data;
      setCurrentBookingId(booking.id);

      // Step 2: Create Razorpay order
      const orderRes = await createOrderMutation.mutateAsync(booking.id);
      const order = orderRes.data;

      // Step 3: Build Razorpay WebView HTML and show payment screen
      const html = buildRazorpayHtml(
        order.id,
        order.amount,
        booking.id,
        RAZORPAY_KEY_ID
      );
      setRazorpayHtml(html);
      setStep('payment');
    } catch (err) {
      Toast.show({
        type: 'error',
        text1: 'Booking Failed',
        text2:
          err instanceof Error ? err.message : 'Could not initiate booking. Try again.',
      });
    }
  };

  const handleWebViewMessage = async (event: any) => {
    try {
      const data = JSON.parse(event.nativeEvent.data);

      if (data.type === 'SUCCESS') {
        setStep('verifying');
        const verifyData: RazorpaySuccessData = data;
        try {
          await verifyPaymentMutation.mutateAsync({
            razorpayOrderId: verifyData.razorpay_order_id,
            razorpayPaymentId: verifyData.razorpay_payment_id,
            razorpaySignature: verifyData.razorpay_signature,
            bookingId: currentBookingId || data.bookingId,
          });

          router.replace({
            pathname: '/booking/success',
            params: {
              bookingId: currentBookingId || data.bookingId,
              amount: amount ?? '0',
              bookingDate: bookingDate ?? '',
              startTime: startTime ?? '',
              endTime: endTime ?? '',
              venueName: venue?.name ?? '',
              turfName: turf?.name ?? '',
            },
          });
        } catch {
          setStep('summary');
          Toast.show({
            type: 'error',
            text1: 'Payment Verification Failed',
            text2: 'Please contact support with your booking reference.',
          });
        }
      } else if (data.type === 'DISMISS') {
        setStep('summary');
        Toast.show({
          type: 'info',
          text1: 'Payment Cancelled',
          text2: 'You dismissed the payment window.',
        });
      } else if (data.type === 'FAILED') {
        setStep('summary');
        Toast.show({
          type: 'error',
          text1: 'Payment Failed',
          text2: data.error ?? 'Your payment could not be processed.',
        });
      }
    } catch {
      // ignore parse errors
    }
  };

  // Payment WebView screen
  if (step === 'payment') {
    return (
      <SafeAreaView className="flex-1 bg-dark" edges={['top', 'bottom']}>
        <View className="flex-row items-center px-5 py-3">
          <TouchableOpacity
            onPress={() => {
              Alert.alert('Cancel Payment?', 'Are you sure you want to cancel?', [
                { text: 'No', style: 'cancel' },
                { text: 'Yes, cancel', style: 'destructive', onPress: () => setStep('summary') },
              ]);
            }}
            className="w-10 h-10 rounded-full bg-dark-200 items-center justify-center"
          >
            <Ionicons name="close" size={20} color="#fff" />
          </TouchableOpacity>
          <Text className="text-white text-base font-bold ml-3">Secure Payment</Text>
        </View>
        <WebView
          ref={webViewRef}
          source={{ html: razorpayHtml }}
          onMessage={handleWebViewMessage}
          javaScriptEnabled
          domStorageEnabled
          style={{ flex: 1, backgroundColor: '#0F0F0F' }}
          onError={() => {
            setStep('summary');
            Toast.show({ type: 'error', text1: 'Payment page failed to load' });
          }}
        />
      </SafeAreaView>
    );
  }

  // Verifying screen
  if (step === 'verifying') {
    return (
      <SafeAreaView className="flex-1 bg-dark items-center justify-center" edges={['top']}>
        <ActivityIndicator size="large" color="#1DB954" />
        <Text className="text-white text-base font-semibold mt-4">
          Verifying payment...
        </Text>
        <Text className="text-muted text-sm mt-2">Please do not close the app</Text>
      </SafeAreaView>
    );
  }

  // Summary screen
  return (
    <SafeAreaView className="flex-1 bg-dark" edges={['top', 'bottom']}>
      {/* Header */}
      <View className="flex-row items-center px-5 pt-3 pb-4">
        <TouchableOpacity
          onPress={() => router.back()}
          className="w-10 h-10 rounded-full bg-dark-200 items-center justify-center mr-3"
        >
          <Ionicons name="arrow-back" size={20} color="#fff" />
        </TouchableOpacity>
        <Text className="text-white text-lg font-bold">Checkout</Text>
      </View>

      <ScrollView className="flex-1 px-5" showsVerticalScrollIndicator={false}>
        {/* Booking details card */}
        <View className="bg-card rounded-2xl p-5 mb-4 border border-dark-300">
          <Text className="text-white text-base font-bold mb-4">Booking Details</Text>

          <DetailRow
            icon="location-outline"
            label="Venue"
            value={venue?.name ?? '—'}
          />
          <DetailRow
            icon="football-outline"
            label="Turf"
            value={turf?.name ?? '—'}
          />
          <DetailRow
            icon="tennisball-outline"
            label="Sport"
            value={turf?.sport ?? '—'}
          />
          <DetailRow
            icon="calendar-outline"
            label="Date"
            value={bookingDate ? formatDate(bookingDate) : '—'}
          />
          <DetailRow
            icon="time-outline"
            label="Time"
            value={
              startTime && endTime
                ? `${formatTime(startTime)} – ${formatTime(endTime)}`
                : '—'
            }
          />
        </View>

        {/* Payment summary card */}
        <View className="bg-card rounded-2xl p-5 mb-4 border border-dark-300">
          <Text className="text-white text-base font-bold mb-4">Payment Summary</Text>
          <View className="flex-row items-center justify-between mb-2">
            <Text className="text-muted text-sm">Turf rental (1 hr)</Text>
            <Text className="text-white text-sm font-medium">
              {formatCurrency(Number(amount) ?? 0)}
            </Text>
          </View>
          <View className="flex-row items-center justify-between mb-2">
            <Text className="text-muted text-sm">Convenience fee</Text>
            <Text className="text-success text-sm font-medium">Free</Text>
          </View>
          <View className="h-px bg-dark-300 my-3" />
          <View className="flex-row items-center justify-between">
            <Text className="text-white text-base font-bold">Total</Text>
            <Text className="text-primary text-xl font-bold">
              {formatCurrency(Number(amount) ?? 0)}
            </Text>
          </View>
        </View>

        {/* Security note */}
        <View className="flex-row items-center bg-dark-200 rounded-xl px-4 py-3 mb-6">
          <Ionicons name="shield-checkmark-outline" size={18} color="#1DB954" />
          <Text className="text-muted text-xs ml-2 flex-1">
            Payments are secured with 256-bit SSL encryption via Razorpay
          </Text>
        </View>

        {createBookingMutation.isError && (
          <View className="bg-error/10 border border-error/30 rounded-xl px-4 py-3 mb-4">
            <Text className="text-error text-sm">
              {createBookingMutation.error instanceof Error
                ? createBookingMutation.error.message
                : 'Failed to create booking. Please try again.'}
            </Text>
          </View>
        )}

        <View className="h-24" />
      </ScrollView>

      {/* Pay button */}
      <View className="absolute bottom-0 left-0 right-0 px-5 pb-6 pt-3 bg-dark border-t border-dark-200">
        <TouchableOpacity
          onPress={handleConfirmAndPay}
          disabled={isLoading}
          className="bg-primary py-4 rounded-2xl flex-row items-center justify-center"
          style={{ opacity: isLoading ? 0.7 : 1 }}
          activeOpacity={0.85}
        >
          {isLoading ? (
            <ActivityIndicator color="#fff" size="small" />
          ) : (
            <>
              <Ionicons name="lock-closed-outline" size={18} color="#fff" />
              <Text className="text-white text-base font-bold ml-2">
                Confirm & Pay {formatCurrency(Number(amount) ?? 0)}
              </Text>
            </>
          )}
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

function DetailRow({
  icon,
  label,
  value,
}: {
  icon: React.ComponentProps<typeof Ionicons>['name'];
  label: string;
  value: string;
}) {
  return (
    <View className="flex-row items-center justify-between mb-3">
      <View className="flex-row items-center">
        <View className="w-8 h-8 rounded-lg bg-dark-300 items-center justify-center mr-2.5">
          <Ionicons name={icon} size={15} color="#6B7280" />
        </View>
        <Text className="text-muted text-sm">{label}</Text>
      </View>
      <Text className="text-white text-sm font-medium max-w-xs text-right flex-1 ml-4" numberOfLines={1}>
        {value}
      </Text>
    </View>
  );
}
