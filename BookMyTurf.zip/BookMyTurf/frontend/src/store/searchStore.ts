import { create } from 'zustand';

interface PriceRange {
  min: number;
  max: number;
}

interface SearchState {
  searchQuery: string;
  selectedCity: string | null;
  selectedSport: string | null;
  priceRange: PriceRange;
  sortBy: string;
}

interface SearchActions {
  setSearchQuery: (query: string) => void;
  setCity: (city: string | null) => void;
  setSport: (sport: string | null) => void;
  setPriceRange: (range: PriceRange) => void;
  setSortBy: (sortBy: string) => void;
  resetFilters: () => void;
}

type SearchStore = SearchState & SearchActions;

const initialState: SearchState = {
  searchQuery: '',
  selectedCity: null,
  selectedSport: null,
  priceRange: { min: 0, max: 5000 },
  sortBy: 'relevance',
};

export const useSearchStore = create<SearchStore>((set) => ({
  ...initialState,

  setSearchQuery: (query: string) => {
    set({ searchQuery: query });
  },

  setCity: (city: string | null) => {
    set({ selectedCity: city });
  },

  setSport: (sport: string | null) => {
    set({ selectedSport: sport });
  },

  setPriceRange: (range: PriceRange) => {
    set({ priceRange: range });
  },

  setSortBy: (sortBy: string) => {
    set({ sortBy });
  },

  resetFilters: () => {
    set({
      searchQuery: '',
      selectedCity: null,
      selectedSport: null,
      priceRange: { min: 0, max: 5000 },
      sortBy: 'relevance',
    });
  },
}));
