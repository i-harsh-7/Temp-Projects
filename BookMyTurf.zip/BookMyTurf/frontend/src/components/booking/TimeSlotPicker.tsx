import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { TimeSlot } from '@/types';
import { formatTime, formatCurrency, isSlotInPast } from '@/utils/helpers';

interface TimeSlotPickerProps {
  slots: TimeSlot[];
  selectedSlot: TimeSlot | null;
  onSelectSlot: (slot: TimeSlot) => void;
  bookingDate?: string;
}

interface SlotChipProps {
  slot: TimeSlot;
  isSelected: boolean;
  isPast: boolean;
  onPress: () => void;
}

const SlotChip: React.FC<SlotChipProps> = ({
  slot,
  isSelected,
  isPast,
  onPress,
}) => {
  const isDisabled = !slot.available || isPast;

  let containerStyle = 'bg-dark-200 border border-dark-300';
  let timeTextStyle = 'text-muted';
  let priceTextStyle = 'text-dark-400';

  if (isSelected) {
    containerStyle = 'bg-primary/20 border-2 border-primary';
    timeTextStyle = 'text-primary font-bold';
    priceTextStyle = 'text-primary/80';
  } else if (!isDisabled) {
    containerStyle = 'bg-dark-200 border border-primary/40';
    timeTextStyle = 'text-white';
    priceTextStyle = 'text-muted';
  }

  return (
    <TouchableOpacity
      onPress={isDisabled ? undefined : onPress}
      disabled={isDisabled}
      className={`rounded-xl p-3 m-1 items-center justify-center ${containerStyle}`}
      style={{ width: '46%' }}
      activeOpacity={isDisabled ? 1 : 0.7}
    >
      {isPast && (
        <View className="absolute top-1.5 right-1.5">
          <Ionicons name="time" size={10} color="#6B7280" />
        </View>
      )}

      {!slot.available && !isPast && (
        <View className="absolute top-1.5 right-1.5">
          <Ionicons name="close-circle" size={12} color="#EF4444" />
        </View>
      )}

      {isSelected && (
        <View className="absolute top-1.5 right-1.5">
          <Ionicons name="checkmark-circle" size={14} color="#1DB954" />
        </View>
      )}

      <Text className={`text-sm ${timeTextStyle} ${isDisabled ? 'line-through' : ''}`}>
        {formatTime(slot.startTime)}
      </Text>
      <Text className={`text-xs mt-0.5 ${timeTextStyle} ${isDisabled ? 'line-through' : ''}`}>
        – {formatTime(slot.endTime)}
      </Text>
      <Text className={`text-xs mt-1 ${priceTextStyle}`}>
        {isDisabled && !isPast ? 'Booked' : isPast ? 'Past' : formatCurrency(slot.price)}
      </Text>
    </TouchableOpacity>
  );
};

const TimeSlotPicker: React.FC<TimeSlotPickerProps> = ({
  slots,
  selectedSlot,
  onSelectSlot,
  bookingDate,
}) => {
  if (slots.length === 0) {
    return (
      <View className="items-center py-10">
        <Ionicons name="calendar-outline" size={40} color="#3A3A3A" />
        <Text className="text-muted text-sm mt-3">No slots available</Text>
      </View>
    );
  }

  const availableCount = slots.filter((s) => s.available).length;

  return (
    <View>
      {/* Legend */}
      <View className="flex-row items-center justify-between mb-3 px-1">
        <Text className="text-white text-sm font-semibold">Select Time Slot</Text>
        <Text className="text-muted text-xs">
          {availableCount} / {slots.length} available
        </Text>
      </View>

      {/* Legend indicators */}
      <View className="flex-row items-center gap-4 mb-4 px-1">
        <View className="flex-row items-center gap-1.5">
          <View className="w-3 h-3 rounded-full bg-primary/30 border border-primary/60" />
          <Text className="text-muted text-xs">Available</Text>
        </View>
        <View className="flex-row items-center gap-1.5">
          <View className="w-3 h-3 rounded-full bg-dark-200 border border-dark-300" />
          <Text className="text-muted text-xs">Booked</Text>
        </View>
        <View className="flex-row items-center gap-1.5">
          <View className="w-3 h-3 rounded-full bg-primary/20 border-2 border-primary" />
          <Text className="text-muted text-xs">Selected</Text>
        </View>
      </View>

      {/* Slots grid */}
      <ScrollView showsVerticalScrollIndicator={false}>
        <View className="flex-row flex-wrap">
          {slots.map((slot, index) => {
            const isPast = bookingDate
              ? isSlotInPast(bookingDate, slot.startTime)
              : false;

            const isSelected =
              selectedSlot?.startTime === slot.startTime &&
              selectedSlot?.endTime === slot.endTime;

            return (
              <SlotChip
                key={`${slot.startTime}-${index}`}
                slot={slot}
                isSelected={isSelected}
                isPast={isPast}
                onPress={() => onSelectSlot(slot)}
              />
            );
          })}
        </View>
      </ScrollView>
    </View>
  );
};

export default TimeSlotPicker;
