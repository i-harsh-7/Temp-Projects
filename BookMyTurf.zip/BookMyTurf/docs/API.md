# REST API Reference

Base URL (local): **`http://localhost:8080/api`** — the server runs on port `8080` with context-path `/api`.

All paths below are shown **with the `/api` prefix included** (i.e. the full external path).

---

## Response envelope — `ApiResponse<T>`

Every endpoint returns a JSON envelope:

```json
{
  "success": true,
  "message": "Human-readable message",
  "data": { },
  "timestamp": "2026-06-28T10:15:30.123Z"
}
```

| Field | Type | Notes |
| --- | --- | --- |
| `success` | boolean | `true` on success, `false` on error |
| `message` | string | Description of the outcome |
| `data` | `T` \| null | Payload (omitted when null — `@JsonInclude(NON_NULL)`) |
| `timestamp` | ISO-8601 instant | Server time |

Error responses use the same envelope with `success: false` and a `message` (produced by the global
exception handler).

---

## Authentication header

Protected endpoints require a **Bearer JWT access token**:

```
Authorization: Bearer <accessToken>
```

- Access tokens are JWTs (HMAC-SHA256), default lifetime **15 minutes** (`JWT_EXPIRY=900000` ms).
- Refresh tokens are opaque random strings stored in MongoDB, default lifetime **7 days**
  (`JWT_REFRESH_EXPIRY=604800000` ms).
- On `401`, the mobile client automatically calls `POST /api/auth/refresh` and retries.

### Public (no token) endpoints

```
/api/auth/**
/api/venues/public/**
/api/turfs/public/**
/api/swagger-ui/**, /api/v3/api-docs/**, /api/actuator/health
```

Everything else requires authentication. Role-restricted endpoints additionally require the noted role
(`@PreAuthorize`).

---

## Pagination

Paginated endpoints accept standard Spring `Pageable` query params:

| Param | Default | Description |
| --- | --- | --- |
| `page` | `0` | Zero-based page index |
| `size` | `20` | Page size |
| `sort` | — | e.g. `sort=createdAt,desc` |

They return a `PageResponse<T>` in `data`:

```json
{
  "content": [ ],
  "page": 0,
  "size": 20,
  "totalElements": 42,
  "totalPages": 3,
  "last": false
}
```

---

## Roles

`CUSTOMER`, `VENUE_OWNER`, `ADMIN`. Spring Security checks `hasRole('X')`.

---

# Auth — `/api/auth`

### `POST /api/auth/register`
Public. Registers a user and returns tokens. `role` is one of `CUSTOMER`, `VENUE_OWNER`, `ADMIN`.

**Request**
```json
{
  "name": "Asha Player",
  "email": "asha@example.com",
  "password": "password123",
  "phone": "9876543210",
  "role": "CUSTOMER"
}
```
Validation: name 2–100 chars; valid email; password ≥ 8 chars; phone matches `^[6-9]\d{9}$`; role required.

**Response — `201 Created`**
```json
{
  "success": true,
  "message": "User registered successfully",
  "data": {
    "accessToken": "eyJhbGciOiJIUzI1NiJ9...",
    "refreshToken": "f1c2...e9a0",
    "user": {
      "id": "665f...",
      "name": "Asha Player",
      "email": "asha@example.com",
      "phone": "9876543210",
      "role": "CUSTOMER",
      "profileImage": null
    }
  },
  "timestamp": "2026-06-28T10:15:30.123Z"
}
```
Status: `201`, `400` (validation), `409` (email already in use).

### `POST /api/auth/login`
Public. Authenticates and returns tokens.

**Request**
```json
{ "email": "asha@example.com", "password": "password123" }
```
**Response — `200 OK`** — same `AuthResponse` shape as register (`message: "Login successful"`).
Status: `200`, `400`, `401` (invalid credentials / deactivated account).

### `POST /api/auth/refresh`
Public. Exchanges a valid refresh token for a new access token.

**Request**
```json
{ "refreshToken": "f1c2...e9a0" }
```
**Response — `200 OK`** — `AuthResponse` with a fresh `accessToken` (same `refreshToken` echoed).
Status: `200`, `401` (invalid / revoked / expired refresh token).

### `POST /api/auth/logout`
Public (idempotent). Revokes the refresh token.

**Request**
```json
{ "refreshToken": "f1c2...e9a0" }
```
**Response — `200 OK`**
```json
{ "success": true, "message": "Logged out successfully", "timestamp": "..." }
```

---

# Users — `/api/users`

### `GET /api/users/me`
Auth: any authenticated user. Returns the current user's profile.

**Response — `200 OK`**
```json
{
  "success": true,
  "message": "User profile retrieved",
  "data": {
    "id": "665f...", "name": "Asha Player", "email": "asha@example.com",
    "phone": "9876543210", "role": "CUSTOMER", "profileImage": null
  },
  "timestamp": "..."
}
```

### `PUT /api/users/me`
Auth: any authenticated user. Updates profile fields.

**Request** (`UpdateProfileRequest`)
```json
{ "name": "Asha P.", "phone": "9876500000" }
```
**Response — `200 OK`** — updated `UserResponse`.

### `PUT /api/users/me/avatar`
Auth: any authenticated user. Multipart upload of an avatar image (stored in Cloudinary `avatars/`).

**Request** — `multipart/form-data` with part **`file`** (image).
**Response — `200 OK`** — updated `UserResponse` with `profileImage` URL.

### `GET /api/users/`
Auth: **ADMIN**. Paginated list of users.
**Response — `200 OK`** — `PageResponse<UserResponse>`.

### `PUT /api/users/{id}/toggle`
Auth: **ADMIN**. Toggles a user's `active` flag (activate/deactivate).
**Response — `200 OK`** — updated `UserResponse`.

---

# Venues — `/api/venues`

### `GET /api/venues/public`
Public. Paginated list of **approved & active** venues.
**Response — `200 OK`** — `PageResponse<VenueResponse>`.

`VenueResponse` shape:
```json
{
  "id": "v123", "ownerId": "o1", "name": "Green Arena", "address": "12 MG Road",
  "city": "Bengaluru", "latitude": 12.97, "longitude": 77.59,
  "description": "Floodlit 5-a-side turf", "images": ["https://res.cloudinary.com/..."],
  "amenities": ["Parking","Washroom"], "sports": ["Football","Cricket"],
  "approved": true, "active": true,
  "createdAt": "2026-06-01T08:00:00Z", "updatedAt": "2026-06-01T08:00:00Z",
  "turfCount": 3
}
```

### `GET /api/venues/public/{id}`
Public. Single venue by id. Status: `200`, `404`.

### `GET /api/venues/public/search`
Public. Search approved venues. Query params (all optional): `query`, `city`, `sport`, plus pagination.

Example: `GET /api/venues/public/search?city=Bengaluru&sport=Football&page=0&size=10`
**Response — `200 OK`** — `PageResponse<VenueResponse>`.

### `GET /api/venues/my`
Auth: **VENUE_OWNER**. Lists the caller's own venues.
**Response — `200 OK`** — `data` is a plain `List<VenueResponse>` (not paginated).

### `POST /api/venues/`
Auth: **VENUE_OWNER**. Creates a venue (starts `approved: false`).

**Request** (`CreateVenueRequest`)
```json
{
  "name": "Green Arena",
  "address": "12 MG Road",
  "city": "Bengaluru",
  "latitude": 12.9716,
  "longitude": 77.5946,
  "description": "Floodlit 5-a-side turf",
  "amenities": ["Parking", "Washroom"],
  "sports": ["Football", "Cricket"]
}
```
Validation: name 2–200; address/city required; latitude −90..90; longitude −180..180; ≥1 sport.
**Response — `201 Created`** — `VenueResponse`.

### `PUT /api/venues/{id}`
Auth: **VENUE_OWNER** (must own the venue). Updates a venue (`UpdateVenueRequest`).
**Response — `200 OK`** — updated `VenueResponse`. Status: `200`, `401/403`, `404`.

### `DELETE /api/venues/{id}`
Auth: **VENUE_OWNER** (owner). Deletes/deactivates a venue.
**Response — `200 OK`** — `{ "success": true, "message": "Venue deleted successfully" }`.

### `POST /api/venues/{id}/images`
Auth: **VENUE_OWNER** (owner). Multipart upload of one or more images (Cloudinary `venues/`).
**Request** — `multipart/form-data` with repeated part **`files`**.
**Response — `200 OK`** — `VenueResponse` with appended `images`.

### `GET /api/venues/admin`
Auth: **ADMIN**. Paginated list of **all** venues (including unapproved).
**Response — `200 OK`** — `PageResponse<VenueResponse>`.

### `PUT /api/venues/admin/{id}/approve`
Auth: **ADMIN**. Approves a venue (`approved: true`).
**Response — `200 OK`** — updated `VenueResponse`.

---

# Turfs — `/api/turfs`

### `GET /api/turfs/public/venue/{venueId}`
Public. Lists turfs for a venue. **Response — `200 OK`** — `List<TurfResponse>`.

`TurfResponse` shape:
```json
{
  "id": "t1", "venueId": "v123", "name": "Turf A", "sport": "Football",
  "pricePerHour": 800, "openingTime": "06:00:00", "closingTime": "23:00:00",
  "images": ["https://res.cloudinary.com/..."], "amenities": ["Bibs"],
  "active": true, "createdAt": "...", "updatedAt": "..."
}
```

### `GET /api/turfs/public/{id}`
Public. Single turf by id. Status: `200`, `404`.

### `GET /api/turfs/public/{id}/slots`
Public. Hourly slot availability for a date. Query param **`date`** (ISO `yyyy-MM-dd`, **required**).

Example: `GET /api/turfs/public/t1/slots?date=2026-07-01`

**Response — `200 OK`** (`SlotAvailabilityResponse`)
```json
{
  "success": true,
  "message": "Slots retrieved",
  "data": {
    "turfId": "t1",
    "date": "2026-07-01",
    "availableSlots": [
      { "startTime": "06:00:00", "endTime": "07:00:00", "available": true,  "price": 800 },
      { "startTime": "07:00:00", "endTime": "08:00:00", "available": false, "price": 800 }
    ]
  },
  "timestamp": "..."
}
```
Slots are generated in 1-hour increments from the turf's `openingTime` to `closingTime`; a slot is
`available: false` if it overlaps a non-cancelled booking.

### `POST /api/turfs/`
Auth: **VENUE_OWNER** (must own the venue). Creates a turf.

**Request** (`CreateTurfRequest`)
```json
{
  "venueId": "v123",
  "name": "Turf A",
  "sport": "Football",
  "pricePerHour": 800,
  "openingTime": "06:00:00",
  "closingTime": "23:00:00",
  "amenities": ["Bibs", "Lights"]
}
```
Validation: venueId/name/sport required; name 2–200; pricePerHour > 0; opening/closing times required.
**Response — `201 Created`** — `TurfResponse`.

### `PUT /api/turfs/{id}`
Auth: **VENUE_OWNER** (owner). Updates a turf (`UpdateTurfRequest`). **Response — `200 OK`**.

### `DELETE /api/turfs/{id}`
Auth: **VENUE_OWNER** (owner). Deletes/deactivates a turf. **Response — `200 OK`**.

### `POST /api/turfs/{id}/images`
Auth: **VENUE_OWNER** (owner). Multipart upload of images (Cloudinary `turfs/`).
**Request** — `multipart/form-data` with repeated part **`files`**. **Response — `200 OK`** — `TurfResponse`.

---

# Bookings — `/api/bookings`

### `POST /api/bookings/`
Auth: **CUSTOMER**. Creates a `PENDING` booking and acquires a Redis slot lock (5-min TTL). Amount =
`pricePerHour × hours`.

**Request** (`CreateBookingRequest`)
```json
{
  "turfId": "t1",
  "venueId": "v123",
  "bookingDate": "2026-07-01",
  "startTime": "18:00:00",
  "endTime": "19:00:00"
}
```
Validation/business rules: date today-or-future; `endTime` after `startTime`; within turf operating
hours; turf & venue active; venue approved; turf belongs to venue; no overlapping non-cancelled booking;
slot not currently locked.

**Response — `201 Created`** (`BookingResponse`)
```json
{
  "success": true,
  "message": "Booking created successfully",
  "data": {
    "id": "b1", "bookingNumber": "BMT-XXXXXX", "userId": "u1",
    "venueId": "v123", "turfId": "t1",
    "bookingDate": "2026-07-01", "startTime": "18:00:00", "endTime": "19:00:00",
    "amount": 800, "paymentStatus": "PENDING", "bookingStatus": "PENDING",
    "createdAt": "...", "updatedAt": "...",
    "venueName": "Green Arena", "turfName": "Turf A", "userName": "Asha Player"
  },
  "timestamp": "..."
}
```
Status: `201`, `400` (validation/business rule), `404` (turf/venue), `409` (slot booked or locked).

### `GET /api/bookings/my`
Auth: any authenticated user. Paginated bookings for the caller.
**Response — `200 OK`** — `PageResponse<BookingResponse>`.

### `GET /api/bookings/{id}`
Auth: booking owner, the venue's owner, or **ADMIN**. Single booking. Status: `200`, `401/403`, `404`.

### `PUT /api/bookings/{id}/cancel`
Auth: booking owner or **ADMIN**. Cancels a booking; releases the Redis lock if payment was still
`PENDING`; logs a refund-needed note if it was `PAID`.
**Response — `200 OK`** — updated `BookingResponse` (`bookingStatus: "CANCELLED"`).
Status: `200`, `400` (already cancelled / past confirmed booking), `401/403`, `404`.

### `GET /api/bookings/venue/{venueId}`
Auth: **VENUE_OWNER** (owner of the venue). Paginated bookings for a venue.
**Response — `200 OK`** — `PageResponse<BookingResponse>`.

### `GET /api/bookings/admin`
Auth: **ADMIN**. Paginated list of all bookings.
**Response — `200 OK`** — `PageResponse<BookingResponse>`.

---

# Payments — `/api/payments`

### `POST /api/payments/create-order`
Auth: authenticated (booking owner). Creates a Razorpay order for a `PENDING` booking and persists a
`Payment` record with status `CREATED`.

**Request**
```json
{ "bookingId": "b1" }
```
**Response — `200 OK`** (`PaymentOrderResponse`)
```json
{
  "success": true,
  "message": "Payment order created",
  "data": {
    "razorpayOrderId": "order_Nxxxxx",
    "amount": 800,
    "currency": "INR",
    "keyId": "rzp_test_xxxxx",
    "bookingId": "b1",
    "bookingNumber": "BMT-XXXXXX"
  },
  "timestamp": "..."
}
```
Status: `200`, `400` (not PENDING / Razorpay failure), `401/403`, `404`.

### `POST /api/payments/verify`
Auth: authenticated. Verifies the Razorpay HMAC-SHA256 signature over `razorpayOrderId|razorpayPaymentId`,
marks the payment `PAID`, and **confirms the booking** (releases the slot lock).

**Request** (`PaymentVerificationRequest`)
```json
{
  "razorpayOrderId": "order_Nxxxxx",
  "razorpayPaymentId": "pay_Nyyyyy",
  "razorpaySignature": "9ef0...c1",
  "bookingId": "b1"
}
```
**Response — `200 OK`** — confirmed `BookingResponse` (`bookingStatus: "CONFIRMED"`, `paymentStatus: "PAID"`),
`message: "Payment verified and booking confirmed"`.
Status: `200`, `401` (signature verification failed), `404` (payment not found).

### `POST /api/payments/failure`
Auth: authenticated. Records a payment failure — marks the `Payment` `FAILED` and the booking's
`paymentStatus` `FAILED`.

**Request**
```json
{ "razorpayOrderId": "order_Nxxxxx" }
```
**Response — `200 OK`** — `{ "success": true, "message": "Payment failure recorded" }`.

> The slot's Redis lock is **not** explicitly deleted here; it auto-expires after its 5-minute TTL,
> freeing the slot.

---

# Admin — `/api/admin`

All endpoints require **ADMIN** (class-level `@PreAuthorize("hasRole('ADMIN')")`).

### `GET /api/admin/dashboard`
Platform metrics.
**Response — `200 OK`** (`DashboardResponse`)
```json
{
  "success": true,
  "message": "Dashboard data retrieved",
  "data": {
    "totalUsers": 120,
    "totalVenues": 18,
    "pendingApprovalVenues": 3,
    "totalBookings": 540,
    "totalRevenue": 432000
  },
  "timestamp": "..."
}
```
`totalRevenue` sums `amount` over `CONFIRMED` bookings; `pendingApprovalVenues` counts active-but-unapproved venues.

### `GET /api/admin/users`
Paginated users — `PageResponse<UserResponse>`.

### `GET /api/admin/venues`
Paginated venues (all) — `PageResponse<VenueResponse>`.

### `GET /api/admin/bookings`
Paginated bookings (all) — `PageResponse<BookingResponse>`.

---

## Status code summary

| Code | Meaning |
| --- | --- |
| `200 OK` | Successful read/update |
| `201 Created` | Resource created (register, create venue/turf/booking) |
| `400 Bad Request` | Validation or business-rule failure |
| `401 Unauthorized` | Missing/invalid token, bad credentials, signature failure |
| `403 Forbidden` | Authenticated but lacking the required role / ownership |
| `404 Not Found` | Resource does not exist |
| `409 Conflict` | Duplicate email, slot already booked, or slot locked |