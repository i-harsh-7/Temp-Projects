package com.bookmyturf.util;

import java.security.SecureRandom;
import java.time.LocalTime;

public class BookingUtils {

    private BookingUtils() {}

    private static final String ALPHANUMERIC = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    private static final SecureRandom RANDOM = new SecureRandom();

    public static String generateBookingNumber() {
        StringBuilder sb = new StringBuilder("BMT");
        for (int i = 0; i < 8; i++) {
            sb.append(ALPHANUMERIC.charAt(RANDOM.nextInt(ALPHANUMERIC.length())));
        }
        return sb.toString();
    }

    public static boolean doTimeSlotsOverlap(LocalTime s1, LocalTime e1, LocalTime s2, LocalTime e2) {
        // Two time ranges overlap if s1 < e2 AND s2 < e1
        return s1.isBefore(e2) && s2.isBefore(e1);
    }
}
