import React, { useRef, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Dimensions,
} from 'react-native';
import { format, addDays, isSameDay, isBefore, startOfDay } from 'date-fns';

interface DateStripProps {
  selectedDate: string; // 'YYYY-MM-DD'
  onSelectDate: (date: string) => void;
  numberOfDays?: number;
}

const ITEM_WIDTH = 60;
const ITEM_GAP = 8;

const DateStrip: React.FC<DateStripProps> = ({
  selectedDate,
  onSelectDate,
  numberOfDays = 14,
}) => {
  const scrollRef = useRef<ScrollView>(null);
  const today = startOfDay(new Date());

  const dates = Array.from({ length: numberOfDays }, (_, i) =>
    addDays(today, i)
  );

  const selectedDateObj = selectedDate
    ? startOfDay(new Date(selectedDate + 'T00:00:00'))
    : today;

  // Scroll to selected date on mount
  useEffect(() => {
    const idx = dates.findIndex((d) => isSameDay(d, selectedDateObj));
    if (idx > 0 && scrollRef.current) {
      setTimeout(() => {
        scrollRef.current?.scrollTo({
          x: idx * (ITEM_WIDTH + ITEM_GAP) - 16,
          animated: true,
        });
      }, 100);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <ScrollView
      ref={scrollRef}
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={{ paddingHorizontal: 16, paddingVertical: 4 }}
    >
      {dates.map((date, idx) => {
        const isSelected = isSameDay(date, selectedDateObj);
        const isToday = isSameDay(date, today);
        const isPast = isBefore(date, today);
        const dateStr = format(date, 'yyyy-MM-dd');

        const dayName = isToday ? 'Today' : format(date, 'EEE');
        const dayNum = format(date, 'd');
        const month = format(date, 'MMM');

        return (
          <TouchableOpacity
            key={dateStr}
            onPress={() => onSelectDate(dateStr)}
            disabled={isPast}
            activeOpacity={0.7}
            style={{
              width: ITEM_WIDTH,
              marginRight: idx < dates.length - 1 ? ITEM_GAP : 0,
              alignItems: 'center',
              paddingVertical: 10,
              paddingHorizontal: 6,
              borderRadius: 16,
              backgroundColor: isSelected
                ? '#1DB954'
                : isToday
                ? '#1DB95420'
                : '#1A1A1A',
              borderWidth: isSelected ? 0 : isToday ? 1.5 : 1,
              borderColor: isSelected
                ? 'transparent'
                : isToday
                ? '#1DB954'
                : '#303030',
              opacity: isPast ? 0.35 : 1,
            }}
          >
            <Text
              style={{
                fontSize: 11,
                fontWeight: '500',
                color: isSelected ? '#fff' : isToday ? '#1DB954' : '#6B7280',
                marginBottom: 4,
              }}
            >
              {dayName}
            </Text>
            <Text
              style={{
                fontSize: 20,
                fontWeight: '700',
                color: isSelected ? '#fff' : '#fff',
                lineHeight: 24,
              }}
            >
              {dayNum}
            </Text>
            <Text
              style={{
                fontSize: 11,
                color: isSelected ? '#ffffffaa' : '#6B7280',
                marginTop: 2,
              }}
            >
              {month}
            </Text>
          </TouchableOpacity>
        );
      })}
    </ScrollView>
  );
};

export default DateStrip;
