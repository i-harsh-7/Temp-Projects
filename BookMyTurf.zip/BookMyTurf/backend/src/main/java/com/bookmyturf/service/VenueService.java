package com.bookmyturf.service;

import com.bookmyturf.cloudinary.CloudinaryService;
import com.bookmyturf.dto.*;
import com.bookmyturf.entity.Venue;
import com.bookmyturf.exception.ResourceNotFoundException;
import com.bookmyturf.exception.UnauthorizedException;
import com.bookmyturf.mapper.VenueMapper;
import com.bookmyturf.repository.TurfRepository;
import com.bookmyturf.repository.VenueRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.geo.GeoJsonPoint;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class VenueService {

    private final VenueRepository venueRepository;
    private final TurfRepository turfRepository;
    private final VenueMapper venueMapper;
    private final CloudinaryService cloudinaryService;

    public VenueResponse createVenue(CreateVenueRequest req, String ownerId) {
        log.info("Creating venue for owner: {}", ownerId);
        Venue venue = venueMapper.toVenue(req);
        venue.setOwnerId(ownerId);
        venue.setLocation(new GeoJsonPoint(req.getLongitude(), req.getLatitude()));
        venue.setApproved(false);
        venue.setActive(true);
        venue.setImages(new ArrayList<>());
        venue = venueRepository.save(venue);
        log.info("Venue created with id: {}", venue.getId());
        return toResponseWithTurfCount(venue);
    }

    public VenueResponse updateVenue(String venueId, UpdateVenueRequest req, String ownerId) {
        log.info("Updating venue: {} by owner: {}", venueId, ownerId);
        Venue venue = getVenueEntityById(venueId);
        verifyOwnership(venue, ownerId);

        venueMapper.updateVenue(req, venue);

        if (req.getLatitude() != null && req.getLongitude() != null) {
            venue.setLocation(new GeoJsonPoint(req.getLongitude(), req.getLatitude()));
        } else if (req.getLatitude() != null) {
            double lon = venue.getLocation() != null ? venue.getLocation().getX() : 0.0;
            venue.setLocation(new GeoJsonPoint(lon, req.getLatitude()));
        } else if (req.getLongitude() != null) {
            double lat = venue.getLocation() != null ? venue.getLocation().getY() : 0.0;
            venue.setLocation(new GeoJsonPoint(req.getLongitude(), lat));
        }

        venue = venueRepository.save(venue);
        log.info("Venue updated: {}", venueId);
        return toResponseWithTurfCount(venue);
    }

    public void deleteVenue(String venueId, String ownerId) {
        log.info("Soft deleting venue: {} by owner: {}", venueId, ownerId);
        Venue venue = getVenueEntityById(venueId);
        verifyOwnership(venue, ownerId);
        venue.setActive(false);
        venueRepository.save(venue);
        log.info("Venue soft deleted: {}", venueId);
    }

    public VenueResponse getVenueById(String id) {
        log.debug("Fetching venue by id: {}", id);
        Venue venue = getVenueEntityById(id);
        return toResponseWithTurfCount(venue);
    }

    public PageResponse<VenueResponse> getPublicVenues(Pageable pageable) {
        log.debug("Fetching public venues");
        List<Venue> all = venueRepository.findByApprovedTrueAndActiveTrue();
        return toPageResponse(all, pageable);
    }

    public List<VenueResponse> getMyVenues(String ownerId) {
        log.debug("Fetching venues for owner: {}", ownerId);
        return venueRepository.findByOwnerId(ownerId).stream()
                .map(this::toResponseWithTurfCount)
                .toList();
    }

    public PageResponse<VenueResponse> searchVenues(String query, String city, String sport, Pageable pageable) {
        log.debug("Searching venues: query={}, city={}, sport={}", query, city, sport);
        List<Venue> venues;

        if (sport != null && !sport.isBlank()) {
            venues = venueRepository.findByApprovedTrueAndActiveTrueAndSportsContaining(sport);
        } else if (city != null && !city.isBlank()) {
            venues = venueRepository.findByCityIgnoreCaseAndApprovedTrueAndActiveTrue(city);
        } else if (query != null && !query.isBlank()) {
            venues = venueRepository.searchVenues(query);
        } else {
            venues = venueRepository.findByApprovedTrueAndActiveTrue();
        }

        if (city != null && !city.isBlank() && (sport != null && !sport.isBlank() || query != null && !query.isBlank())) {
            final String cityFilter = city.toLowerCase();
            venues = venues.stream()
                    .filter(v -> v.getCity() != null && v.getCity().toLowerCase().contains(cityFilter))
                    .toList();
        }

        return toPageResponse(venues, pageable);
    }

    public VenueResponse uploadVenueImages(String venueId, List<MultipartFile> files, String ownerId) {
        log.info("Uploading {} images for venue: {}", files.size(), venueId);
        Venue venue = getVenueEntityById(venueId);
        verifyOwnership(venue, ownerId);

        List<String> images = venue.getImages() != null ? new ArrayList<>(venue.getImages()) : new ArrayList<>();
        for (MultipartFile file : files) {
            String url = cloudinaryService.uploadImage(file, "venues");
            images.add(url);
            log.debug("Uploaded image to Cloudinary: {}", url);
        }
        venue.setImages(images);
        venue = venueRepository.save(venue);
        log.info("Venue images updated: {}", venueId);
        return toResponseWithTurfCount(venue);
    }

    public VenueResponse approveVenue(String venueId) {
        log.info("Approving venue: {}", venueId);
        Venue venue = getVenueEntityById(venueId);
        venue.setApproved(true);
        venue = venueRepository.save(venue);
        log.info("Venue approved: {}", venueId);
        return toResponseWithTurfCount(venue);
    }

    public PageResponse<VenueResponse> getAllVenuesAdmin(Pageable pageable) {
        log.debug("Admin fetching all venues");
        Page<Venue> page = venueRepository.findAll(pageable);
        List<VenueResponse> content = page.getContent().stream()
                .map(this::toResponseWithTurfCount)
                .toList();
        return PageResponse.<VenueResponse>builder()
                .content(content)
                .page(page.getNumber())
                .size(page.getSize())
                .totalElements(page.getTotalElements())
                .totalPages(page.getTotalPages())
                .last(page.isLast())
                .build();
    }

    private Venue getVenueEntityById(String id) {
        return venueRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Venue", "id", id));
    }

    private void verifyOwnership(Venue venue, String ownerId) {
        if (!venue.getOwnerId().equals(ownerId)) {
            throw new UnauthorizedException("You do not have permission to modify this venue");
        }
    }

    private VenueResponse toResponseWithTurfCount(Venue venue) {
        VenueResponse response = venueMapper.toResponse(venue);
        int count = turfRepository.findByVenueIdAndActiveTrue(venue.getId()).size();
        response.setTurfCount(count);
        return response;
    }

    private PageResponse<VenueResponse> toPageResponse(List<Venue> all, Pageable pageable) {
        int start = (int) pageable.getOffset();
        int end = Math.min(start + pageable.getPageSize(), all.size());
        List<Venue> pageContent = start >= all.size() ? List.of() : all.subList(start, end);

        List<VenueResponse> content = pageContent.stream()
                .map(this::toResponseWithTurfCount)
                .toList();

        return PageResponse.<VenueResponse>builder()
                .content(content)
                .page(pageable.getPageNumber())
                .size(pageable.getPageSize())
                .totalElements(all.size())
                .totalPages((int) Math.ceil((double) all.size() / pageable.getPageSize()))
                .last(end >= all.size())
                .build();
    }
}
