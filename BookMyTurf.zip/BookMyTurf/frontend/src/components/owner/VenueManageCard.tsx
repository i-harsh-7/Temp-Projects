import React from 'react';
import { View, Text, Switch, Pressable } from 'react-native';
import { Image } from 'expo-image';
import { Ionicons } from '@expo/vector-icons';
import { Venue } from '@/types';

interface VenueManageCardProps {
  venue: Venue;
  onEdit: (venue: Venue) => void;
  onDelete: (venue: Venue) => void;
  onToggleActive: (venue: Venue) => void;
  onManageTurfs: (venue: Venue) => void;
}

const VenueManageCard: React.FC<VenueManageCardProps> = ({
  venue,
  onEdit,
  onDelete,
  onToggleActive,
  onManageTurfs,
}) => {
  const thumbnail = venue.images && venue.images.length > 0 ? venue.images[0] : null;
  const visibleSports = venue.sports.slice(0, 2);
  const extraSports = venue.sports.length - 2;

  return (
    <View className="bg-dark-100 rounded-2xl overflow-hidden mb-3">
      {/* Main content row */}
      <View className="p-4">
        <View className="flex-row items-center">
          {/* Thumbnail */}
          <View
            style={{ width: 60, height: 60, borderRadius: 12, overflow: 'hidden' }}
            className="bg-dark-200 items-center justify-center mr-3"
          >
            {thumbnail ? (
              <Image
                source={{ uri: thumbnail }}
                style={{ width: 60, height: 60 }}
                contentFit="cover"
                transition={300}
              />
            ) : (
              <Ionicons name="business-outline" size={28} color="#6B7280" />
            )}
          </View>

          {/* Name / city / turf count */}
          <View className="flex-1 mr-2">
            <View className="flex-row items-center flex-wrap gap-2">
              <Text
                className="text-white font-semibold text-base flex-shrink"
                numberOfLines={1}
              >
                {venue.name}
              </Text>
              {/* Approval badge */}
              <View
                className={`px-2 py-0.5 rounded-full ${
                  venue.approved ? 'bg-green-500/20' : 'bg-amber-500/20'
                }`}
              >
                <Text
                  className={`text-xs font-medium ${
                    venue.approved ? 'text-green-400' : 'text-amber-400'
                  }`}
                >
                  {venue.approved ? 'Approved' : 'Pending'}
                </Text>
              </View>
            </View>

            <View className="flex-row items-center mt-0.5">
              <Ionicons name="location-outline" size={12} color="#6B7280" />
              <Text className="text-muted text-xs ml-0.5">{venue.city}</Text>
              <Text className="text-muted text-xs ml-2">
                {venue.turfCount} {venue.turfCount === 1 ? 'turf' : 'turfs'}
              </Text>
            </View>

            {/* Sports tags */}
            {venue.sports.length > 0 && (
              <View className="flex-row flex-wrap mt-1.5 gap-1">
                {visibleSports.map((sport) => (
                  <View key={sport} className="bg-dark-300 px-2 py-0.5 rounded-full">
                    <Text className="text-muted text-xs">{sport}</Text>
                  </View>
                ))}
                {extraSports > 0 && (
                  <View className="bg-dark-300 px-2 py-0.5 rounded-full">
                    <Text className="text-muted text-xs">+{extraSports} more</Text>
                  </View>
                )}
              </View>
            )}
          </View>

          {/* Active toggle */}
          <Switch
            value={venue.active}
            onValueChange={() => onToggleActive(venue)}
            trackColor={{ false: '#374151', true: '#1DB954' }}
            thumbColor="#FFFFFF"
          />
        </View>

        {/* Divider */}
        <View className="h-px bg-dark-300 mt-3 mb-3" />

        {/* Bottom row buttons */}
        <View className="flex-row items-center gap-2">
          {/* Manage Turfs button */}
          <Pressable
            onPress={() => onManageTurfs(venue)}
            className="flex-row items-center border border-primary rounded-lg px-3 py-1.5 flex-1 justify-center"
            style={({ pressed }) => ({ opacity: pressed ? 0.75 : 1 })}
          >
            <Ionicons name="football-outline" size={14} color="#1DB954" />
            <Text className="text-primary text-sm font-medium ml-1.5">Turfs</Text>
          </Pressable>

          {/* Edit button */}
          <Pressable
            onPress={() => onEdit(venue)}
            style={({ pressed }) => ({
              opacity: pressed ? 0.75 : 1,
              backgroundColor: '#252525',
              width: 36,
              height: 36,
              borderRadius: 18,
              alignItems: 'center',
              justifyContent: 'center',
            })}
          >
            <Ionicons name="pencil-outline" size={16} color="#FFFFFF" />
          </Pressable>

          {/* Delete button */}
          <Pressable
            onPress={() => onDelete(venue)}
            style={({ pressed }) => ({
              opacity: pressed ? 0.75 : 1,
              backgroundColor: '#EF444419',
              width: 36,
              height: 36,
              borderRadius: 18,
              alignItems: 'center',
              justifyContent: 'center',
            })}
          >
            <Ionicons name="trash-outline" size={16} color="#EF4444" />
          </Pressable>
        </View>
      </View>
    </View>
  );
};

export default VenueManageCard;
