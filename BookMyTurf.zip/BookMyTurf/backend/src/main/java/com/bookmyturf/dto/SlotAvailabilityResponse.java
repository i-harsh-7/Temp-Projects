package com.bookmyturf.dto;

import lombok.*;

import java.time.LocalDate;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SlotAvailabilityResponse {

    private String turfId;

    private LocalDate date;

    private List<TimeSlot> availableSlots;
}
