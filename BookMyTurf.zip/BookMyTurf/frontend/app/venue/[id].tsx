import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  FlatList,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useVenueById } from '@/hooks/useVenues';
import { useTurfsByVenue } from '@/hooks/useTurfs';
import VenueCarousel from '@/components/venue/VenueCarousel';
import TurfCard from '@/components/turf/TurfCard';
import SkeletonLoader, { SkeletonBlock } from '@/components/common/SkeletonLoader';
import ErrorScreen from '@/components/common/ErrorScreen';
import EmptyState from '@/components/common/EmptyState';
import { SPORT_COLORS } from '@/utils/constants';
import { truncateText } from '@/utils/helpers';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

const AMENITY_ICONS: Record<string, React.ComponentProps<typeof Ionicons>['name']> = {
  Parking: 'car-outline',
  'Changing Room': 'shirt-outline',
  Cafeteria: 'restaurant-outline',
  Floodlights: 'flashlight-outline',
  'First Aid': 'medkit-outline',
  Washrooms: 'water-outline',
  'Drinking Water': 'water-outline',
  CCTV: 'videocam-outline',
  'Locker Room': 'lock-closed-outline',
  'Equipment Rental': 'basketball-outline',
};

export default function VenueDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const [descExpanded, setDescExpanded] = useState(false);

  const {
    data: venue,
    isLoading: venueLoading,
    error: venueError,
    refetch,
  } = useVenueById(id ?? '');

  const {
    data: turfs,
    isLoading: turfsLoading,
  } = useTurfsByVenue(id ?? '');

  if (venueLoading) {
    return (
      <SafeAreaView className="flex-1 bg-dark" edges={['top']}>
        <TouchableOpacity
          onPress={() => router.back()}
          className="absolute top-12 left-4 z-10 w-10 h-10 rounded-full bg-black/60 items-center justify-center"
        >
          <Ionicons name="arrow-back" size={20} color="#fff" />
        </TouchableOpacity>
        <ScrollView className="flex-1">
          <SkeletonBlock width={SCREEN_WIDTH} height={280} borderRadius={0} />
          <View className="px-5 pt-4">
            <SkeletonBlock width="70%" height={24} borderRadius={6} />
            <View className="mt-2">
              <SkeletonBlock width="45%" height={16} borderRadius={6} />
            </View>
            <View className="flex-row gap-2 mt-4">
              <SkeletonBlock width={70} height={28} borderRadius={14} />
              <SkeletonBlock width={70} height={28} borderRadius={14} />
            </View>
            <View className="mt-4">
              <SkeletonBlock width="100%" height={80} borderRadius={8} />
            </View>
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }

  if (venueError || !venue) {
    return (
      <SafeAreaView className="flex-1 bg-dark" edges={['top']}>
        <TouchableOpacity
          onPress={() => router.back()}
          className="absolute top-12 left-4 z-10 w-10 h-10 rounded-full bg-black/60 items-center justify-center"
        >
          <Ionicons name="arrow-back" size={20} color="#fff" />
        </TouchableOpacity>
        <ErrorScreen
          message="Could not load venue details."
          onRetry={refetch}
        />
      </SafeAreaView>
    );
  }

  const description = venue.description ?? '';
  const shouldTruncate = description.length > 160;
  const displayDesc =
    shouldTruncate && !descExpanded
      ? truncateText(description, 160)
      : description;

  const turfList = turfs ?? [];

  return (
    <SafeAreaView className="flex-1 bg-dark" edges={['bottom']}>
      <ScrollView
        className="flex-1"
        showsVerticalScrollIndicator={false}
        stickyHeaderIndices={[0]}
      >
        {/* Sticky back button */}
        <View className="absolute top-0 left-0 right-0 z-10 px-4 pt-12 pb-4 pointer-events-none">
          <TouchableOpacity
            onPress={() => router.back()}
            className="w-10 h-10 rounded-full bg-black/60 items-center justify-center"
          >
            <Ionicons name="arrow-back" size={20} color="#fff" />
          </TouchableOpacity>
        </View>

        {/* Image Carousel */}
        <VenueCarousel images={venue.images} height={280} />

        {/* Content */}
        <View className="px-5 pt-4 pb-32">
          {/* Name + location */}
          <View className="flex-row items-start justify-between">
            <View className="flex-1 mr-3">
              <Text className="text-white text-2xl font-bold">{venue.name}</Text>
              <View className="flex-row items-center mt-1.5">
                <Ionicons name="location-outline" size={14} color="#6B7280" />
                <Text className="text-muted text-sm ml-1 flex-1" numberOfLines={2}>
                  {venue.address}, {venue.city}
                </Text>
              </View>
            </View>
            {/* Rating placeholder */}
            <View className="bg-dark-200 rounded-xl px-3 py-2 items-center">
              <View className="flex-row items-center">
                <Ionicons name="star" size={14} color="#F59E0B" />
                <Text className="text-white text-sm font-bold ml-1">4.5</Text>
              </View>
              <Text className="text-muted text-xs mt-0.5">Rating</Text>
            </View>
          </View>

          {/* Sports chips */}
          <View className="flex-row flex-wrap gap-2 mt-4">
            {venue.sports.map((sport) => {
              const color = SPORT_COLORS[sport] ?? '#1DB954';
              return (
                <View
                  key={sport}
                  className="rounded-full px-3 py-1.5"
                  style={{
                    backgroundColor: `${color}20`,
                    borderWidth: 1,
                    borderColor: `${color}60`,
                  }}
                >
                  <Text className="text-sm font-medium" style={{ color }}>
                    {sport}
                  </Text>
                </View>
              );
            })}
          </View>

          {/* Amenities */}
          {venue.amenities.length > 0 && (
            <View className="mt-5">
              <Text className="text-white text-base font-bold mb-3">Amenities</Text>
              <View className="flex-row flex-wrap gap-3">
                {venue.amenities.map((amenity) => (
                  <View
                    key={amenity}
                    className="flex-row items-center bg-dark-200 rounded-xl px-3 py-2"
                  >
                    <Ionicons
                      name={AMENITY_ICONS[amenity] ?? 'checkmark-circle-outline'}
                      size={15}
                      color="#1DB954"
                    />
                    <Text className="text-white text-xs ml-1.5 font-medium">
                      {amenity}
                    </Text>
                  </View>
                ))}
              </View>
            </View>
          )}

          {/* Description */}
          {description.length > 0 && (
            <View className="mt-5">
              <Text className="text-white text-base font-bold mb-2">About</Text>
              <Text className="text-muted text-sm leading-6">{displayDesc}</Text>
              {shouldTruncate && (
                <TouchableOpacity
                  onPress={() => setDescExpanded((e) => !e)}
                  className="mt-1"
                >
                  <Text className="text-primary text-sm font-medium">
                    {descExpanded ? 'Read less' : 'Read more'}
                  </Text>
                </TouchableOpacity>
              )}
            </View>
          )}

          {/* Divider */}
          <View className="h-px bg-dark-300 my-5" />

          {/* Turfs section */}
          <View>
            <View className="flex-row items-center justify-between mb-3">
              <Text className="text-white text-base font-bold">
                Available Turfs ({turfList.length})
              </Text>
            </View>

            {turfsLoading ? (
              <SkeletonLoader variant="card" count={2} />
            ) : turfList.length === 0 ? (
              <EmptyState
                icon="football-outline"
                title="No turfs available"
                subtitle="This venue has no active turfs yet"
              />
            ) : (
              turfList.map((turf) => (
                <TurfCard
                  key={turf.id}
                  turf={turf}
                  onPress={() => router.push(`/turf/${turf.id}`)}
                />
              ))
            )}
          </View>
        </View>
      </ScrollView>

      {/* Floating Book Now button */}
      {turfList.length > 0 && (
        <View className="absolute bottom-0 left-0 right-0 px-5 pb-6 pt-3 bg-dark border-t border-dark-200">
          <TouchableOpacity
            onPress={() =>
              router.push({
                pathname: '/booking/slot-selection',
                params: { venueId: venue.id, turfId: turfList[0].id },
              })
            }
            className="bg-primary py-4 rounded-2xl items-center flex-row justify-center"
            activeOpacity={0.85}
          >
            <Ionicons name="calendar-outline" size={20} color="#fff" />
            <Text className="text-white text-base font-bold ml-2">Book Now</Text>
          </TouchableOpacity>
        </View>
      )}
    </SafeAreaView>
  );
}
