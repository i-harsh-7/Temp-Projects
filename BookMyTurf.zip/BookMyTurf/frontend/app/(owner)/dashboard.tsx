import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  RefreshControl,
  TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useQueryClient } from '@tanstack/react-query';
import Toast from 'react-native-toast-message';

import { useAuthStore } from '@/store/authStore';
import { useMyVenues, useDeleteVenue } from '@/hooks/useVenues';
import { getInitials } from '@/utils/helpers';
import { QUERY_KEYS } from '@/utils/constants';
import { venueService } from '@/services/venueService';
import { Venue } from '@/types';

import StatsCard from '@/components/owner/StatsCard';
import VenueManageCard from '@/components/owner/VenueManageCard';
import SkeletonLoader from '@/components/common/SkeletonLoader';
import EmptyState from '@/components/common/EmptyState';
import ConfirmDialog from '@/components/common/ConfirmDialog';
import CustomButton from '@/components/common/CustomButton';

export default function OwnerDashboard() {
  const router = useRouter();
  const queryClient = useQueryClient();

  const user = useAuthStore((s) => s.user);
  const { data: venues = [], isLoading, refetch } = useMyVenues();
  const { mutateAsync: deleteVenue, isPending: isDeleting } = useDeleteVenue();

  const [refreshing, setRefreshing] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Venue | null>(null);
  const [togglingId, setTogglingId] = useState<string | null>(null);

  const greeting = (() => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  })();

  const totalTurfs = venues.reduce((sum, v) => sum + (v.turfCount ?? 0), 0);

  const onRefresh = async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  };

  const handleToggleActive = async (venue: Venue) => {
    if (togglingId === venue.id) return;
    setTogglingId(venue.id);
    try {
      await venueService.toggleVenueActive(venue.id);
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.MY_VENUES] });
    } catch {
      Toast.show({ type: 'error', text1: 'Failed to update venue status' });
    } finally {
      setTogglingId(null);
    }
  };

  const handleDeleteConfirm = async () => {
    if (!deleteTarget) return;
    try {
      await deleteVenue(deleteTarget.id);
      Toast.show({
        type: 'success',
        text1: 'Venue deleted',
        text2: `${deleteTarget.name} has been removed.`,
      });
    } catch {
      Toast.show({ type: 'error', text1: 'Failed to delete venue' });
    } finally {
      setDeleteTarget(null);
    }
  };

  const previewVenues = venues.slice(0, 3);

  return (
    <SafeAreaView className="flex-1 bg-dark">
      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingBottom: 32 }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor="#1DB954"
            colors={['#1DB954']}
          />
        }
      >
        {/* Header */}
        <View className="flex-row items-center justify-between px-4 pt-4 pb-6">
          <View className="flex-1">
            <Text className="text-muted text-sm">{greeting},</Text>
            <Text className="text-white text-2xl font-bold mt-0.5">
              {user?.name ?? 'Owner'}
            </Text>
            <Text className="text-muted text-xs mt-0.5">Venue Owner</Text>
          </View>

          {/* Avatar */}
          <View
            style={{
              width: 48,
              height: 48,
              borderRadius: 24,
              backgroundColor: '#1DB954',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Text style={{ color: '#FFFFFF', fontWeight: '700', fontSize: 16 }}>
              {getInitials(user?.name ?? 'O')}
            </Text>
          </View>
        </View>

        {/* Stats Row */}
        <View className="px-4 mb-6">
          <Text className="text-white text-lg font-bold mb-3">Overview</Text>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ gap: 12 }}
          >
            <View style={{ width: 130 }}>
              <StatsCard
                icon="business-outline"
                label="Total Venues"
                value={isLoading ? '—' : venues.length}
                color="#1DB954"
              />
            </View>
            <View style={{ width: 130 }}>
              <StatsCard
                icon="football-outline"
                label="Total Turfs"
                value={isLoading ? '—' : totalTurfs}
                color="#FF6B35"
              />
            </View>
            <View style={{ width: 130 }}>
              <StatsCard
                icon="calendar-outline"
                label="Today's Bookings"
                value="—"
                color="#3B82F6"
              />
            </View>
            <View style={{ width: 130 }}>
              <StatsCard
                icon="cash-outline"
                label="Revenue"
                value="—"
                color="#8B5CF6"
              />
            </View>
          </ScrollView>
        </View>

        {/* My Venues Section */}
        <View className="px-4 mb-6">
          <View className="flex-row items-center justify-between mb-3">
            <Text className="text-white text-lg font-bold">My Venues</Text>
            {venues.length > 3 && (
              <TouchableOpacity
                onPress={() => router.push('/(owner)/venues' as any)}
                activeOpacity={0.7}
              >
                <Text className="text-primary text-sm font-medium">
                  View All
                </Text>
              </TouchableOpacity>
            )}
          </View>

          {isLoading ? (
            <SkeletonLoader variant="list" count={3} />
          ) : previewVenues.length === 0 ? (
            <EmptyState
              icon="business-outline"
              title="No venues yet"
              subtitle="Add your first venue to get started."
              actionLabel="Add Venue"
              onAction={() => router.push('/(owner)/venues/create' as any)}
            />
          ) : (
            previewVenues.map((venue) => (
              <VenueManageCard
                key={venue.id}
                venue={venue}
                onEdit={(v) =>
                  router.push(`/(owner)/venues/${v.id}/edit` as any)
                }
                onDelete={(v) => setDeleteTarget(v)}
                onToggleActive={handleToggleActive}
                onManageTurfs={(v) =>
                  router.push(`/(owner)/venues/${v.id}/turfs` as any)
                }
              />
            ))
          )}

          {!isLoading && venues.length > 3 && (
            <TouchableOpacity
              onPress={() => router.push('/(owner)/venues' as any)}
              className="items-center py-3 border border-dark-300 rounded-xl mt-2"
              activeOpacity={0.7}
            >
              <Text className="text-muted text-sm">
                +{venues.length - 3} more venues
              </Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Quick Actions */}
        <View className="px-4">
          <Text className="text-white text-lg font-bold mb-3">
            Quick Actions
          </Text>
          <View className="flex-row gap-3">
            <View className="flex-1">
              <CustomButton
                title="Add Venue"
                onPress={() => router.push('/(owner)/venues/create' as any)}
                variant="primary"
                fullWidth
                icon={
                  <Ionicons name="add-circle-outline" size={18} color="#fff" />
                }
              />
            </View>
            <View className="flex-1">
              <CustomButton
                title="View Bookings"
                onPress={() => router.push('/(owner)/bookings')}
                variant="outline"
                fullWidth
                icon={
                  <Ionicons
                    name="calendar-outline"
                    size={18}
                    color="#1DB954"
                  />
                }
              />
            </View>
          </View>
        </View>
      </ScrollView>

      <ConfirmDialog
        visible={!!deleteTarget}
        title="Delete Venue"
        message={`Are you sure you want to delete "${deleteTarget?.name}"? This action cannot be undone.`}
        confirmLabel="Delete"
        cancelLabel="Cancel"
        destructive
        loading={isDeleting}
        onConfirm={handleDeleteConfirm}
        onCancel={() => setDeleteTarget(null)}
      />
    </SafeAreaView>
  );
}
