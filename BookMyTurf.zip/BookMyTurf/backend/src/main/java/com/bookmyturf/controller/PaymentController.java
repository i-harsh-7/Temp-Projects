package com.bookmyturf.controller;

import com.bookmyturf.dto.*;
import com.bookmyturf.security.CustomUserDetails;
import com.bookmyturf.service.PaymentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
@Slf4j
public class PaymentController {

    private final PaymentService paymentService;

    @PostMapping("/create-order")
    public ResponseEntity<ApiResponse<PaymentOrderResponse>> createOrder(
            @RequestBody Map<String, String> body,
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        String bookingId = body.get("bookingId");
        PaymentOrderResponse response = paymentService.createRazorpayOrder(bookingId, userDetails.getId());
        return ResponseEntity.ok(ApiResponse.success("Payment order created", response));
    }

    @PostMapping("/verify")
    public ResponseEntity<ApiResponse<BookingResponse>> verifyPayment(
            @Valid @RequestBody PaymentVerificationRequest req,
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        BookingResponse response = paymentService.verifyAndCompletePayment(req, userDetails.getId());
        return ResponseEntity.ok(ApiResponse.success("Payment verified and booking confirmed", response));
    }

    @PostMapping("/failure")
    public ResponseEntity<ApiResponse<Void>> handleFailure(@RequestBody Map<String, String> body) {
        String razorpayOrderId = body.get("razorpayOrderId");
        paymentService.handlePaymentFailure(razorpayOrderId);
        return ResponseEntity.ok(ApiResponse.success("Payment failure recorded"));
    }
}
