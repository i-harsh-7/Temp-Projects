# Setup Guide

This guide walks you through running **BookMyTurf** locally from scratch — backend (Spring Boot) and
frontend (React Native / Expo).

---

## Prerequisites

| Tool | Version | Install link |
| --- | --- | --- |
| Java JDK | 21 | https://adoptium.net/ |
| Maven | 3.9+ | https://maven.apache.org/install.html |
| Node.js | 18+ | https://nodejs.org/ |
| MongoDB | 6+ | https://www.mongodb.com/try/download/community |
| Redis | 7+ | https://redis.io/download / Docker |
| Expo CLI | bundled | `npx expo` (no global install needed) |
| Cloudinary | account | https://cloudinary.com/users/register/free |
| Razorpay | test account | https://dashboard.razorpay.com/signup |

Verify your toolchain:

```bash
java -version     # should report 21
mvn -version
node -v           # should be >= 18
```

---

## Step 1 — Clone & environment setup

```bash
git clone <your-repo-url> BookMyTurf
cd BookMyTurf
```

The repository has two apps:

```
BookMyTurf/
├── backend/    # Spring Boot 3, Java 21
└── frontend/   # React Native, Expo
```

Both ship with a `.env.example` you will copy and fill in (`backend/.env.example`,
`frontend/.env.example`).

---

## Step 2 — MongoDB setup

BookMyTurf uses a database named `bookmyturf`. Collections are created automatically on first write.

### Option A — Local MongoDB

Install MongoDB Community Server, then start it:

```bash
# macOS (Homebrew)
brew services start mongodb-community

# Linux (systemd)
sudo systemctl start mongod

# Windows
net start MongoDB
```

Default connection string:

```
mongodb://localhost:27017/bookmyturf
```

### Option B — MongoDB Atlas (cloud)

1. Create a free cluster at https://www.mongodb.com/cloud/atlas
2. Create a database user and whitelist your IP (or `0.0.0.0/0` for dev).
3. Copy the connection string and append the database name:

```
mongodb+srv://<user>:<password>@<cluster>.mongodb.net/bookmyturf?retryWrites=true&w=majority
```

Set this as `MONGO_URI`.

---

## Step 3 — Redis setup

Redis is **required** — it backs the distributed slot lock that prevents double-booking.

### Option A — Docker (recommended)

```bash
docker run -d --name bookmyturf-redis -p 6379:6379 redis
```

### Option B — Local install

```bash
# macOS
brew install redis && brew services start redis

# Linux
sudo apt-get install redis-server && sudo systemctl start redis

# Windows: use Docker or WSL2
```

Verify:

```bash
redis-cli ping     # -> PONG
```

Defaults: `REDIS_HOST=localhost`, `REDIS_PORT=6379`.

---

## Step 4 — Cloudinary account + credentials

Image uploads (venue, turf, avatar) are stored on Cloudinary.

1. Create a free account at https://cloudinary.com/users/register/free
2. Open the **Dashboard** — you will see your **Cloud Name**, **API Key**, and **API Secret**.
3. Note the three values for the backend env vars:
   - `CLOUDINARY_CLOUD_NAME`
   - `CLOUDINARY_API_KEY`
   - `CLOUDINARY_API_SECRET`

Images are uploaded into folders `venues/`, `turfs/`, and `avatars/`.

---

## Step 5 — Razorpay test account + test keys

1. Sign up at https://dashboard.razorpay.com/signup
2. Stay in **Test Mode** (toggle in the dashboard).
3. Go to **Settings → API Keys → Generate Test Key**.
4. Copy the **Key Id** (`rzp_test_...`) and **Key Secret**:
   - `RAZORPAY_KEY_ID`
   - `RAZORPAY_KEY_SECRET`

The backend uses the secret both to create orders and to verify the HMAC-SHA256 payment signature.

---

## Step 6 — Backend setup

The backend reads configuration from `backend/src/main/resources/application.yml`, which pulls values from
**environment variables** with sensible local defaults. You have two equivalent options:

- **(A)** Export the variables in your shell / set system env vars, or
- **(B)** Use a `backend/.env` file (copy from `.env.example`) and load it into your environment.

> The app does not auto-load a `.env`; either export the vars, source the `.env`, or pass them via your
> IDE's run configuration. Local defaults exist for Mongo/Redis/JWT so you only strictly need the
> Cloudinary and Razorpay values to exercise image upload and payments.

### Exact environment variables (from `application.yml`)

| Variable | Default | Required |
| --- | --- | --- |
| `MONGO_URI` | `mongodb://localhost:27017/bookmyturf` | for non-default DB |
| `REDIS_HOST` | `localhost` | no |
| `REDIS_PORT` | `6379` | no |
| `JWT_SECRET` | dev default (do **not** use in prod) | yes (prod) |
| `JWT_EXPIRY` | `900000` (15 min, ms) | no |
| `JWT_REFRESH_EXPIRY` | `604800000` (7 days, ms) | no |
| `CLOUDINARY_CLOUD_NAME` | _(empty)_ | for image upload |
| `CLOUDINARY_API_KEY` | _(empty)_ | for image upload |
| `CLOUDINARY_API_SECRET` | _(empty)_ | for image upload |
| `RAZORPAY_KEY_ID` | _(empty)_ | for payments |
| `RAZORPAY_KEY_SECRET` | _(empty)_ | for payments |

### Build & run

```bash
cd backend

# (Option B) load .env into the current shell, e.g.:
#   set -a && source .env && set +a

mvn clean install        # compile + run tests + package
mvn spring-boot:run      # starts the API
```

The server starts on **http://localhost:8080** with context path **`/api`**, so the base URL is
**http://localhost:8080/api**.

---

## Step 7 — Frontend setup

```bash
cd frontend
npm install
cp .env.example .env
```

Edit `frontend/.env`:

```env
EXPO_PUBLIC_API_URL=http://localhost:8080/api
```

> **On a physical device**, `localhost` points to the phone, not your computer. Use your machine's LAN IP,
> e.g. `EXPO_PUBLIC_API_URL=http://192.168.1.50:8080/api`. For the Android emulator use
> `http://10.0.2.2:8080/api`.

Start Expo:

```bash
npx expo start
```

Press `a` (Android emulator), `i` (iOS simulator), or scan the QR code with **Expo Go**.

---

## Step 8 — Verify the setup

1. **Backend up?**

   ```bash
   curl http://localhost:8080/api/actuator/health
   # or hit a public endpoint:
   curl "http://localhost:8080/api/venues/public?page=0&size=10"
   ```

2. **Swagger UI** (interactive API docs):

   ```
   http://localhost:8080/api/swagger-ui.html
   ```

3. **Register a user** to confirm Mongo connectivity:

   ```bash
   curl -X POST http://localhost:8080/api/auth/register \
     -H "Content-Type: application/json" \
     -d '{"name":"Test User","email":"test@example.com","password":"password123","phone":"9876543210","role":"CUSTOMER"}'
   ```

4. **Frontend** launches into onboarding/login and can register/login against the API.

---

## Commands reference

### Backend

```bash
cd backend
mvn clean install        # build + test
mvn spring-boot:run      # run the API (http://localhost:8080/api)
mvn test                 # run tests only
```

### Frontend

```bash
cd frontend
npm install              # install dependencies
npx expo start           # start the dev server / Metro bundler
npm run android          # open on Android
npm run ios              # open on iOS
npm run web              # open in browser
npm run lint             # lint
```

---

## Troubleshooting

| Symptom | Cause | Fix |
| --- | --- | --- |
| `MongoSocketOpenException` / app won't start | MongoDB not running or wrong `MONGO_URI` | Start MongoDB; verify the URI includes `/bookmyturf`; for Atlas check IP whitelist & credentials. |
| `Unable to connect to Redis` / lock failures | Redis not running | `docker run -d -p 6379:6379 redis` or start local Redis; check `REDIS_HOST`/`REDIS_PORT`. |
| Frontend requests fail / network error | Wrong `EXPO_PUBLIC_API_URL` | On a device use LAN IP, on Android emulator use `10.0.2.2`; ensure backend is running. Restart Expo after changing `.env`. |
| CORS error in browser/web | Origin blocked | The backend allows all origins by default (`setAllowedOriginPatterns("*")`). Confirm you are hitting `/api` and the server is up. |
| `Failed to create payment order` | Missing/invalid Razorpay keys | Set `RAZORPAY_KEY_ID` / `RAZORPAY_KEY_SECRET` from the **Test Mode** dashboard. |
| `Payment signature verification failed` | Key secret mismatch or tampered payload | Ensure the same `RAZORPAY_KEY_SECRET` is configured; the signature is HMAC-SHA256 of `orderId|paymentId`. |
| `Failed to upload image` | Missing/invalid Cloudinary creds | Set `CLOUDINARY_CLOUD_NAME` / `CLOUDINARY_API_KEY` / `CLOUDINARY_API_SECRET`. |
| `401 Unauthorized` on protected routes | Missing/expired access token | Send `Authorization: Bearer <accessToken>`; the app auto-refreshes via `/auth/refresh`. |
| `Slot temporarily locked` | Another payment in progress for the same slot | Wait — the Redis lock has a 5-minute TTL and releases on confirm/cancel/expiry. |