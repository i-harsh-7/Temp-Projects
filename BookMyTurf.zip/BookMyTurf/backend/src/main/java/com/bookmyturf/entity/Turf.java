package com.bookmyturf.entity;

import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalTime;
import java.util.List;

@Document("turfs")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Turf {

    @Id
    private String id;

    private String venueId;

    private String name;

    private String sport;

    private BigDecimal pricePerHour;

    private LocalTime openingTime;

    private LocalTime closingTime;

    private List<String> images;

    private List<String> amenities;

    @Builder.Default
    private boolean active = true;

    @CreatedDate
    private Instant createdAt;

    @LastModifiedDate
    private Instant updatedAt;
}
