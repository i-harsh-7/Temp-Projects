import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  TextInput,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import Toast from 'react-native-toast-message';

import { useCreateVenue, useUploadVenueImages } from '@/hooks/useVenues';
import { CITIES, SPORTS, AMENITIES } from '@/utils/constants';

import CustomButton from '@/components/common/CustomButton';
import CustomInput from '@/components/common/CustomInput';
import MultiSelect from '@/components/common/MultiSelect';
import ImageUploader from '@/components/common/ImageUploader';
import ProgressSteps from '@/components/common/ProgressSteps';

// ---------------------------------------------------------------------------
// Schema
// ---------------------------------------------------------------------------
const schema = z.object({
  name: z.string().min(3, 'Name must be at least 3 characters'),
  description: z.string().min(10, 'Description must be at least 10 characters'),
  address: z.string().min(5, 'Address is required'),
  city: z.string().min(1, 'City is required'),
  sports: z.array(z.string()).min(1, 'Select at least one sport'),
  amenities: z.array(z.string()),
  latitude: z.number({ invalid_type_error: 'Enter a valid number' }),
  longitude: z.number({ invalid_type_error: 'Enter a valid number' }),
});

type FormValues = z.infer<typeof schema>;

const STEPS = ['Basic Info', 'Details', 'Location'];

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------
export default function CreateVenueScreen() {
  const router = useRouter();
  const [currentStep, setCurrentStep] = useState(0);
  const [images, setImages] = useState<string[]>([]);

  const { mutateAsync: createVenue, isPending: isCreating } = useCreateVenue();
  const { mutateAsync: uploadImages, isPending: isUploading } =
    useUploadVenueImages();

  const {
    control,
    handleSubmit,
    trigger,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      name: '',
      description: '',
      address: '',
      city: '',
      sports: [],
      amenities: [],
      latitude: undefined as unknown as number,
      longitude: undefined as unknown as number,
    },
  });

  // -------------------------------------------------------------------------
  // Step validation
  // -------------------------------------------------------------------------
  const stepFields: (keyof FormValues)[][] = [
    ['name', 'description', 'address', 'city'],
    ['sports', 'amenities'],
    ['latitude', 'longitude'],
  ];

  const handleNext = async () => {
    const valid = await trigger(stepFields[currentStep]);
    if (valid) setCurrentStep((s) => s + 1);
  };

  const handlePrev = () => {
    if (currentStep > 0) setCurrentStep((s) => s - 1);
    else router.back();
  };

  // -------------------------------------------------------------------------
  // Submit
  // -------------------------------------------------------------------------
  const onSubmit = async (values: FormValues) => {
    try {
      const result = await createVenue({
        name: values.name,
        description: values.description,
        address: values.address,
        city: values.city,
        sports: values.sports,
        amenities: values.amenities,
        latitude: values.latitude,
        longitude: values.longitude,
      });

      const venueId = result.data?.id;

      if (venueId && images.length > 0) {
        try {
          const formData = new FormData();
          images.forEach((uri, idx) => {
            const filename = uri.split('/').pop() ?? `image_${idx}.jpg`;
            const ext = filename.split('.').pop() ?? 'jpg';
            formData.append('files', {
              uri,
              name: filename,
              type: `image/${ext}`,
            } as any);
          });
          await uploadImages({ id: venueId, files: formData });
        } catch {
          // Images upload failure should not block success
        }
      }

      Toast.show({
        type: 'success',
        text1: 'Venue created!',
        text2: 'It will be reviewed before going live.',
      });
      router.replace('/(owner)/venues' as any);
    } catch (err: any) {
      Toast.show({
        type: 'error',
        text1: 'Failed to create venue',
        text2: err?.message ?? 'Please try again.',
      });
    }
  };

  const isSubmitting = isCreating || isUploading;

  // -------------------------------------------------------------------------
  // Render helpers
  // -------------------------------------------------------------------------
  const renderStep0 = () => (
    <View>
      <Controller
        control={control}
        name="name"
        render={({ field: { value, onChange, onBlur } }) => (
          <CustomInput
            label="Venue Name"
            placeholder="e.g. Green Park Sports Arena"
            value={value}
            onChangeText={onChange}
            onBlur={onBlur}
            error={errors.name?.message}
          />
        )}
      />

      <View className="mb-4">
        <Text className="text-white text-sm font-medium mb-1.5">
          Description
        </Text>
        <Controller
          control={control}
          name="description"
          render={({ field: { value, onChange, onBlur } }) => (
            <View
              style={{
                backgroundColor: '#1A1A1A',
                borderWidth: 1,
                borderColor: errors.description ? '#EF4444' : '#374151',
                borderRadius: 12,
                paddingHorizontal: 16,
                paddingVertical: 12,
              }}
            >
              <TextInput
                value={value}
                onChangeText={onChange}
                onBlur={onBlur}
                placeholder="Describe your venue, facilities, and what makes it special..."
                placeholderTextColor="#6B7280"
                multiline
                numberOfLines={4}
                textAlignVertical="top"
                style={{ color: '#FFFFFF', fontSize: 15, minHeight: 100 }}
                selectionColor="#1DB954"
              />
            </View>
          )}
        />
        {errors.description && (
          <View className="flex-row items-center mt-1.5">
            <Ionicons name="alert-circle-outline" size={14} color="#EF4444" />
            <Text className="text-red-400 text-xs ml-1">
              {errors.description.message}
            </Text>
          </View>
        )}
      </View>

      <Controller
        control={control}
        name="address"
        render={({ field: { value, onChange, onBlur } }) => (
          <CustomInput
            label="Address"
            placeholder="Full street address of the venue"
            value={value}
            onChangeText={onChange}
            onBlur={onBlur}
            error={errors.address?.message}
            leftIcon={
              <Ionicons name="location-outline" size={18} color="#6B7280" />
            }
          />
        )}
      />

      {/* City picker */}
      <View className="mb-4">
        <Text className="text-white text-sm font-medium mb-2">City</Text>
        <Controller
          control={control}
          name="city"
          render={({ field: { value, onChange } }) => (
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ gap: 8, paddingBottom: 4 }}
            >
              {CITIES.map((city) => {
                const selected = value === city;
                return (
                  <TouchableOpacity
                    key={city}
                    onPress={() => onChange(city)}
                    activeOpacity={0.75}
                    style={{
                      paddingHorizontal: 16,
                      paddingVertical: 8,
                      borderRadius: 999,
                      borderWidth: 1,
                      backgroundColor: selected ? '#1DB954' : '#1A1A1A',
                      borderColor: selected ? '#1DB954' : '#374151',
                    }}
                  >
                    <Text
                      style={{
                        color: selected ? '#FFFFFF' : '#6B7280',
                        fontSize: 13,
                        fontWeight: '500',
                      }}
                    >
                      {city}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </ScrollView>
          )}
        />
        {errors.city && (
          <View className="flex-row items-center mt-1.5">
            <Ionicons name="alert-circle-outline" size={14} color="#EF4444" />
            <Text className="text-red-400 text-xs ml-1">
              {errors.city.message}
            </Text>
          </View>
        )}
      </View>
    </View>
  );

  const renderStep1 = () => (
    <View>
      <View className="mb-5">
        <Controller
          control={control}
          name="sports"
          render={({ field: { value, onChange } }) => (
            <MultiSelect
              label="Sports Available"
              options={[...SPORTS]}
              selected={value}
              onToggle={(option) => {
                if (value.includes(option)) {
                  onChange(value.filter((s) => s !== option));
                } else {
                  onChange([...value, option]);
                }
              }}
            />
          )}
        />
        {errors.sports && (
          <View className="flex-row items-center mt-1.5">
            <Ionicons name="alert-circle-outline" size={14} color="#EF4444" />
            <Text className="text-red-400 text-xs ml-1">
              {errors.sports.message}
            </Text>
          </View>
        )}
      </View>

      <View className="mb-5">
        <Controller
          control={control}
          name="amenities"
          render={({ field: { value, onChange } }) => (
            <MultiSelect
              label="Amenities"
              options={[...AMENITIES]}
              selected={value}
              onToggle={(option) => {
                if (value.includes(option)) {
                  onChange(value.filter((a) => a !== option));
                } else {
                  onChange([...value, option]);
                }
              }}
            />
          )}
        />
      </View>

      <ImageUploader
        label="Venue Photos (optional)"
        images={images}
        onImagesChange={setImages}
        maxCount={5}
      />
    </View>
  );

  const renderStep2 = () => (
    <View>
      <Controller
        control={control}
        name="latitude"
        render={({ field: { value, onChange, onBlur } }) => (
          <CustomInput
            label="Latitude"
            placeholder="e.g. 19.0760"
            value={value !== undefined && !isNaN(value) ? String(value) : ''}
            onChangeText={(t) => {
              const n = parseFloat(t);
              onChange(isNaN(n) ? (undefined as unknown as number) : n);
            }}
            onBlur={onBlur}
            keyboardType="numeric"
            error={errors.latitude?.message}
            leftIcon={
              <Ionicons name="navigate-outline" size={18} color="#6B7280" />
            }
          />
        )}
      />

      <Controller
        control={control}
        name="longitude"
        render={({ field: { value, onChange, onBlur } }) => (
          <CustomInput
            label="Longitude"
            placeholder="e.g. 72.8777"
            value={value !== undefined && !isNaN(value) ? String(value) : ''}
            onChangeText={(t) => {
              const n = parseFloat(t);
              onChange(isNaN(n) ? (undefined as unknown as number) : n);
            }}
            onBlur={onBlur}
            keyboardType="numeric"
            error={errors.longitude?.message}
            leftIcon={
              <Ionicons name="navigate-outline" size={18} color="#6B7280" />
            }
          />
        )}
      />

      {/* Tip */}
      <View
        style={{
          backgroundColor: '#1A1A1A',
          borderRadius: 12,
          padding: 16,
          borderWidth: 1,
          borderColor: '#374151',
          flexDirection: 'row',
          gap: 10,
          marginTop: 4,
        }}
      >
        <Ionicons name="information-circle-outline" size={20} color="#1DB954" />
        <Text style={{ color: '#6B7280', fontSize: 13, lineHeight: 20, flex: 1 }}>
          <Text style={{ color: '#FFFFFF', fontWeight: '600' }}>Tip: </Text>
          Open Google Maps, long-press on your venue location, and copy the
          coordinates shown at the top of the screen.
        </Text>
      </View>
    </View>
  );

  // -------------------------------------------------------------------------
  // Layout
  // -------------------------------------------------------------------------
  return (
    <SafeAreaView className="flex-1 bg-dark">
      <KeyboardAvoidingView
        className="flex-1"
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={0}
      >
        {/* Header */}
        <View className="flex-row items-center px-4 pt-2 pb-4 border-b border-dark-300">
          <TouchableOpacity
            onPress={handlePrev}
            activeOpacity={0.7}
            style={{
              width: 40,
              height: 40,
              borderRadius: 20,
              backgroundColor: '#1A1A1A',
              alignItems: 'center',
              justifyContent: 'center',
              marginRight: 12,
            }}
          >
            <Ionicons name="arrow-back" size={20} color="#FFFFFF" />
          </TouchableOpacity>
          <Text className="text-white text-xl font-bold flex-1">
            Create Venue
          </Text>
        </View>

        {/* Progress */}
        <View className="px-4 py-4">
          <ProgressSteps steps={STEPS} currentStep={currentStep} />
        </View>

        {/* Form */}
        <ScrollView
          className="flex-1 px-4"
          contentContainerStyle={{ paddingBottom: 32 }}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <Text className="text-white text-lg font-bold mb-4">
            {STEPS[currentStep]}
          </Text>

          {currentStep === 0 && renderStep0()}
          {currentStep === 1 && renderStep1()}
          {currentStep === 2 && renderStep2()}
        </ScrollView>

        {/* Footer Buttons */}
        <View
          className="px-4 py-4 border-t border-dark-300"
          style={{ gap: 12 }}
        >
          {currentStep < STEPS.length - 1 ? (
            <CustomButton
              title="Next"
              onPress={handleNext}
              variant="primary"
              fullWidth
              icon={<Ionicons name="arrow-forward" size={18} color="#fff" />}
            />
          ) : (
            <CustomButton
              title={isSubmitting ? 'Submitting…' : 'Submit Venue'}
              onPress={handleSubmit(onSubmit)}
              variant="primary"
              fullWidth
              loading={isSubmitting}
              disabled={isSubmitting}
            />
          )}
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
