import React from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useTurfById } from '@/hooks/useTurfs';
import VenueCarousel from '@/components/venue/VenueCarousel';
import SkeletonLoader, { SkeletonBlock } from '@/components/common/SkeletonLoader';
import ErrorScreen from '@/components/common/ErrorScreen';
import { SPORT_COLORS } from '@/utils/constants';
import { formatCurrency, formatTime } from '@/utils/helpers';

const AMENITY_ICONS: Record<string, React.ComponentProps<typeof Ionicons>['name']> = {
  Parking: 'car-outline',
  'Changing Room': 'shirt-outline',
  Cafeteria: 'restaurant-outline',
  Floodlights: 'flashlight-outline',
  'First Aid': 'medkit-outline',
  Washrooms: 'water-outline',
  'Drinking Water': 'water-outline',
  CCTV: 'videocam-outline',
  'Locker Room': 'lock-closed-outline',
  'Equipment Rental': 'basketball-outline',
};

export default function TurfDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();

  const {
    data: turf,
    isLoading,
    error,
    refetch,
  } = useTurfById(id ?? '');

  if (isLoading) {
    return (
      <SafeAreaView className="flex-1 bg-dark" edges={['top']}>
        <ScrollView className="flex-1">
          <SkeletonBlock width="100%" height={260} borderRadius={0} />
          <View className="px-5 pt-4">
            <SkeletonBlock width="60%" height={22} borderRadius={6} />
            <View className="mt-2">
              <SkeletonBlock width="40%" height={16} borderRadius={6} />
            </View>
            <View className="mt-4">
              <SkeletonBlock width="100%" height={120} borderRadius={8} />
            </View>
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }

  if (error || !turf) {
    return (
      <SafeAreaView className="flex-1 bg-dark" edges={['top']}>
        <TouchableOpacity
          onPress={() => router.back()}
          className="absolute top-12 left-4 z-10 w-10 h-10 rounded-full bg-black/60 items-center justify-center"
        >
          <Ionicons name="arrow-back" size={20} color="#fff" />
        </TouchableOpacity>
        <ErrorScreen message="Could not load turf details." onRetry={refetch} />
      </SafeAreaView>
    );
  }

  const sportColor = SPORT_COLORS[turf.sport] ?? '#1DB954';

  return (
    <SafeAreaView className="flex-1 bg-dark" edges={['bottom']}>
      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        {/* Back button overlay */}
        <View className="absolute top-0 left-0 right-0 z-10 px-4 pt-12">
          <TouchableOpacity
            onPress={() => router.back()}
            className="w-10 h-10 rounded-full bg-black/60 items-center justify-center"
          >
            <Ionicons name="arrow-back" size={20} color="#fff" />
          </TouchableOpacity>
        </View>

        {/* Image carousel */}
        <VenueCarousel images={turf.images} height={260} />

        {/* Content */}
        <View className="px-5 pt-5 pb-32">
          {/* Name + sport badge */}
          <View className="flex-row items-start justify-between">
            <View className="flex-1 mr-3">
              <Text className="text-white text-2xl font-bold">{turf.name}</Text>
            </View>
            <View
              className="rounded-full px-3 py-1.5"
              style={{
                backgroundColor: `${sportColor}20`,
                borderWidth: 1,
                borderColor: `${sportColor}60`,
              }}
            >
              <Text className="text-sm font-semibold" style={{ color: sportColor }}>
                {turf.sport}
              </Text>
            </View>
          </View>

          {/* Price */}
          <View className="flex-row items-center mt-3">
            <Ionicons name="pricetag" size={18} color="#1DB954" />
            <Text className="text-primary text-xl font-bold ml-2">
              {formatCurrency(turf.pricePerHour)}
            </Text>
            <Text className="text-muted text-sm ml-1">/ hour</Text>
          </View>

          {/* Hours */}
          <View className="flex-row items-center mt-3 bg-dark-200 rounded-2xl px-4 py-3.5">
            <Ionicons name="time-outline" size={20} color="#1DB954" />
            <View className="ml-3">
              <Text className="text-muted text-xs">Opening Hours</Text>
              <Text className="text-white text-sm font-semibold mt-0.5">
                {formatTime(turf.openingTime)} – {formatTime(turf.closingTime)}
              </Text>
            </View>
          </View>

          {/* Active badge */}
          <View className="flex-row items-center mt-3">
            <View
              className="flex-row items-center rounded-full px-3 py-1.5"
              style={{
                backgroundColor: turf.active ? '#22C55E20' : '#6B728020',
                borderWidth: 1,
                borderColor: turf.active ? '#22C55E50' : '#6B728050',
              }}
            >
              <View
                className="w-2 h-2 rounded-full mr-1.5"
                style={{ backgroundColor: turf.active ? '#22C55E' : '#6B7280' }}
              />
              <Text
                className="text-xs font-semibold"
                style={{ color: turf.active ? '#22C55E' : '#6B7280' }}
              >
                {turf.active ? 'Available for Booking' : 'Currently Unavailable'}
              </Text>
            </View>
          </View>

          {/* Amenities */}
          {turf.amenities.length > 0 && (
            <View className="mt-5">
              <Text className="text-white text-base font-bold mb-3">Amenities</Text>
              <View className="flex-row flex-wrap gap-3">
                {turf.amenities.map((amenity) => (
                  <View
                    key={amenity}
                    className="flex-row items-center bg-dark-200 rounded-xl px-3 py-2"
                  >
                    <Ionicons
                      name={AMENITY_ICONS[amenity] ?? 'checkmark-circle-outline'}
                      size={15}
                      color="#1DB954"
                    />
                    <Text className="text-white text-xs ml-1.5 font-medium">
                      {amenity}
                    </Text>
                  </View>
                ))}
              </View>
            </View>
          )}

          {/* Info cards */}
          <View className="mt-5 flex-row gap-3">
            <View className="flex-1 bg-dark-200 rounded-2xl px-4 py-3.5">
              <Ionicons name="calendar-outline" size={20} color="#1DB954" />
              <Text className="text-muted text-xs mt-2">Slot Duration</Text>
              <Text className="text-white text-sm font-semibold mt-0.5">60 minutes</Text>
            </View>
            <View className="flex-1 bg-dark-200 rounded-2xl px-4 py-3.5">
              <Ionicons name="shield-checkmark-outline" size={20} color="#1DB954" />
              <Text className="text-muted text-xs mt-2">Instant</Text>
              <Text className="text-white text-sm font-semibold mt-0.5">Confirmation</Text>
            </View>
          </View>
        </View>
      </ScrollView>

      {/* Book CTA */}
      {turf.active && (
        <View className="absolute bottom-0 left-0 right-0 px-5 pb-6 pt-3 bg-dark border-t border-dark-200">
          <TouchableOpacity
            onPress={() =>
              router.push({
                pathname: '/booking/slot-selection',
                params: { turfId: turf.id, venueId: turf.venueId },
              })
            }
            className="bg-primary py-4 rounded-2xl flex-row items-center justify-center"
            activeOpacity={0.85}
          >
            <Ionicons name="calendar-outline" size={20} color="#fff" />
            <Text className="text-white text-base font-bold ml-2">Book This Turf</Text>
          </TouchableOpacity>
        </View>
      )}
    </SafeAreaView>
  );
}
