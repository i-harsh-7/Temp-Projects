package com.bookmyturf.dto;

import lombok.*;

import java.time.Instant;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VenueResponse {

    private String id;

    private String ownerId;

    private String name;

    private String address;

    private String city;

    private Double latitude;

    private Double longitude;

    private String description;

    private List<String> images;

    private List<String> amenities;

    private List<String> sports;

    private boolean approved;

    private boolean active;

    private Instant createdAt;

    private Instant updatedAt;

    private int turfCount;
}
