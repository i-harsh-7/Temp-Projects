import { useMutation } from '@tanstack/react-query';
import { router } from 'expo-router';
import { useAuthStore } from '@/store/authStore';
import { authService } from '@/services/authService';
import { LoginRequest, RegisterRequest } from '@/types';

export const useAuth = () => {
  const { user, accessToken, refreshToken, isAuthenticated, isLoading, setAuth, logout: storeLogout, updateUser, setLoading } =
    useAuthStore();

  const loginMutation = useMutation({
    mutationFn: (data: LoginRequest) => authService.login(data),
    onMutate: () => setLoading(true),
    onSuccess: (response) => {
      if (response.success && response.data) {
        const { user: authUser, accessToken: token, refreshToken: rToken } = response.data;
        setAuth(authUser, token, rToken);
        router.replace('/(tabs)');
      }
    },
    onError: () => setLoading(false),
    onSettled: () => setLoading(false),
  });

  const registerMutation = useMutation({
    mutationFn: (data: RegisterRequest) => authService.register(data),
    onMutate: () => setLoading(true),
    onSuccess: (response) => {
      if (response.success && response.data) {
        const { user: authUser, accessToken: token, refreshToken: rToken } = response.data;
        setAuth(authUser, token, rToken);
        router.replace('/(tabs)');
      }
    },
    onError: () => setLoading(false),
    onSettled: () => setLoading(false),
  });

  const logoutMutation = useMutation({
    mutationFn: () => {
      const token = refreshToken;
      if (token) {
        return authService.logout(token);
      }
      return Promise.resolve({ success: true, message: '', data: null, timestamp: '' });
    },
    onSettled: () => {
      storeLogout();
      router.replace('/(auth)/login');
    },
  });

  return {
    user,
    accessToken,
    isAuthenticated,
    isLoading,
    login: loginMutation.mutate,
    loginAsync: loginMutation.mutateAsync,
    loginError: loginMutation.error,
    isLoginLoading: loginMutation.isPending,
    register: registerMutation.mutate,
    registerAsync: registerMutation.mutateAsync,
    registerError: registerMutation.error,
    isRegisterLoading: registerMutation.isPending,
    logout: logoutMutation.mutate,
    isLogoutLoading: logoutMutation.isPending,
    updateUser,
  };
};
