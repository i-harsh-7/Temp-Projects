import React from 'react';
import {
  View,
  TextInput,
  TouchableOpacity,
  TextInputProps,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

interface SearchBarProps extends Omit<TextInputProps, 'value' | 'onChangeText'> {
  value: string;
  onChangeText: (text: string) => void;
  placeholder?: string;
  onClear?: () => void;
  onPress?: () => void;
  editable?: boolean;
}

const SearchBar: React.FC<SearchBarProps> = ({
  value,
  onChangeText,
  placeholder = 'Search venues, sports...',
  onClear,
  onPress,
  editable = true,
  ...rest
}) => {
  const handleClear = () => {
    onChangeText('');
    onClear?.();
  };

  return (
    <TouchableOpacity
      activeOpacity={editable ? 1 : 0.7}
      onPress={!editable ? onPress : undefined}
      className="flex-row items-center bg-dark-100 border border-dark-300 rounded-2xl px-4 h-12"
    >
      <Ionicons name="search-outline" size={18} color="#6B7280" />
      <TextInput
        className="flex-1 text-white text-base ml-2.5"
        placeholder={placeholder}
        placeholderTextColor="#6B7280"
        value={value}
        onChangeText={onChangeText}
        onPress={onPress}
        editable={editable}
        selectionColor="#1DB954"
        cursorColor="#1DB954"
        returnKeyType="search"
        {...rest}
      />
      {value.length > 0 && editable && (
        <TouchableOpacity
          onPress={handleClear}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
          className="ml-2 p-1"
        >
          <Ionicons name="close-circle" size={18} color="#6B7280" />
        </TouchableOpacity>
      )}
    </TouchableOpacity>
  );
};

export default SearchBar;
