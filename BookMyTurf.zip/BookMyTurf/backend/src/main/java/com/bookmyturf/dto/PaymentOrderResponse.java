package com.bookmyturf.dto;

import lombok.*;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PaymentOrderResponse {

    private String razorpayOrderId;

    private BigDecimal amount;

    private String currency;

    private String keyId;

    private String bookingId;

    private String bookingNumber;
}
