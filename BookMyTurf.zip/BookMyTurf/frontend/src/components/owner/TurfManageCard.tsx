import React from 'react';
import { View, Text, Switch, Pressable } from 'react-native';
import { Image } from 'expo-image';
import { Ionicons } from '@expo/vector-icons';
import { Turf } from '@/types';
import { formatCurrency, formatTime } from '@/utils/helpers';
import { SPORT_COLORS, SPORT_ICONS } from '@/utils/constants';

interface TurfManageCardProps {
  turf: Turf;
  onEdit: (turf: Turf) => void;
  onDelete: (turf: Turf) => void;
  onToggleActive: (turf: Turf) => void;
}

const TurfManageCard: React.FC<TurfManageCardProps> = ({
  turf,
  onEdit,
  onDelete,
  onToggleActive,
}) => {
  const thumbnail = turf.images && turf.images.length > 0 ? turf.images[0] : null;
  const sportColor = SPORT_COLORS[turf.sport] ?? '#6B7280';
  const sportIcon = (SPORT_ICONS as Record<string, string>)[turf.sport] ?? 'tennisball-outline';
  const sportBg = `${sportColor}26`;

  return (
    <View className="bg-dark-100 rounded-2xl overflow-hidden mb-3">
      <View className="flex-row items-center p-3">
        {/* Thumbnail */}
        <View
          style={{ width: 80, height: 80, borderRadius: 12, overflow: 'hidden' }}
          className="bg-dark-200 items-center justify-center mr-3 flex-shrink-0"
        >
          {thumbnail ? (
            <Image
              source={{ uri: thumbnail }}
              style={{ width: 80, height: 80 }}
              contentFit="cover"
              transition={300}
            />
          ) : (
            <Ionicons name={sportIcon as any} size={32} color={sportColor} />
          )}
        </View>

        {/* Center: name, sport, price, time */}
        <View className="flex-1 mr-2">
          <Text className="text-white font-semibold text-sm" numberOfLines={1}>
            {turf.name}
          </Text>

          {/* Sport badge */}
          <View
            className="self-start px-2 py-0.5 rounded-full mt-1"
            style={{ backgroundColor: sportBg }}
          >
            <Text className="text-xs font-medium" style={{ color: sportColor }}>
              {turf.sport}
            </Text>
          </View>

          {/* Price */}
          <Text className="text-white text-sm font-bold mt-1.5">
            {formatCurrency(turf.pricePerHour)}
            <Text className="text-muted font-normal text-xs">/hr</Text>
          </Text>

          {/* Time range */}
          <View className="flex-row items-center mt-0.5">
            <Ionicons name="time-outline" size={11} color="#6B7280" />
            <Text className="text-muted text-xs ml-0.5">
              {formatTime(turf.openingTime)} – {formatTime(turf.closingTime)}
            </Text>
          </View>
        </View>

        {/* Right: toggle + edit/delete */}
        <View className="items-center gap-2">
          <Switch
            value={turf.active}
            onValueChange={() => onToggleActive(turf)}
            trackColor={{ false: '#374151', true: '#1DB954' }}
            thumbColor="#FFFFFF"
          />

          {/* Edit */}
          <Pressable
            onPress={() => onEdit(turf)}
            style={({ pressed }) => ({
              opacity: pressed ? 0.75 : 1,
              backgroundColor: '#252525',
              width: 32,
              height: 32,
              borderRadius: 16,
              alignItems: 'center',
              justifyContent: 'center',
            })}
          >
            <Ionicons name="pencil-outline" size={15} color="#FFFFFF" />
          </Pressable>

          {/* Delete */}
          <Pressable
            onPress={() => onDelete(turf)}
            style={({ pressed }) => ({
              opacity: pressed ? 0.75 : 1,
              backgroundColor: '#EF444419',
              width: 32,
              height: 32,
              borderRadius: 16,
              alignItems: 'center',
              justifyContent: 'center',
            })}
          >
            <Ionicons name="trash-outline" size={15} color="#EF4444" />
          </Pressable>
        </View>
      </View>
    </View>
  );
};

export default TurfManageCard;
