import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  ScrollView,
  RefreshControl,
  Pressable,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import Toast from 'react-native-toast-message';

import { useTurfsByVenue, useDeleteTurf, useToggleTurfActive } from '@/hooks/useTurfs';
import { useVenueById } from '@/hooks/useVenues';
import { Turf } from '@/types';
import TurfManageCard from '@/components/owner/TurfManageCard';
import CustomButton from '@/components/common/CustomButton';
import EmptyState from '@/components/common/EmptyState';
import SkeletonLoader from '@/components/common/SkeletonLoader';
import ConfirmDialog from '@/components/common/ConfirmDialog';

export default function VenueTurfsScreen() {
  const router = useRouter();
  const { id: venueId } = useLocalSearchParams<{ id: string }>();

  const { data: venue } = useVenueById(venueId);
  const {
    data: turfs,
    isLoading,
    isError,
    refetch,
  } = useTurfsByVenue(venueId);

  const { mutate: deleteTurf, isPending: isDeleting } = useDeleteTurf();
  const { mutate: toggleTurfActive } = useToggleTurfActive();

  const [refreshing, setRefreshing] = useState(false);
  const [deleteDialogVisible, setDeleteDialogVisible] = useState(false);
  const [turfToDelete, setTurfToDelete] = useState<Turf | null>(null);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  }, [refetch]);

  const handleEdit = (turf: Turf) => {
    router.push(`/(owner)/turfs/${turf.id}/edit`);
  };

  const handleDeletePress = (turf: Turf) => {
    setTurfToDelete(turf);
    setDeleteDialogVisible(true);
  };

  const handleDeleteConfirm = () => {
    if (!turfToDelete) return;
    deleteTurf(
      { id: turfToDelete.id, venueId },
      {
        onSuccess: () => {
          setDeleteDialogVisible(false);
          setTurfToDelete(null);
          Toast.show({
            type: 'success',
            text1: 'Turf deleted',
            text2: `${turfToDelete.name} has been removed.`,
          });
        },
        onError: () => {
          setDeleteDialogVisible(false);
          Toast.show({
            type: 'error',
            text1: 'Delete failed',
            text2: 'Could not delete turf. Please try again.',
          });
        },
      }
    );
  };

  const handleToggleActive = (turf: Turf) => {
    toggleTurfActive(turf.id, {
      onSuccess: () => {
        Toast.show({
          type: 'success',
          text1: turf.active ? 'Turf deactivated' : 'Turf activated',
        });
      },
      onError: () => {
        Toast.show({
          type: 'error',
          text1: 'Update failed',
          text2: 'Could not toggle turf status.',
        });
      },
    });
  };

  const handleAddTurf = () => {
    router.push(`/(owner)/turfs/create?venueId=${venueId}`);
  };

  return (
    <SafeAreaView className="flex-1 bg-dark">
      {/* Header */}
      <View className="flex-row items-center justify-between px-4 py-3 border-b border-dark-200">
        <View className="flex-row items-center flex-1">
          <Pressable
            onPress={() => router.back()}
            className="w-9 h-9 items-center justify-center rounded-full bg-dark-100 mr-3"
            hitSlop={8}
          >
            <Ionicons name="chevron-back" size={20} color="#FFFFFF" />
          </Pressable>
          <Text
            className="text-white font-bold text-lg flex-1"
            numberOfLines={1}
          >
            {venue?.name ?? 'Turfs'}
          </Text>
        </View>
        <CustomButton
          title="Add Turf"
          onPress={handleAddTurf}
          variant="primary"
          size="sm"
          icon={<Ionicons name="add" size={16} color="#FFFFFF" />}
        />
      </View>

      {/* Content */}
      {isLoading ? (
        <View className="px-4 pt-4">
          <SkeletonLoader variant="card" count={3} />
        </View>
      ) : isError ? (
        <View className="flex-1 items-center justify-center px-6">
          <Ionicons name="alert-circle-outline" size={48} color="#EF4444" />
          <Text className="text-white font-semibold text-base mt-3">
            Failed to load turfs
          </Text>
          <Text className="text-muted text-sm mt-1 text-center">
            Something went wrong. Pull down to retry.
          </Text>
        </View>
      ) : (
        <ScrollView
          className="flex-1"
          contentContainerStyle={{
            padding: 16,
            paddingBottom: 32,
            flexGrow: turfs && turfs.length === 0 ? 1 : undefined,
          }}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              tintColor="#1DB954"
              colors={['#1DB954']}
            />
          }
          showsVerticalScrollIndicator={false}
        >
          {turfs && turfs.length > 0 ? (
            turfs.map((turf) => (
              <TurfManageCard
                key={turf.id}
                turf={turf}
                onEdit={handleEdit}
                onDelete={handleDeletePress}
                onToggleActive={handleToggleActive}
              />
            ))
          ) : (
            <View className="flex-1 items-center justify-center">
              <EmptyState
                icon="football-outline"
                title="No turfs yet"
                subtitle="Add your first turf for this venue"
                actionLabel="Add Turf"
                onAction={handleAddTurf}
              />
            </View>
          )}
        </ScrollView>
      )}

      {/* Delete Confirm Dialog */}
      <ConfirmDialog
        visible={deleteDialogVisible}
        title="Delete Turf"
        message={`Are you sure you want to delete "${turfToDelete?.name}"? This action cannot be undone.`}
        confirmLabel="Delete"
        cancelLabel="Cancel"
        onConfirm={handleDeleteConfirm}
        onCancel={() => {
          setDeleteDialogVisible(false);
          setTurfToDelete(null);
        }}
        destructive
        loading={isDeleting}
      />
    </SafeAreaView>
  );
}
