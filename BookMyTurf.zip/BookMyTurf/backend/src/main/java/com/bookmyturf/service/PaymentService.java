package com.bookmyturf.service;

import com.bookmyturf.dto.BookingResponse;
import com.bookmyturf.dto.PaymentOrderResponse;
import com.bookmyturf.dto.PaymentVerificationRequest;
import com.bookmyturf.entity.Booking;
import com.bookmyturf.entity.Payment;
import com.bookmyturf.exception.BadRequestException;
import com.bookmyturf.exception.ResourceNotFoundException;
import com.bookmyturf.exception.UnauthorizedException;
import com.bookmyturf.repository.BookingRepository;
import com.bookmyturf.repository.PaymentRepository;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;

@Service
@Slf4j
public class PaymentService {

    private final BookingRepository bookingRepository;
    private final PaymentRepository paymentRepository;
    private final BookingService bookingService;

    @Value("${razorpay.key-id}")
    private String razorpayKeyId;

    @Value("${razorpay.key-secret}")
    private String razorpayKeySecret;

    public PaymentService(BookingRepository bookingRepository,
                          PaymentRepository paymentRepository,
                          BookingService bookingService) {
        this.bookingRepository = bookingRepository;
        this.paymentRepository = paymentRepository;
        this.bookingService = bookingService;
    }

    public PaymentOrderResponse createRazorpayOrder(String bookingId, String userId) {
        log.info("Creating Razorpay order for booking: {}", bookingId);

        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking", "id", bookingId));

        if (!booking.getUserId().equals(userId)) {
            throw new UnauthorizedException("You do not have permission to pay for this booking");
        }

        if (booking.getPaymentStatus() != Booking.PaymentStatus.PENDING) {
            throw new BadRequestException("Booking payment status is not PENDING");
        }

        try {
            RazorpayClient razorpayClient = new RazorpayClient(razorpayKeyId, razorpayKeySecret);

            long amountInPaise = booking.getAmount().multiply(BigDecimal.valueOf(100)).longValue();

            JSONObject options = new JSONObject();
            options.put("amount", amountInPaise);
            options.put("currency", "INR");
            options.put("receipt", booking.getBookingNumber());

            Order order = razorpayClient.orders.create(options);
            String razorpayOrderId = order.get("id");

            Payment payment = Payment.builder()
                    .bookingId(bookingId)
                    .razorpayOrderId(razorpayOrderId)
                    .amount(booking.getAmount())
                    .currency("INR")
                    .status(Payment.PaymentStatus.CREATED)
                    .build();
            paymentRepository.save(payment);

            log.info("Razorpay order created: {} for booking: {}", razorpayOrderId, bookingId);
            return PaymentOrderResponse.builder()
                    .razorpayOrderId(razorpayOrderId)
                    .amount(booking.getAmount())
                    .currency("INR")
                    .keyId(razorpayKeyId)
                    .bookingId(bookingId)
                    .bookingNumber(booking.getBookingNumber())
                    .build();

        } catch (RazorpayException e) {
            log.error("Failed to create Razorpay order for booking: {}", bookingId, e);
            throw new BadRequestException("Failed to create payment order: " + e.getMessage());
        }
    }

    public BookingResponse verifyAndCompletePayment(PaymentVerificationRequest req, String userId) {
        log.info("Verifying payment for booking: {}", req.getBookingId());

        String payload = req.getRazorpayOrderId() + "|" + req.getRazorpayPaymentId();
        if (!verifySignature(payload, req.getRazorpaySignature())) {
            log.warn("Payment signature verification failed for booking: {}", req.getBookingId());
            throw new UnauthorizedException("Payment signature verification failed");
        }

        Payment payment = paymentRepository.findByRazorpayOrderId(req.getRazorpayOrderId())
                .orElseThrow(() -> new ResourceNotFoundException("Payment", "razorpayOrderId", req.getRazorpayOrderId()));

        payment.setStatus(Payment.PaymentStatus.PAID);
        payment.setRazorpayPaymentId(req.getRazorpayPaymentId());
        payment.setRazorpaySignature(req.getRazorpaySignature());
        paymentRepository.save(payment);

        log.info("Payment verified, confirming booking: {}", req.getBookingId());
        return bookingService.confirmBooking(req.getBookingId());
    }

    public void handlePaymentFailure(String razorpayOrderId) {
        log.info("Handling payment failure for Razorpay order: {}", razorpayOrderId);

        paymentRepository.findByRazorpayOrderId(razorpayOrderId).ifPresent(payment -> {
            payment.setStatus(Payment.PaymentStatus.FAILED);
            paymentRepository.save(payment);

            bookingRepository.findById(payment.getBookingId()).ifPresent(booking -> {
                booking.setPaymentStatus(Booking.PaymentStatus.FAILED);
                bookingRepository.save(booking);
                log.info("Payment failed for booking: {}", payment.getBookingId());
            });
        });
    }

    private boolean verifySignature(String payload, String expectedSignature) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            SecretKeySpec secretKeySpec = new SecretKeySpec(
                    razorpayKeySecret.getBytes(StandardCharsets.UTF_8), "HmacSHA256");
            mac.init(secretKeySpec);
            byte[] hash = mac.doFinal(payload.getBytes(StandardCharsets.UTF_8));

            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }

            return hexString.toString().equals(expectedSignature);
        } catch (Exception e) {
            log.error("Error verifying payment signature", e);
            return false;
        }
    }
}
