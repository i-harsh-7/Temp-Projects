package com.bookmyturf.security;

import com.bookmyturf.entity.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.util.ReflectionTestUtils;

import static org.assertj.core.api.Assertions.assertThat;

@DisplayName("JwtTokenProvider unit tests")
class JwtTokenProviderTest {

    private static final String SECRET =
            "test-jwt-secret-key-for-unit-tests-which-is-long-enough-256-bits-1234567890";

    private JwtTokenProvider jwtTokenProvider;
    private UserDetails userDetails;

    @BeforeEach
    void setUp() {
        jwtTokenProvider = new JwtTokenProvider();
        ReflectionTestUtils.setField(jwtTokenProvider, "secret", SECRET);
        ReflectionTestUtils.setField(jwtTokenProvider, "expiry", 900_000L);
        ReflectionTestUtils.setField(jwtTokenProvider, "refreshExpiry", 604_800_000L);

        User user = User.builder()
                .id("user-1")
                .email("alice@example.com")
                .role(User.Role.CUSTOMER)
                .active(true)
                .build();
        userDetails = new CustomUserDetails(user);
    }

    @Test
    @DisplayName("generateAccessToken then validateToken returns true")
    void generateAccessToken_andValidate_returnsTrue() {
        String token = jwtTokenProvider.generateAccessToken(userDetails);

        assertThat(token).isNotBlank();
        assertThat(jwtTokenProvider.validateToken(token)).isTrue();
    }

    @Test
    @DisplayName("validateToken returns false for a malformed token")
    void validateToken_invalidToken_returnsFalse() {
        assertThat(jwtTokenProvider.validateToken("not.a.valid.jwt.token")).isFalse();
        assertThat(jwtTokenProvider.validateToken("garbage")).isFalse();
    }

    @Test
    @DisplayName("validateToken returns false for an expired token")
    void validateToken_expiredToken_returnsFalse() {
        // Generate a token that is already expired by setting a negative expiry.
        ReflectionTestUtils.setField(jwtTokenProvider, "expiry", -10_000L);
        String expiredToken = jwtTokenProvider.generateAccessToken(userDetails);

        // restore normal expiry for validation path (the token itself is already past expiry)
        ReflectionTestUtils.setField(jwtTokenProvider, "expiry", 900_000L);

        assertThat(jwtTokenProvider.validateToken(expiredToken)).isFalse();
    }

    @Test
    @DisplayName("getUsernameFromToken returns the user's email (token subject)")
    void getUsernameFromToken_returnsEmail() {
        String token = jwtTokenProvider.generateAccessToken(userDetails);

        String username = jwtTokenProvider.getUsernameFromToken(token);

        assertThat(username).isEqualTo("alice@example.com");
    }

    @Test
    @DisplayName("generateRefreshToken produces a non-blank opaque token")
    void generateRefreshToken_producesToken() {
        String refresh = jwtTokenProvider.generateRefreshToken();

        assertThat(refresh).isNotBlank();
        assertThat(refresh).doesNotContain("-");
        assertThat(refresh.length()).isGreaterThanOrEqualTo(32);
    }
}