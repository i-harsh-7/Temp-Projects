package com.bookmyturf.repository;

import com.bookmyturf.entity.Booking;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Repository
public interface BookingRepository extends MongoRepository<Booking, String> {

    List<Booking> findByUserId(String userId);

    List<Booking> findByVenueId(String venueId);

    List<Booking> findByTurfId(String turfId);

    List<Booking> findByTurfIdAndBookingDate(String turfId, LocalDate bookingDate);

    @Query("{ 'turfId': ?0, 'bookingDate': ?1, 'bookingStatus': { '$ne': 'CANCELLED' }, '$or': [ { 'startTime': { '$lt': ?3 }, 'endTime': { '$gt': ?2 } } ] }")
    List<Booking> findOverlappingBookings(String turfId, LocalDate bookingDate, LocalTime startTime, LocalTime endTime);

    @Query(value = "{ 'turfId': ?0, 'bookingDate': ?1, 'bookingStatus': { '$ne': 'CANCELLED' }, '$or': [ { 'startTime': { '$lt': ?3 }, 'endTime': { '$gt': ?2 } } ] }", exists = true)
    boolean existsByTurfIdAndBookingDateAndStatusNotAndTimeOverlap(String turfId, LocalDate bookingDate, LocalTime startTime, LocalTime endTime);
}
