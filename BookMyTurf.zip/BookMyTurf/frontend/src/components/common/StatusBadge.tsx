import React, { useEffect } from 'react';
import { View, Text } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  Easing,
} from 'react-native-reanimated';
import { BookingStatus, PaymentStatus } from '@/types';
import {
  getBookingStatusColor,
  getPaymentStatusColor,
} from '@/utils/helpers';

type StatusType = BookingStatus | PaymentStatus | 'CREATED';

interface StatusBadgeProps {
  status: StatusType;
  type?: 'booking' | 'payment';
  size?: 'sm' | 'md';
}

const getColor = (status: StatusType, type: 'booking' | 'payment'): string => {
  if (type === 'booking') {
    return getBookingStatusColor(status as BookingStatus);
  }
  return getPaymentStatusColor(status as PaymentStatus);
};

const getLabel = (status: StatusType): string => {
  switch (status) {
    case 'PENDING': return 'Pending';
    case 'CONFIRMED': return 'Confirmed';
    case 'CANCELLED': return 'Cancelled';
    case 'PAID': return 'Paid';
    case 'FAILED': return 'Failed';
    case 'REFUNDED': return 'Refunded';
    case 'CREATED': return 'Created';
    default: return status;
  }
};

const StatusBadge: React.FC<StatusBadgeProps> = ({
  status,
  type = 'booking',
  size = 'md',
}) => {
  const color = getColor(status, type);
  const isPending = status === 'PENDING';
  const pulseOpacity = useSharedValue(1);

  useEffect(() => {
    if (isPending) {
      pulseOpacity.value = withRepeat(
        withTiming(0.4, { duration: 900, easing: Easing.inOut(Easing.ease) }),
        -1,
        true
      );
    } else {
      pulseOpacity.value = 1;
    }
  }, [isPending, pulseOpacity]);

  const pulseStyle = useAnimatedStyle(() => ({
    opacity: pulseOpacity.value,
  }));

  const paddingH = size === 'sm' ? 8 : 12;
  const paddingV = size === 'sm' ? 3 : 5;
  const fontSize = size === 'sm' ? 11 : 12;
  const dotSize = size === 'sm' ? 5 : 6;

  return (
    <Animated.View
      style={[
        {
          flexDirection: 'row',
          alignItems: 'center',
          paddingHorizontal: paddingH,
          paddingVertical: paddingV,
          borderRadius: 20,
          backgroundColor: `${color}20`,
          borderWidth: 1,
          borderColor: `${color}50`,
        },
        isPending ? pulseStyle : undefined,
      ]}
    >
      <View
        style={{
          width: dotSize,
          height: dotSize,
          borderRadius: dotSize / 2,
          backgroundColor: color,
          marginRight: 5,
        }}
      />
      <Text style={{ fontSize, fontWeight: '600', color, letterSpacing: 0.3 }}>
        {getLabel(status)}
      </Text>
    </Animated.View>
  );
};

export default StatusBadge;
