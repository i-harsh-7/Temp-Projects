import React, { useRef, useState } from 'react';
import {
  View,
  FlatList,
  Dimensions,
  NativeSyntheticEvent,
  NativeScrollEvent,
} from 'react-native';
import { Image } from 'expo-image';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

interface VenueCarouselProps {
  images: string[];
  height?: number;
}

const PLACEHOLDER_IMAGE =
  'https://placehold.co/800x400/1A1A1A/1DB954?text=BookMyTurf';

const VenueCarousel: React.FC<VenueCarouselProps> = ({
  images,
  height = 260,
}) => {
  const [activeIndex, setActiveIndex] = useState(0);
  const flatListRef = useRef<FlatList<string>>(null);

  const displayImages = images.length > 0 ? images : [PLACEHOLDER_IMAGE];

  const handleScroll = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
    const slideIndex = Math.round(
      event.nativeEvent.contentOffset.x / SCREEN_WIDTH
    );
    setActiveIndex(slideIndex);
  };

  return (
    <View>
      <FlatList
        ref={flatListRef}
        data={displayImages}
        keyExtractor={(item, index) => `${item}-${index}`}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScroll={handleScroll}
        scrollEventThrottle={16}
        renderItem={({ item }) => (
          <Image
            source={{ uri: item }}
            style={{ width: SCREEN_WIDTH, height }}
            contentFit="cover"
            placeholder={PLACEHOLDER_IMAGE}
            transition={300}
          />
        )}
      />

      {/* Dot indicators */}
      {displayImages.length > 1 && (
        <View className="flex-row items-center justify-center py-3 gap-1.5">
          {displayImages.map((_, index) => (
            <View
              key={index}
              className={`rounded-full ${
                index === activeIndex
                  ? 'w-5 h-2 bg-primary'
                  : 'w-2 h-2 bg-dark-400'
              }`}
            />
          ))}
        </View>
      )}
    </View>
  );
};

export default VenueCarousel;
