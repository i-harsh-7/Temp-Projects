import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Link } from 'expo-router';
import Toast from 'react-native-toast-message';
import { Ionicons } from '@expo/vector-icons';
import CustomInput from '@/components/common/CustomInput';
import CustomButton from '@/components/common/CustomButton';
import { useAuth } from '@/hooks/useAuth';
import { registerSchema, RegisterFormData } from '@/utils/validation';
import { UserRole } from '@/types';

const ROLE_OPTIONS: { label: string; value: UserRole; icon: string }[] = [
  { label: 'Player', value: 'CUSTOMER', icon: 'person' },
  { label: 'Venue Owner', value: 'VENUE_OWNER', icon: 'business' },
];

export default function RegisterScreen() {
  const { register: registerUser, isRegisterLoading } = useAuth();

  const {
    control,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm<RegisterFormData>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      name: '',
      email: '',
      password: '',
      phone: '',
      role: 'CUSTOMER',
    },
  });

  const selectedRole = watch('role');

  const onSubmit = (data: RegisterFormData) => {
    registerUser(data, {
      onError: (error) => {
        Toast.show({
          type: 'error',
          text1: 'Registration Failed',
          text2:
            error instanceof Error ? error.message : 'Could not create account',
        });
      },
    });
  };

  return (
    <SafeAreaView className="flex-1 bg-dark">
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        className="flex-1"
      >
        <ScrollView
          className="flex-1 px-6"
          contentContainerStyle={{ paddingTop: 32, paddingBottom: 40 }}
          keyboardShouldPersistTaps="handled"
        >
          <View className="items-center mb-8">
            <View className="w-14 h-14 rounded-2xl bg-primary/20 items-center justify-center mb-3">
              <Ionicons name="football" size={28} color="#1DB954" />
            </View>
            <Text className="text-white text-2xl font-bold">BookMyTurf</Text>
          </View>

          <Text className="text-white text-2xl font-bold mb-1">
            Create Account
          </Text>
          <Text className="text-muted text-sm mb-8">
            Join thousands of sports enthusiasts
          </Text>

          {/* Role selector */}
          <Text className="text-white text-sm font-medium mb-2">I am a...</Text>
          <View className="flex-row gap-3 mb-5">
            {ROLE_OPTIONS.map((option) => (
              <TouchableOpacity
                key={option.value}
                onPress={() => setValue('role', option.value)}
                className={`flex-1 flex-row items-center justify-center gap-2 py-3.5 rounded-xl border ${
                  selectedRole === option.value
                    ? 'bg-primary/20 border-primary'
                    : 'bg-dark-100 border-dark-300'
                }`}
              >
                <Ionicons
                  name={option.icon as React.ComponentProps<typeof Ionicons>['name']}
                  size={18}
                  color={selectedRole === option.value ? '#1DB954' : '#6B7280'}
                />
                <Text
                  className={`text-sm font-medium ${
                    selectedRole === option.value ? 'text-primary' : 'text-muted'
                  }`}
                >
                  {option.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <Controller
            control={control}
            name="name"
            render={({ field: { onChange, onBlur, value } }) => (
              <CustomInput
                label="Full Name"
                placeholder="John Doe"
                autoCapitalize="words"
                onChangeText={onChange}
                onBlur={onBlur}
                value={value}
                error={errors.name?.message}
                leftIcon={<Ionicons name="person-outline" size={18} color="#6B7280" />}
              />
            )}
          />

          <Controller
            control={control}
            name="email"
            render={({ field: { onChange, onBlur, value } }) => (
              <CustomInput
                label="Email"
                placeholder="you@example.com"
                keyboardType="email-address"
                autoCapitalize="none"
                autoComplete="email"
                onChangeText={onChange}
                onBlur={onBlur}
                value={value}
                error={errors.email?.message}
                leftIcon={<Ionicons name="mail-outline" size={18} color="#6B7280" />}
              />
            )}
          />

          <Controller
            control={control}
            name="phone"
            render={({ field: { onChange, onBlur, value } }) => (
              <CustomInput
                label="Phone Number"
                placeholder="9876543210"
                keyboardType="phone-pad"
                maxLength={10}
                onChangeText={onChange}
                onBlur={onBlur}
                value={value}
                error={errors.phone?.message}
                leftIcon={<Ionicons name="call-outline" size={18} color="#6B7280" />}
              />
            )}
          />

          <Controller
            control={control}
            name="password"
            render={({ field: { onChange, onBlur, value } }) => (
              <CustomInput
                label="Password"
                placeholder="Min 8 chars, 1 uppercase, 1 number"
                secureTextEntry
                onChangeText={onChange}
                onBlur={onBlur}
                value={value}
                error={errors.password?.message}
                leftIcon={<Ionicons name="lock-closed-outline" size={18} color="#6B7280" />}
              />
            )}
          />

          <CustomButton
            title="Create Account"
            onPress={handleSubmit(onSubmit)}
            loading={isRegisterLoading}
            fullWidth
          />

          <View className="flex-row items-center justify-center mt-6">
            <Text className="text-muted text-sm">Already have an account? </Text>
            <Link href="/(auth)/login">
              <Text className="text-primary text-sm font-semibold">Sign In</Text>
            </Link>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
