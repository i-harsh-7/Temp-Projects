# BookMyTurf

> Book your game in seconds — a full-stack sports turf booking platform for customers, venue owners, and administrators.

![Java](https://img.shields.io/badge/Java-21-orange?logo=openjdk&logoColor=white)
![Spring Boot](https://img.shields.io/badge/Spring%20Boot-3.2.3-6DB33F?logo=springboot&logoColor=white)
![React Native](https://img.shields.io/badge/React%20Native-0.76-61DAFB?logo=react&logoColor=white)
![Expo](https://img.shields.io/badge/Expo-52-000020?logo=expo&logoColor=white)
![MongoDB](https://img.shields.io/badge/MongoDB-Document%20DB-47A248?logo=mongodb&logoColor=white)
![Redis](https://img.shields.io/badge/Redis-Distributed%20Lock-DC382D?logo=redis&logoColor=white)
![License](https://img.shields.io/badge/License-MIT-blue.svg)

---

## Overview

**BookMyTurf** is a sports turf booking platform that connects players with venues. It is built as two
applications:

- A **Spring Boot 3 / Java 21** REST backend persisting to **MongoDB**, using **Redis** for distributed
  slot locking, **JWT** for stateless authentication, **Razorpay** for payments, and **Cloudinary** for
  image hosting.
- A **React Native / Expo** mobile app (Expo Router file-based navigation) consuming the REST API.

The platform supports three roles, each with a dedicated experience:

| Role | Description |
| --- | --- |
| `CUSTOMER` | Browses and searches venues, views turfs and time slots, books and pays, manages bookings. |
| `VENUE_OWNER` | Creates and manages venues and turfs, uploads images, views bookings, sees a dashboard. |
| `ADMIN` | Approves venues, views all users / venues / bookings, sees a platform-wide dashboard. |

---

## Key Features

### Customer
- Register / login / logout with JWT (access + refresh tokens)
- Browse approved venues (paginated)
- Search venues by free-text query, city, and sport
- View venue details and its turfs
- View per-day hourly slot availability for a turf
- Create a booking (price computed from turf hourly rate)
- Pay securely via Razorpay (order creation + signature verification)
- View "My Bookings" and cancel a booking
- View and update profile, upload an avatar

### Venue Owner
- Full CRUD on venues (create, update, delete, list "my venues")
- Full CRUD on turfs (create, update, delete, list by venue)
- Upload venue images and turf images (Cloudinary)
- View bookings for a venue (owner-scoped)
- Owner dashboard

### Admin
- View all users (paginated), activate/deactivate a user
- View all venues (paginated) and approve venues
- View all bookings (paginated)
- Platform dashboard (total users, venues, pending approvals, bookings, revenue)

---

## Tech Stack

### Frontend

| Concern | Technology |
| --- | --- |
| Framework | React Native `0.76.5`, Expo `~52.0.0` |
| Navigation | Expo Router `~4.0.0` (file-based) |
| Language | TypeScript `^5.3.0` |
| Data fetching | TanStack React Query `^5.0.0` |
| State | Zustand `^4.4.0` |
| Forms / Validation | React Hook Form `^7.48.0` + Zod `^3.22.0` |
| HTTP | Axios `^1.6.0` |
| Storage | AsyncStorage `1.23.1` |
| Styling | NativeWind `^4.0.1` + Tailwind CSS `^3.4.0` |
| Misc | Reanimated, expo-image, react-native-toast-message, date-fns |

### Backend

| Concern | Technology |
| --- | --- |
| Language / Runtime | Java `21` |
| Framework | Spring Boot `3.2.3` (Web, Security, Validation, Cache) |
| Database | MongoDB (Spring Data MongoDB) |
| Cache / Locking | Redis (Spring Data Redis) |
| Auth | JWT (`io.jsonwebtoken` jjwt `0.12.3`) |
| Payments | Razorpay Java SDK `1.4.5` |
| Images | Cloudinary `cloudinary-http44` `1.36.0` |
| Mapping | MapStruct `1.5.5.Final`, ModelMapper `3.1.1` |
| Boilerplate | Lombok `1.18.30` |
| API Docs | springdoc-openapi `2.3.0` (Swagger UI) |

---

## Architecture Overview

BookMyTurf follows a **Clean / layered architecture** on the backend:

```
React Native (Expo)  ──HTTPS/JSON──►  REST API  (context-path: /api)
                                          │
                              ┌───────────┴───────────┐
                              │      Controller        │  HTTP mapping, validation, auth (@PreAuthorize)
                              ├────────────────────────┤
                              │       Service          │  Business logic (booking rules, payments, slots)
                              ├────────────────────────┤
                              │      Repository         │  Spring Data MongoDB interfaces
                              └───────────┬────────────┘
                                          ▼
                                     MongoDB  (users, venues, turfs, bookings, payments, refresh_tokens)

      Cross-cutting:  Redis (slot locks)   •   Razorpay (payments)   •   Cloudinary (images)   •   JWT (stateless auth)
```

- **Controllers** only translate HTTP <-> DTOs, enforce role-based access (`@PreAuthorize`), and delegate.
- **Services** hold all business logic — booking validation, Redis slot locking, Razorpay order/verify,
  Cloudinary uploads, slot generation.
- **Repositories** are thin Spring Data MongoDB interfaces.
- **Redis distributed locking** prevents double-booking race conditions (`SET NX` with a 5-minute TTL).
- **JWT** gives stateless auth — a short-lived access token plus an opaque refresh token persisted in MongoDB.
- **Razorpay** handles payment: backend creates an order, frontend completes it, backend verifies the HMAC
  signature before confirming the booking.
- **Cloudinary** stores all uploaded images (venue, turf, avatar) and returns secure URLs.

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for diagrams (system, auth flow, slot-booking sequence, ER).

---

## Project Structure

```
BookMyTurf/
├── backend/
│   ├── pom.xml
│   └── src/main/
│       ├── java/com/bookmyturf/
│       │   ├── cloudinary/      # CloudinaryService (image upload/delete)
│       │   ├── config/          # SecurityConfig, RedisConfig, MongoConfig, CloudinaryConfig, AppConfig
│       │   ├── controller/      # AuthController, UserController, VenueController, TurfController,
│       │   │                    #   BookingController, PaymentController, AdminController
│       │   ├── dto/             # Request/response DTOs + ApiResponse, PageResponse
│       │   ├── entity/          # User, Venue, Turf, Booking, Payment, RefreshToken
│       │   ├── exception/       # Custom exceptions + global handler
│       │   ├── mapper/          # MapStruct mappers
│       │   ├── redis/           # RedisLockService (slot locking)
│       │   ├── repository/      # Spring Data MongoDB repositories
│       │   ├── security/        # JwtTokenProvider, JwtAuthenticationFilter, CustomUserDetails
│       │   ├── service/         # AuthService, UserService, VenueService, TurfService,
│       │   │                    #   BookingService, PaymentService, SlotService
│       │   └── util/            # SecurityUtils, BookingUtils
│       └── resources/
│           └── application.yml
└── frontend/
    ├── package.json
    ├── app/                     # Expo Router screens (file-based routing)
    │   ├── (auth)/              # login, register, forgot-password
    │   ├── (tabs)/              # home, search, bookings, profile (customer)
    │   ├── (owner)/             # dashboard, venues, turfs, bookings, add-venue
    │   ├── (admin)/             # dashboard, users, venues, bookings
    │   ├── booking/             # slot-selection, checkout
    │   ├── turf/[id].tsx
    │   ├── venue/[id].tsx
    │   ├── onboarding.tsx
    │   └── _layout.tsx
    └── src/
        ├── components/          # common, booking, venue, turf, owner UI components
        ├── hooks/               # useAuth, useBookings, usePayment, useTurfs, useVenues
        ├── services/            # api (axios), authService, bookingService, paymentService, ...
        ├── store/               # authStore, searchStore (Zustand)
        ├── types/               # shared TypeScript types
        └── utils/               # constants, helpers, validation
```

---

## Prerequisites

- **Java 21** (JDK)
- **Maven 3.9+**
- **Node.js 18+** and npm
- **MongoDB** (local or Atlas)
- **Redis** (local or Docker)
- **Expo CLI** (`npx expo`)
- A **Cloudinary** account (for image uploads)
- A **Razorpay** test account (for payments)

---

## Quick Start

```bash
# 1. Backend
cd backend
cp .env.example .env          # then fill in your secrets (or export as env vars)
mvn clean install
mvn spring-boot:run            # starts on http://localhost:8080/api

# 2. Frontend (in a second terminal)
cd frontend
cp .env.example .env          # set EXPO_PUBLIC_API_URL
npm install
npx expo start
```

For the complete, step-by-step setup (MongoDB, Redis, Cloudinary, Razorpay, env vars, troubleshooting),
see **[docs/SETUP.md](docs/SETUP.md)**.

---

## Screenshots

> _Placeholder — add screenshots / screen recordings here._

| Onboarding | Home | Venue Detail | Slot Selection | Checkout |
| --- | --- | --- | --- | --- |
| _coming soon_ | _coming soon_ | _coming soon_ | _coming soon_ | _coming soon_ |

---

## Documentation

| Document | Description |
| --- | --- |
| [docs/SETUP.md](docs/SETUP.md) | Complete environment + run setup guide |
| [docs/API.md](docs/API.md) | Full REST API reference (every endpoint) |
| [docs/ENVIRONMENT.md](docs/ENVIRONMENT.md) | Environment variable reference |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | Architecture, diagrams, Redis locking, RBAC |
| [docs/DATABASE.md](docs/DATABASE.md) | MongoDB schema, indexes, relationships |
| [VERIFICATION_CHECKLIST.md](VERIFICATION_CHECKLIST.md) | Sprint 1 feature verification checklist |

---

## License

This project is licensed under the **MIT License**. See the [LICENSE](LICENSE) file (if present) for details.
