package com.bookmyturf.cloudinary;

import com.bookmyturf.exception.BadRequestException;
import com.cloudinary.Cloudinary;
import com.cloudinary.utils.ObjectUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class CloudinaryService {

    private final Cloudinary cloudinary;

    /**
     * Uploads an image to Cloudinary and returns the secure URL.
     *
     * @param file   the multipart file to upload
     * @param folder the Cloudinary folder to upload into
     * @return the secure URL of the uploaded image
     */
    public String uploadImage(MultipartFile file, String folder) {
        if (file == null || file.isEmpty()) {
            throw new BadRequestException("File is empty or null");
        }

        try {
            Map<?, ?> uploadResult = cloudinary.uploader().upload(
                    file.getBytes(),
                    ObjectUtils.asMap(
                            "folder", folder,
                            "resource_type", "image",
                            "use_filename", true,
                            "unique_filename", true
                    )
            );

            String secureUrl = (String) uploadResult.get("secure_url");
            log.debug("Image uploaded to Cloudinary: folder='{}', url='{}'", folder, secureUrl);
            return secureUrl;

        } catch (IOException e) {
            log.error("Failed to upload image to Cloudinary in folder '{}'", folder, e);
            throw new BadRequestException("Failed to upload image: " + e.getMessage());
        }
    }

    /**
     * Deletes an image from Cloudinary by its public ID.
     *
     * @param publicId the Cloudinary public ID of the image to delete
     */
    public void deleteImage(String publicId) {
        if (publicId == null || publicId.isBlank()) {
            throw new BadRequestException("Public ID is required for image deletion");
        }

        try {
            Map<?, ?> result = cloudinary.uploader().destroy(publicId, ObjectUtils.emptyMap());
            String resultStatus = (String) result.get("result");
            log.debug("Image deletion from Cloudinary: publicId='{}', result='{}'", publicId, resultStatus);

        } catch (IOException e) {
            log.error("Failed to delete image from Cloudinary: publicId='{}'", publicId, e);
            throw new BadRequestException("Failed to delete image: " + e.getMessage());
        }
    }
}
