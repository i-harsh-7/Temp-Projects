package com.bookmyturf.mapper;

import com.bookmyturf.dto.CreateVenueRequest;
import com.bookmyturf.dto.UpdateVenueRequest;
import com.bookmyturf.dto.VenueResponse;
import com.bookmyturf.entity.Venue;
import org.mapstruct.BeanMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValuePropertyMappingStrategy;

@Mapper(componentModel = "spring")
public interface VenueMapper {

    @Mapping(target = "latitude", expression = "java(venue.getLocation() != null ? venue.getLocation().getY() : null)")
    @Mapping(target = "longitude", expression = "java(venue.getLocation() != null ? venue.getLocation().getX() : null)")
    @Mapping(target = "turfCount", ignore = true)
    VenueResponse toResponse(Venue venue);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "ownerId", ignore = true)
    @Mapping(target = "location", ignore = true)
    @Mapping(target = "images", ignore = true)
    @Mapping(target = "approved", ignore = true)
    @Mapping(target = "active", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    Venue toVenue(CreateVenueRequest request);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "ownerId", ignore = true)
    @Mapping(target = "location", ignore = true)
    @Mapping(target = "images", ignore = true)
    @Mapping(target = "approved", ignore = true)
    @Mapping(target = "active", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    void updateVenue(UpdateVenueRequest request, @MappingTarget Venue venue);
}
