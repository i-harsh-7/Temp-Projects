import { format, parseISO, isBefore } from 'date-fns';
import { BookingStatus, PaymentStatus, TimeSlot } from '@/types';

/**
 * Format a number as Indian Rupees currency string.
 * Example: formatCurrency(1200) → "₹1,200"
 */
export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
};

/**
 * Format an ISO date string to a human-readable date.
 * Example: formatDate("2026-06-27") → "Mon, 27 Jun 2026"
 */
export const formatDate = (date: string): string => {
  try {
    const parsed = date.includes('T') ? parseISO(date) : parseISO(date + 'T00:00:00');
    return format(parsed, 'EEE, dd MMM yyyy');
  } catch {
    return date;
  }
};

/**
 * Format a time string (HH:mm or HH:mm:ss) to 12-hour format.
 * Example: formatTime("10:00") → "10:00 AM"
 *          formatTime("22:30") → "10:30 PM"
 */
export const formatTime = (time: string): string => {
  try {
    const [hourStr, minuteStr] = time.split(':');
    const hour = parseInt(hourStr, 10);
    const minute = parseInt(minuteStr, 10);
    const period = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 === 0 ? 12 : hour % 12;
    const displayMinute = minute.toString().padStart(2, '0');
    return `${displayHour}:${displayMinute} ${period}`;
  } catch {
    return time;
  }
};

/**
 * Get initials from a full name.
 * Example: getInitials("John Doe") → "JD"
 *          getInitials("Alice") → "A"
 */
export const getInitials = (name: string): string => {
  if (!name || name.trim().length === 0) return '?';
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) {
    return parts[0].charAt(0).toUpperCase();
  }
  return (
    parts[0].charAt(0).toUpperCase() +
    parts[parts.length - 1].charAt(0).toUpperCase()
  );
};

/**
 * Generate time slots between opening and closing time.
 * Returns array of {startTime, endTime} objects.
 */
export const generateTimeSlots = (
  openingTime: string,
  closingTime: string,
  durationMinutes: number = 60
): Array<{ startTime: string; endTime: string }> => {
  const slots: Array<{ startTime: string; endTime: string }> = [];

  const [openHour, openMin] = openingTime.split(':').map(Number);
  const [closeHour, closeMin] = closingTime.split(':').map(Number);

  let currentMinutes = openHour * 60 + openMin;
  const closeMinutes = closeHour * 60 + closeMin;

  while (currentMinutes + durationMinutes <= closeMinutes) {
    const startHour = Math.floor(currentMinutes / 60);
    const startMin = currentMinutes % 60;
    const endMinutes = currentMinutes + durationMinutes;
    const endHour = Math.floor(endMinutes / 60);
    const endMin = endMinutes % 60;

    slots.push({
      startTime: `${startHour.toString().padStart(2, '0')}:${startMin.toString().padStart(2, '0')}`,
      endTime: `${endHour.toString().padStart(2, '0')}:${endMin.toString().padStart(2, '0')}`,
    });

    currentMinutes += durationMinutes;
  }

  return slots;
};

/**
 * Check if a time slot is in the past.
 * date: "YYYY-MM-DD", time: "HH:mm"
 */
export const isSlotInPast = (date: string, time: string): boolean => {
  try {
    const slotDateTime = parseISO(`${date}T${time}:00`);
    return isBefore(slotDateTime, new Date());
  } catch {
    return false;
  }
};

/**
 * Get a hex color string for a booking status.
 */
export const getBookingStatusColor = (status: BookingStatus): string => {
  switch (status) {
    case 'CONFIRMED':
      return '#22C55E'; // green
    case 'PENDING':
      return '#F59E0B'; // amber
    case 'CANCELLED':
      return '#EF4444'; // red
    default:
      return '#6B7280'; // gray
  }
};

/**
 * Get a hex color string for a payment status.
 */
export const getPaymentStatusColor = (status: PaymentStatus): string => {
  switch (status) {
    case 'PAID':
      return '#22C55E'; // green
    case 'PENDING':
      return '#F59E0B'; // amber
    case 'FAILED':
      return '#EF4444'; // red
    case 'REFUNDED':
      return '#3B82F6'; // blue
    default:
      return '#6B7280'; // gray
  }
};

/**
 * Truncate text to a specified length and append ellipsis.
 */
export const truncateText = (text: string, maxLength: number): string => {
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength - 3) + '...';
};

/**
 * Convert a TimeSlot array into a map keyed by startTime for fast lookup.
 */
export const slotsToMap = (slots: TimeSlot[]): Map<string, TimeSlot> => {
  return new Map(slots.map((slot) => [slot.startTime, slot]));
};

/**
 * Format a duration in minutes to a human-readable string.
 * Example: formatDuration(90) → "1h 30m"
 */
export const formatDuration = (minutes: number): string => {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  if (hours === 0) return `${mins}m`;
  if (mins === 0) return `${hours}h`;
  return `${hours}h ${mins}m`;
};
