package com.bookmyturf.dto;

import com.bookmyturf.entity.Booking;
import lombok.*;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BookingResponse {

    private String id;

    private String bookingNumber;

    private String userId;

    private String venueId;

    private String turfId;

    private LocalDate bookingDate;

    private LocalTime startTime;

    private LocalTime endTime;

    private BigDecimal amount;

    private Booking.PaymentStatus paymentStatus;

    private Booking.BookingStatus bookingStatus;

    private Instant createdAt;

    private Instant updatedAt;

    private String venueName;

    private String turfName;

    private String userName;
}
