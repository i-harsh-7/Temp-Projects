import React from 'react'
import { View, Text, TouchableOpacity, Alert } from 'react-native'
import { Image } from 'expo-image'
import * as ImagePicker from 'expo-image-picker'
import { Ionicons } from '@expo/vector-icons'

interface ImageUploaderProps {
  images: string[]
  onImagesChange: (uris: string[]) => void
  maxCount?: number
  label?: string
}

export default function ImageUploader({
  images,
  onImagesChange,
  maxCount = 5,
  label,
}: ImageUploaderProps) {
  const handleAddPhoto = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync()
    if (status !== 'granted') {
      Alert.alert(
        'Permission Required',
        'Please allow access to your photo library to upload images.'
      )
      return
    }

    const remaining = maxCount - images.length
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsMultipleSelection: true,
      quality: 0.8,
      selectionLimit: remaining,
    })

    if (!result.canceled && result.assets.length > 0) {
      const newUris = result.assets.map((asset) => asset.uri)
      const combined = [...images, ...newUris].slice(0, maxCount)
      onImagesChange(combined)
    }
  }

  const handleRemove = (index: number) => {
    const updated = images.filter((_, i) => i !== index)
    onImagesChange(updated)
  }

  return (
    <View>
      {label ? (
        <Text className="text-white text-sm font-medium mb-2">{label}</Text>
      ) : null}
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
        {images.map((uri, index) => (
          <View key={uri + index} style={{ position: 'relative', width: 80, height: 80 }}>
            <Image
              source={{ uri }}
              style={{ width: 80, height: 80, borderRadius: 8 }}
              contentFit="cover"
            />
            <TouchableOpacity
              onPress={() => handleRemove(index)}
              style={{
                position: 'absolute',
                top: 4,
                right: 4,
                width: 20,
                height: 20,
                borderRadius: 10,
                backgroundColor: '#EF4444',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Ionicons name="close" size={12} color="#FFFFFF" />
            </TouchableOpacity>
          </View>
        ))}

        {images.length < maxCount && (
          <TouchableOpacity
            onPress={handleAddPhoto}
            style={{
              width: 80,
              height: 80,
              borderRadius: 8,
              borderWidth: 1.5,
              borderStyle: 'dashed',
              borderColor: '#374151',
              backgroundColor: '#1A1A1A',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 4,
            }}
          >
            <Ionicons name="add" size={20} color="#6B7280" />
            <Text style={{ color: '#6B7280', fontSize: 10, textAlign: 'center' }}>
              Add Photo
            </Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  )
}
