package com.bookmyturf.service;

import com.bookmyturf.dto.BookingResponse;
import com.bookmyturf.dto.CreateBookingRequest;
import com.bookmyturf.entity.Booking;
import com.bookmyturf.entity.Turf;
import com.bookmyturf.entity.User;
import com.bookmyturf.entity.Venue;
import com.bookmyturf.exception.BadRequestException;
import com.bookmyturf.exception.ConflictException;
import com.bookmyturf.exception.UnauthorizedException;
import com.bookmyturf.mapper.BookingMapper;
import com.bookmyturf.redis.RedisLockService;
import com.bookmyturf.repository.BookingRepository;
import com.bookmyturf.repository.TurfRepository;
import com.bookmyturf.repository.UserRepository;
import com.bookmyturf.repository.VenueRepository;
import com.bookmyturf.security.CustomUserDetails;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("BookingService unit tests (Redis locking & booking rules)")
class BookingServiceTest {

    @Mock
    private BookingRepository bookingRepository;
    @Mock
    private TurfRepository turfRepository;
    @Mock
    private VenueRepository venueRepository;
    @Mock
    private UserRepository userRepository;
    @Mock
    private BookingMapper bookingMapper;
    @Mock
    private RedisLockService redisLockService;

    @InjectMocks
    private BookingService bookingService;

    private static final String USER_ID = "user-1";
    private static final String TURF_ID = "turf-1";
    private static final String VENUE_ID = "venue-1";

    private CreateBookingRequest request;
    private Turf turf;
    private Venue venue;

    @BeforeEach
    void setUp() {
        LocalDate tomorrow = LocalDate.now().plusDays(1);
        request = CreateBookingRequest.builder()
                .turfId(TURF_ID)
                .venueId(VENUE_ID)
                .bookingDate(tomorrow)
                .startTime(LocalTime.of(10, 0))
                .endTime(LocalTime.of(12, 0))
                .build();

        turf = Turf.builder()
                .id(TURF_ID)
                .venueId(VENUE_ID)
                .name("Turf A")
                .sport("Football")
                .pricePerHour(new BigDecimal("500"))
                .openingTime(LocalTime.of(6, 0))
                .closingTime(LocalTime.of(23, 0))
                .active(true)
                .build();

        venue = Venue.builder()
                .id(VENUE_ID)
                .ownerId("owner-1")
                .name("Venue One")
                .approved(true)
                .active(true)
                .build();

        // BookingMapper just maps fields; return a response echoing core fields.
        when(bookingMapper.toResponse(any(Booking.class))).thenAnswer(inv -> {
            Booking b = inv.getArgument(0);
            return BookingResponse.builder()
                    .id(b.getId())
                    .bookingNumber(b.getBookingNumber())
                    .userId(b.getUserId())
                    .venueId(b.getVenueId())
                    .turfId(b.getTurfId())
                    .bookingDate(b.getBookingDate())
                    .startTime(b.getStartTime())
                    .endTime(b.getEndTime())
                    .amount(b.getAmount())
                    .paymentStatus(b.getPaymentStatus())
                    .bookingStatus(b.getBookingStatus())
                    .build();
        });
        // enrichBookingResponse looks up venue/turf/user names — keep them present.
        when(venueRepository.findById(VENUE_ID)).thenReturn(Optional.of(venue));
        when(turfRepository.findById(TURF_ID)).thenReturn(Optional.of(turf));
        when(userRepository.findById(USER_ID))
                .thenReturn(Optional.of(User.builder().id(USER_ID).name("Alice").build()));
    }

    @AfterEach
    void tearDown() {
        SecurityContextHolder.clearContext();
    }

    private void authenticateAs(String userId, String... roles) {
        User u = User.builder().id(userId).email(userId + "@test.com")
                .role(User.Role.CUSTOMER).active(true).build();
        CustomUserDetails principal = new CustomUserDetails(u);
        var authorities = java.util.Arrays.stream(roles)
                .map(r -> new SimpleGrantedAuthority("ROLE_" + r))
                .toList();
        var auth = new UsernamePasswordAuthenticationToken(principal, null, authorities);
        SecurityContextHolder.getContext().setAuthentication(auth);
    }

    @Test
    @DisplayName("createBooking: success persists PENDING booking with generated bookingNumber")
    void createBooking_success() {
        when(bookingRepository.findOverlappingBookings(eq(TURF_ID), any(), any(), any()))
                .thenReturn(List.of());
        when(redisLockService.acquireSlotLock(eq(TURF_ID), any(), any(), any())).thenReturn(true);
        when(bookingRepository.save(any(Booking.class))).thenAnswer(inv -> {
            Booking b = inv.getArgument(0);
            b.setId("booking-1");
            return b;
        });

        BookingResponse response = bookingService.createBooking(request, USER_ID);

        assertThat(response).isNotNull();
        assertThat(response.getBookingStatus()).isEqualTo(Booking.BookingStatus.PENDING);
        assertThat(response.getPaymentStatus()).isEqualTo(Booking.PaymentStatus.PENDING);
        assertThat(response.getUserId()).isEqualTo(USER_ID);

        ArgumentCaptor<Booking> captor = ArgumentCaptor.forClass(Booking.class);
        verify(bookingRepository).save(captor.capture());
        Booking saved = captor.getValue();
        assertThat(saved.getBookingNumber()).isNotBlank();
        assertThat(saved.getBookingNumber()).startsWith("BMT");
        // 2 hours * 500/hr
        assertThat(saved.getAmount()).isEqualByComparingTo(new BigDecimal("1000"));
        verify(redisLockService).acquireSlotLock(eq(TURF_ID), eq(request.getBookingDate()),
                eq(request.getStartTime()), eq(request.getEndTime()));
    }

    @Test
    @DisplayName("createBooking: past date throws BadRequestException")
    void createBooking_pastDate_throwsBadRequest() {
        request.setBookingDate(LocalDate.now().minusDays(1));

        assertThatThrownBy(() -> bookingService.createBooking(request, USER_ID))
                .isInstanceOf(BadRequestException.class)
                .hasMessageContaining("past");

        verify(bookingRepository, never()).save(any());
        verify(redisLockService, never()).acquireSlotLock(any(), any(), any(), any());
    }

    @Test
    @DisplayName("createBooking: inactive turf throws BadRequestException")
    void createBooking_inactiveTurf_throwsBadRequest() {
        turf.setActive(false);

        assertThatThrownBy(() -> bookingService.createBooking(request, USER_ID))
                .isInstanceOf(BadRequestException.class)
                .hasMessageContaining("Turf is not active");

        verify(bookingRepository, never()).save(any());
    }

    @Test
    @DisplayName("createBooking: unapproved venue throws BadRequestException")
    void createBooking_unapprovedVenue_throwsBadRequest() {
        venue.setApproved(false);

        assertThatThrownBy(() -> bookingService.createBooking(request, USER_ID))
                .isInstanceOf(BadRequestException.class)
                .hasMessageContaining("not approved");

        verify(bookingRepository, never()).save(any());
    }

    @Test
    @DisplayName("createBooking: inactive venue throws BadRequestException")
    void createBooking_inactiveVenue_throwsBadRequest() {
        venue.setActive(false);

        assertThatThrownBy(() -> bookingService.createBooking(request, USER_ID))
                .isInstanceOf(BadRequestException.class)
                .hasMessageContaining("Venue is not active");

        verify(bookingRepository, never()).save(any());
    }

    @Test
    @DisplayName("createBooking: overlapping active booking throws ConflictException")
    void createBooking_overlappingBooking_throwsConflict() {
        Booking existing = Booking.builder()
                .id("existing")
                .turfId(TURF_ID)
                .bookingStatus(Booking.BookingStatus.CONFIRMED)
                .build();
        when(bookingRepository.findOverlappingBookings(eq(TURF_ID), any(), any(), any()))
                .thenReturn(List.of(existing));

        assertThatThrownBy(() -> bookingService.createBooking(request, USER_ID))
                .isInstanceOf(ConflictException.class)
                .hasMessageContaining("already booked");

        verify(redisLockService, never()).acquireSlotLock(any(), any(), any(), any());
        verify(bookingRepository, never()).save(any());
    }

    @Test
    @DisplayName("createBooking: lock acquisition failure throws ConflictException (Slot temporarily locked)")
    void createBooking_slotLockFails_throwsConflict() {
        when(bookingRepository.findOverlappingBookings(eq(TURF_ID), any(), any(), any()))
                .thenReturn(List.of());
        when(redisLockService.acquireSlotLock(eq(TURF_ID), any(), any(), any())).thenReturn(false);

        assertThatThrownBy(() -> bookingService.createBooking(request, USER_ID))
                .isInstanceOf(ConflictException.class)
                .hasMessageContaining("temporarily locked");

        verify(bookingRepository, never()).save(any());
    }

    @Test
    @DisplayName("confirmBooking: sets CONFIRMED + PAID and releases the slot lock")
    void confirmBooking_setsConfirmedAndPaid_releasesLock() {
        Booking booking = Booking.builder()
                .id("booking-1")
                .bookingNumber("BMT12345678")
                .userId(USER_ID)
                .venueId(VENUE_ID)
                .turfId(TURF_ID)
                .bookingDate(LocalDate.now().plusDays(1))
                .startTime(LocalTime.of(10, 0))
                .endTime(LocalTime.of(12, 0))
                .amount(new BigDecimal("1000"))
                .paymentStatus(Booking.PaymentStatus.PENDING)
                .bookingStatus(Booking.BookingStatus.PENDING)
                .build();
        when(bookingRepository.findById("booking-1")).thenReturn(Optional.of(booking));
        when(bookingRepository.save(any(Booking.class))).thenAnswer(inv -> inv.getArgument(0));

        BookingResponse response = bookingService.confirmBooking("booking-1");

        assertThat(response.getBookingStatus()).isEqualTo(Booking.BookingStatus.CONFIRMED);
        assertThat(response.getPaymentStatus()).isEqualTo(Booking.PaymentStatus.PAID);
        verify(redisLockService).releaseSlotLock(TURF_ID, booking.getBookingDate(),
                LocalTime.of(10, 0), LocalTime.of(12, 0));
    }

    @Test
    @DisplayName("cancelBooking: owner can cancel a pending booking and lock is released")
    void cancelBooking_success_releasesLock() {
        authenticateAs(USER_ID, "CUSTOMER");
        Booking booking = Booking.builder()
                .id("booking-1")
                .userId(USER_ID)
                .venueId(VENUE_ID)
                .turfId(TURF_ID)
                .bookingDate(LocalDate.now().plusDays(1))
                .startTime(LocalTime.of(10, 0))
                .endTime(LocalTime.of(12, 0))
                .paymentStatus(Booking.PaymentStatus.PENDING)
                .bookingStatus(Booking.BookingStatus.PENDING)
                .build();
        when(bookingRepository.findById("booking-1")).thenReturn(Optional.of(booking));
        when(bookingRepository.save(any(Booking.class))).thenAnswer(inv -> inv.getArgument(0));

        BookingResponse response = bookingService.cancelBooking("booking-1", USER_ID);

        assertThat(response.getBookingStatus()).isEqualTo(Booking.BookingStatus.CANCELLED);
        verify(redisLockService).releaseSlotLock(TURF_ID, booking.getBookingDate(),
                LocalTime.of(10, 0), LocalTime.of(12, 0));
    }

    @Test
    @DisplayName("cancelBooking: non-owner non-admin throws UnauthorizedException")
    void cancelBooking_notOwner_throwsException() {
        authenticateAs("intruder", "CUSTOMER");
        Booking booking = Booking.builder()
                .id("booking-1")
                .userId(USER_ID)
                .venueId(VENUE_ID)
                .turfId(TURF_ID)
                .bookingStatus(Booking.BookingStatus.PENDING)
                .paymentStatus(Booking.PaymentStatus.PENDING)
                .build();
        when(bookingRepository.findById("booking-1")).thenReturn(Optional.of(booking));

        assertThatThrownBy(() -> bookingService.cancelBooking("booking-1", "intruder"))
                .isInstanceOf(UnauthorizedException.class)
                .hasMessageContaining("permission");

        verify(bookingRepository, never()).save(any());
        verify(redisLockService, never()).releaseSlotLock(any(), any(), any(), any());
    }

    @Test
    @DisplayName("cancelBooking: confirmed booking with a past date throws BadRequestException")
    void cancelBooking_pastConfirmed_throwsBadRequest() {
        authenticateAs(USER_ID, "CUSTOMER");
        Booking booking = Booking.builder()
                .id("booking-1")
                .userId(USER_ID)
                .venueId(VENUE_ID)
                .turfId(TURF_ID)
                .bookingDate(LocalDate.now().minusDays(2))
                .startTime(LocalTime.of(10, 0))
                .endTime(LocalTime.of(12, 0))
                .bookingStatus(Booking.BookingStatus.CONFIRMED)
                .paymentStatus(Booking.PaymentStatus.PAID)
                .build();
        when(bookingRepository.findById("booking-1")).thenReturn(Optional.of(booking));

        assertThatThrownBy(() -> bookingService.cancelBooking("booking-1", USER_ID))
                .isInstanceOf(BadRequestException.class)
                .hasMessageContaining("after its date has passed");

        verify(bookingRepository, never()).save(any());
    }
}