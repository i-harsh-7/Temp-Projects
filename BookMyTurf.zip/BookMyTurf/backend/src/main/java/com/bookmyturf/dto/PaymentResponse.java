package com.bookmyturf.dto;

import com.bookmyturf.entity.Payment;
import lombok.*;

import java.math.BigDecimal;
import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PaymentResponse {

    private String id;

    private String bookingId;

    private String razorpayOrderId;

    private String razorpayPaymentId;

    private String razorpaySignature;

    private BigDecimal amount;

    private String currency;

    private Payment.PaymentStatus status;

    private Instant createdAt;
}
