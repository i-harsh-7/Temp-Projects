import React, { useState } from 'react';
import {
  View,
  Text,
  FlatList,
  RefreshControl,
  Pressable,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { useAllBookings } from '@/hooks/useBookings';
import { formatCurrency, formatDate, getBookingStatusColor } from '@/utils/helpers';
import { Booking } from '@/types';
import CustomButton from '@/components/common/CustomButton';
import EmptyState from '@/components/common/EmptyState';
import SkeletonLoader from '@/components/common/SkeletonLoader';

type StatusFilter = 'ALL' | 'PENDING' | 'CONFIRMED' | 'CANCELLED';

const STATUS_FILTERS: { key: StatusFilter; label: string }[] = [
  { key: 'ALL', label: 'All' },
  { key: 'PENDING', label: 'Pending' },
  { key: 'CONFIRMED', label: 'Confirmed' },
  { key: 'CANCELLED', label: 'Cancelled' },
];

export default function AdminBookings() {
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('ALL');
  const [page, setPage] = useState(0);
  const [refreshing, setRefreshing] = useState(false);

  const { data: bookingsPage, isLoading, refetch } = useAllBookings({
    page,
    size: 10,
    status: statusFilter === 'ALL' ? undefined : statusFilter,
  });

  const handleRefresh = async () => {
    setRefreshing(true);
    setPage(0);
    await refetch();
    setRefreshing(false);
  };

  const handleFilterChange = (filter: StatusFilter) => {
    setStatusFilter(filter);
    setPage(0);
  };

  const bookings = bookingsPage?.content ?? [];

  const totalRevenue = bookings.reduce((sum, b) => sum + (b.amount ?? 0), 0);

  const renderBooking = ({ item }: { item: Booking }) => {
    const statusColor = getBookingStatusColor(item.bookingStatus);

    return (
      <View className="bg-card rounded-xl p-4 mb-3">
        {/* Top row: booking number + status badge */}
        <View className="flex-row items-center justify-between mb-2">
          <Text className="text-muted text-xs">#{item.bookingNumber}</Text>
          <View
            className="px-2 py-0.5 rounded-full"
            style={{ backgroundColor: statusColor + '33' }}
          >
            <Text className="text-xs font-medium" style={{ color: statusColor }}>
              {item.bookingStatus}
            </Text>
          </View>
        </View>

        {/* Venue + Turf */}
        <Text className="text-white font-semibold text-base" numberOfLines={1}>
          {item.venueName}
        </Text>
        <Text className="text-muted text-sm mt-0.5" numberOfLines={1}>
          {item.turfName}
        </Text>

        {/* Date + Time */}
        <View className="flex-row items-center mt-2 gap-3">
          <Text className="text-muted text-xs">{formatDate(item.bookingDate)}</Text>
          <Text className="text-muted text-xs">
            {item.startTime} – {item.endTime}
          </Text>
        </View>

        {/* Amount */}
        <Text className="text-primary font-bold text-base mt-2">
          {formatCurrency(item.amount)}
        </Text>
      </View>
    );
  };

  return (
    <SafeAreaView className="flex-1 bg-dark">
      {/* Header */}
      <View className="px-4 pt-4 pb-2">
        <Text className="text-white text-2xl font-bold">All Bookings</Text>
      </View>

      {/* Revenue Summary Card */}
      <View className="bg-card rounded-xl p-4 mx-4 mb-4">
        <Text className="text-muted text-xs mb-1">Total Revenue (filtered)</Text>
        <Text className="text-white text-xl font-bold">{formatCurrency(totalRevenue)}</Text>
        <Text className="text-muted text-xs mt-1">
          {bookingsPage?.totalElements ?? 0} booking{(bookingsPage?.totalElements ?? 0) !== 1 ? 's' : ''}
        </Text>
      </View>

      {/* Status Filter Tabs */}
      <View className="mb-2">
        <FlatList
          horizontal
          data={STATUS_FILTERS}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: 16, gap: 8 }}
          keyExtractor={(item) => item.key}
          renderItem={({ item }) => (
            <Pressable
              onPress={() => handleFilterChange(item.key)}
              className="px-4 py-2 rounded-full"
              style={{
                backgroundColor: statusFilter === item.key ? '#1DB954' : '#1A1A1A',
                borderWidth: 1,
                borderColor: statusFilter === item.key ? '#1DB954' : '#303030',
              }}
            >
              <Text
                className="text-sm font-medium"
                style={{ color: statusFilter === item.key ? '#0F0F0F' : '#6B7280' }}
              >
                {item.label}
              </Text>
            </Pressable>
          )}
        />
      </View>

      {/* Bookings List */}
      {isLoading && !bookingsPage ? (
        <View className="px-4 mt-2">
          <SkeletonLoader variant="list" count={5} />
        </View>
      ) : (
        <FlatList
          data={bookings}
          keyExtractor={(item) => item.id}
          renderItem={renderBooking}
          contentContainerStyle={{ paddingHorizontal: 16, paddingTop: 8, paddingBottom: 24 }}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={handleRefresh}
              tintColor="#1DB954"
            />
          }
          ListEmptyComponent={
            <EmptyState
              icon="calendar-outline"
              title="No bookings found"
              subtitle="No bookings match the selected filter"
            />
          }
          ListFooterComponent={
            bookingsPage && page < bookingsPage.totalPages - 1 ? (
              <CustomButton
                title="Load More"
                onPress={() => setPage((p) => p + 1)}
                variant="outline"
                size="sm"
                fullWidth
              />
            ) : null
          }
        />
      )}
    </SafeAreaView>
  );
}
