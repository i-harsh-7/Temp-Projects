import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Pressable,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import DateTimePicker, {
  DateTimePickerEvent,
} from '@react-native-community/datetimepicker';
import Toast from 'react-native-toast-message';

import { useCreateTurf } from '@/hooks/useTurfs';
import { turfService } from '@/services/turfService';
import { SPORTS, AMENITIES, SPORT_COLORS } from '@/utils/constants';
import { formatTime } from '@/utils/helpers';
import CustomButton from '@/components/common/CustomButton';
import CustomInput from '@/components/common/CustomInput';
import MultiSelect from '@/components/common/MultiSelect';
import ImageUploader from '@/components/common/ImageUploader';

// ---------------------------------------------------------------------------
// Schema
// ---------------------------------------------------------------------------
const schema = z.object({
  name: z.string().min(2, 'Name required'),
  sport: z.string().min(1, 'Select a sport'),
  pricePerHour: z
    .number({ invalid_type_error: 'Enter a valid price' })
    .positive('Price must be positive'),
  openingTime: z.string().min(1, 'Required'),
  closingTime: z.string().min(1, 'Required'),
  amenities: z.array(z.string()),
});

type FormData = z.infer<typeof schema>;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function dateToHHMM(date: Date): string {
  const h = date.getHours().toString().padStart(2, '0');
  const m = date.getMinutes().toString().padStart(2, '0');
  return `${h}:${m}`;
}

function hhmmToDate(hhmm: string): Date {
  const [h, m] = hhmm.split(':').map(Number);
  const d = new Date();
  d.setHours(h, m, 0, 0);
  return d;
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------
export default function CreateTurfScreen() {
  const router = useRouter();
  const { venueId } = useLocalSearchParams<{ venueId: string }>();

  const { mutate: createTurf, isPending } = useCreateTurf();

  const [images, setImages] = useState<string[]>([]);
  const [showOpenPicker, setShowOpenPicker] = useState(false);
  const [showClosePicker, setShowClosePicker] = useState(false);

  const {
    control,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      name: '',
      sport: '',
      pricePerHour: undefined as unknown as number,
      openingTime: '',
      closingTime: '',
      amenities: [],
    },
  });

  const selectedSport = watch('sport');
  const openingTime = watch('openingTime');
  const closingTime = watch('closingTime');

  // ---------------------------------------------------------------------------
  // Submit
  // ---------------------------------------------------------------------------
  const onSubmit = (data: FormData) => {
    if (!venueId) {
      Toast.show({ type: 'error', text1: 'Missing venue ID' });
      return;
    }

    createTurf(
      { ...data, venueId },
      {
        onSuccess: async (response) => {
          const newTurf = response.data;

          // Upload images if any were selected
          if (images.length > 0) {
            try {
              const formData = new FormData();
              images.forEach((uri, index) => {
                const filename = uri.split('/').pop() ?? `image_${index}.jpg`;
                const match = /\.(\w+)$/.exec(filename);
                const type = match ? `image/${match[1]}` : 'image/jpeg';
                formData.append('files', { uri, name: filename, type } as any);
              });
              await turfService.uploadTurfImages(newTurf.id, formData);
            } catch {
              // Image upload failure is non-fatal — turf was created
              Toast.show({
                type: 'info',
                text1: 'Turf created',
                text2: 'Images could not be uploaded.',
              });
              router.back();
              return;
            }
          }

          Toast.show({
            type: 'success',
            text1: 'Turf created',
            text2: `${data.name} has been added successfully.`,
          });
          router.back();
        },
        onError: () => {
          Toast.show({
            type: 'error',
            text1: 'Create failed',
            text2: 'Could not create turf. Please try again.',
          });
        },
      }
    );
  };

  // ---------------------------------------------------------------------------
  // Time picker handlers
  // ---------------------------------------------------------------------------
  const handleOpenTimeChange = (
    _event: DateTimePickerEvent,
    date?: Date
  ) => {
    if (Platform.OS === 'android') setShowOpenPicker(false);
    if (date) setValue('openingTime', dateToHHMM(date), { shouldValidate: true });
  };

  const handleCloseTimeChange = (
    _event: DateTimePickerEvent,
    date?: Date
  ) => {
    if (Platform.OS === 'android') setShowClosePicker(false);
    if (date) setValue('closingTime', dateToHHMM(date), { shouldValidate: true });
  };

  // ---------------------------------------------------------------------------
  // Render
  // ---------------------------------------------------------------------------
  return (
    <SafeAreaView className="flex-1 bg-dark">
      {/* Header */}
      <View className="flex-row items-center px-4 py-3 border-b border-dark-200">
        <Pressable
          onPress={() => router.back()}
          className="w-9 h-9 items-center justify-center rounded-full bg-dark-100 mr-3"
          hitSlop={8}
        >
          <Ionicons name="chevron-back" size={20} color="#FFFFFF" />
        </Pressable>
        <Text className="text-white font-bold text-lg">Add Turf</Text>
      </View>

      <ScrollView
        className="flex-1"
        contentContainerStyle={{ padding: 16, paddingBottom: 48 }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* ── Name ── */}
        <Controller
          control={control}
          name="name"
          render={({ field: { onChange, onBlur, value } }) => (
            <CustomInput
              label="Turf Name"
              placeholder="e.g. Main Football Ground"
              value={value}
              onChangeText={onChange}
              onBlur={onBlur}
              error={errors.name?.message}
              containerClassName="mb-4"
            />
          )}
        />

        {/* ── Sport ── */}
        <View className="mb-4">
          <Text className="text-white text-sm font-medium mb-2">Sport</Text>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ gap: 8 }}
          >
            {SPORTS.map((sport) => {
              const isSelected = selectedSport === sport;
              const color = SPORT_COLORS[sport] ?? '#6B7280';
              return (
                <TouchableOpacity
                  key={sport}
                  onPress={() =>
                    setValue('sport', sport, { shouldValidate: true })
                  }
                  style={{
                    paddingHorizontal: 16,
                    paddingVertical: 8,
                    borderRadius: 999,
                    backgroundColor: isSelected ? color : '#1A1A1A',
                    borderWidth: 1,
                    borderColor: isSelected ? color : '#374151',
                  }}
                  activeOpacity={0.75}
                >
                  <Text
                    style={{
                      color: isSelected ? '#FFFFFF' : '#6B7280',
                      fontWeight: isSelected ? '600' : '400',
                      fontSize: 13,
                    }}
                  >
                    {sport}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </ScrollView>
          {errors.sport && (
            <Text className="text-red-500 text-xs mt-1">
              {errors.sport.message}
            </Text>
          )}
        </View>

        {/* ── Price Per Hour ── */}
        <Controller
          control={control}
          name="pricePerHour"
          render={({ field: { onChange, onBlur, value } }) => (
            <CustomInput
              label="Price Per Hour (₹)"
              placeholder="e.g. 800"
              value={value ? String(value) : ''}
              onChangeText={(text) => {
                const parsed = parseFloat(text);
                onChange(isNaN(parsed) ? undefined : parsed);
              }}
              onBlur={onBlur}
              keyboardType="numeric"
              error={errors.pricePerHour?.message}
              containerClassName="mb-4"
              leftIcon={
                <Text style={{ color: '#6B7280', fontSize: 15 }}>₹</Text>
              }
            />
          )}
        />

        {/* ── Opening Time ── */}
        <View className="mb-4">
          <Text className="text-white text-sm font-medium mb-2">
            Opening Time
          </Text>
          <TouchableOpacity
            onPress={() => setShowOpenPicker(true)}
            className="flex-row items-center bg-dark-100 border border-dark-300 rounded-xl px-4 py-3"
            activeOpacity={0.7}
          >
            <Ionicons name="time-outline" size={18} color="#6B7280" />
            <Text
              className="ml-2 text-sm"
              style={{ color: openingTime ? '#FFFFFF' : '#6B7280' }}
            >
              {openingTime ? formatTime(openingTime) : 'Select opening time'}
            </Text>
          </TouchableOpacity>
          {errors.openingTime && (
            <Text className="text-red-500 text-xs mt-1">
              {errors.openingTime.message}
            </Text>
          )}
          {showOpenPicker && (
            <DateTimePicker
              mode="time"
              value={openingTime ? hhmmToDate(openingTime) : new Date()}
              is24Hour={false}
              display={Platform.OS === 'ios' ? 'spinner' : 'default'}
              onChange={handleOpenTimeChange}
              themeVariant="dark"
            />
          )}
          {Platform.OS === 'ios' && showOpenPicker && (
            <TouchableOpacity
              onPress={() => setShowOpenPicker(false)}
              className="mt-2 items-end"
            >
              <Text className="text-primary font-semibold">Done</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* ── Closing Time ── */}
        <View className="mb-4">
          <Text className="text-white text-sm font-medium mb-2">
            Closing Time
          </Text>
          <TouchableOpacity
            onPress={() => setShowClosePicker(true)}
            className="flex-row items-center bg-dark-100 border border-dark-300 rounded-xl px-4 py-3"
            activeOpacity={0.7}
          >
            <Ionicons name="time-outline" size={18} color="#6B7280" />
            <Text
              className="ml-2 text-sm"
              style={{ color: closingTime ? '#FFFFFF' : '#6B7280' }}
            >
              {closingTime ? formatTime(closingTime) : 'Select closing time'}
            </Text>
          </TouchableOpacity>
          {errors.closingTime && (
            <Text className="text-red-500 text-xs mt-1">
              {errors.closingTime.message}
            </Text>
          )}
          {showClosePicker && (
            <DateTimePicker
              mode="time"
              value={closingTime ? hhmmToDate(closingTime) : new Date()}
              is24Hour={false}
              display={Platform.OS === 'ios' ? 'spinner' : 'default'}
              onChange={handleCloseTimeChange}
              themeVariant="dark"
            />
          )}
          {Platform.OS === 'ios' && showClosePicker && (
            <TouchableOpacity
              onPress={() => setShowClosePicker(false)}
              className="mt-2 items-end"
            >
              <Text className="text-primary font-semibold">Done</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* ── Amenities ── */}
        <View className="mb-4">
          <Controller
            control={control}
            name="amenities"
            render={({ field: { onChange, value } }) => (
              <MultiSelect
                label="Amenities"
                options={[...AMENITIES]}
                selected={value}
                onToggle={(option) => {
                  const updated = value.includes(option)
                    ? value.filter((a) => a !== option)
                    : [...value, option];
                  onChange(updated);
                }}
              />
            )}
          />
        </View>

        {/* ── Images ── */}
        <View className="mb-6">
          <ImageUploader
            label="Turf Images (max 3)"
            images={images}
            onImagesChange={setImages}
            maxCount={3}
          />
        </View>

        {/* ── Submit ── */}
        <CustomButton
          title="Create Turf"
          onPress={handleSubmit(onSubmit)}
          variant="primary"
          size="lg"
          loading={isPending}
          fullWidth
        />
      </ScrollView>
    </SafeAreaView>
  );
}
