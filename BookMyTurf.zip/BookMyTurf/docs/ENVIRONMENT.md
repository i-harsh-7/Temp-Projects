# Environment Variables Reference

All backend variables are consumed by `backend/src/main/resources/application.yml`. Each has a default
(shown below); production deployments **must** override the secrets.

---

## Backend

| Variable | Description | Example | Required |
| --- | --- | --- | --- |
| `MONGO_URI` | MongoDB connection string (must end with the `bookmyturf` DB name) | `mongodb://localhost:27017/bookmyturf` | No (defaults to local) |
| `REDIS_HOST` | Redis host used for distributed slot locks | `localhost` | No |
| `REDIS_PORT` | Redis port | `6379` | No |
| `JWT_SECRET` | Secret key for signing/verifying JWT access tokens (HMAC-SHA256) | `a-long-random-base64-string-at-least-32-bytes` | **Yes in prod** |
| `JWT_EXPIRY` | Access-token lifetime in **milliseconds** | `900000` (15 min) | No |
| `JWT_REFRESH_EXPIRY` | Refresh-token lifetime in **milliseconds** | `604800000` (7 days) | No |
| `CLOUDINARY_CLOUD_NAME` | Cloudinary cloud name | `dxyz1234` | For image upload |
| `CLOUDINARY_API_KEY` | Cloudinary API key | `123456789012345` | For image upload |
| `CLOUDINARY_API_SECRET` | Cloudinary API secret | `aBcD...` | For image upload |
| `RAZORPAY_KEY_ID` | Razorpay key id (test or live) | `rzp_test_abcdef123456` | For payments |
| `RAZORPAY_KEY_SECRET` | Razorpay key secret (also used for signature verification) | `xYz...` | For payments |

> Defaults present in `application.yml`: `MONGO_URI`, `REDIS_HOST`, `REDIS_PORT`, `JWT_SECRET` (dev key),
> `JWT_EXPIRY`, `JWT_REFRESH_EXPIRY` all default for local dev. Cloudinary and Razorpay values default to
> **empty** — set them to use those features. The server also runs on port `8080` with context-path `/api`.

---

## Frontend

| Variable | Description | Example | Required |
| --- | --- | --- | --- |
| `EXPO_PUBLIC_API_URL` | Base URL of the backend REST API (include `/api`) | `http://localhost:8080/api` | Yes |

> Expo only exposes variables prefixed with `EXPO_PUBLIC_` to the client bundle. If unset, the app falls
> back to `http://localhost:8080/api`. On a physical device, use your machine's LAN IP; on the Android
> emulator use `http://10.0.2.2:8080/api`.

---

## Example `.env` files

### `backend/.env`

```env
# --- Database ---
MONGO_URI=mongodb://localhost:27017/bookmyturf

# --- Redis (distributed slot locking) ---
REDIS_HOST=localhost
REDIS_PORT=6379

# --- JWT ---
JWT_SECRET=replace-with-a-long-random-secret-at-least-32-bytes
JWT_EXPIRY=900000
JWT_REFRESH_EXPIRY=604800000

# --- Cloudinary (image uploads) ---
CLOUDINARY_CLOUD_NAME=your-cloud-name
CLOUDINARY_API_KEY=your-api-key
CLOUDINARY_API_SECRET=your-api-secret

# --- Razorpay (payments, test mode) ---
RAZORPAY_KEY_ID=rzp_test_xxxxxxxxxxxxx
RAZORPAY_KEY_SECRET=your-razorpay-secret
```

### `frontend/.env`

```env
EXPO_PUBLIC_API_URL=http://localhost:8080/api
```

---

## Security notes

- **Never commit secrets.** `.env`, `application-local.yml`, and similar files are git-ignored — keep it
  that way. The example files contain placeholders only.
- **JWT secret length:** the signing key must be at least **256 bits (32 bytes)** for HMAC-SHA256. The
  backend pads shorter keys, but you should always supply a proper-length random secret in production. The
  bundled default is for **development only** and must be overridden.
- **Rotate the Razorpay secret** if it leaks — it is used both to create orders and to verify the payment
  signature; exposure allows forging confirmations.
- **Cloudinary API secret** grants upload/delete rights to your media library — treat it as a credential.
- Use **Razorpay Test Mode** keys for development. Switch to live keys only in production.
- Restrict CORS in production. The default config allows all origins (`*`) which is convenient for dev but
  should be narrowed to your known client origins.