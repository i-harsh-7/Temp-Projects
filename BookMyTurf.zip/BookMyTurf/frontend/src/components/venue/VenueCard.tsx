import React from 'react';
import { View, Text, Pressable } from 'react-native';
import { Image } from 'expo-image';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { Venue } from '@/types';
import { formatCurrency } from '@/utils/helpers';
import { SPORT_COLORS } from '@/utils/constants';

interface VenueCardProps {
  venue: Venue;
  onPress: () => void;
}

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

const PLACEHOLDER_IMAGE = 'https://placehold.co/400x220/1A1A1A/1DB954?text=BookMyTurf';

const VenueCard: React.FC<VenueCardProps> = ({ venue, onPress }) => {
  const scale = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const handlePressIn = () => {
    scale.value = withSpring(0.97, { damping: 15, stiffness: 300 });
  };

  const handlePressOut = () => {
    scale.value = withSpring(1, { damping: 15, stiffness: 300 });
  };

  const visibleSports = venue.sports.slice(0, 3);
  const extraSports = venue.sports.length - 3;

  const coverImage = venue.images.length > 0 ? venue.images[0] : PLACEHOLDER_IMAGE;

  return (
    <AnimatedPressable
      onPress={onPress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      style={animatedStyle}
      className="bg-card rounded-2xl overflow-hidden mb-4 shadow-lg"
    >
      {/* Venue image */}
      <View className="relative">
        <Image
          source={{ uri: coverImage }}
          style={{ width: '100%', height: 180 }}
          contentFit="cover"
          placeholder={PLACEHOLDER_IMAGE}
          transition={300}
        />
        {/* Overlay badge for turf count */}
        <View className="absolute top-3 right-3 bg-black/60 rounded-lg px-2.5 py-1">
          <Text className="text-white text-xs font-medium">
            {venue.turfCount} {venue.turfCount === 1 ? 'Turf' : 'Turfs'}
          </Text>
        </View>
        {!venue.approved && (
          <View className="absolute top-3 left-3 bg-warning/90 rounded-lg px-2.5 py-1">
            <Text className="text-dark text-xs font-semibold">Pending</Text>
          </View>
        )}
      </View>

      {/* Content */}
      <View className="p-4">
        <Text
          className="text-white text-lg font-bold"
          numberOfLines={1}
        >
          {venue.name}
        </Text>

        <View className="flex-row items-center mt-1">
          <Ionicons name="location-outline" size={14} color="#6B7280" />
          <Text className="text-muted text-sm ml-1 flex-1" numberOfLines={1}>
            {venue.city}
          </Text>
        </View>

        {/* Sports tags */}
        <View className="flex-row flex-wrap gap-1.5 mt-3">
          {visibleSports.map((sport) => (
            <View
              key={sport}
              className="rounded-full px-3 py-1"
              style={{
                backgroundColor: `${SPORT_COLORS[sport] ?? '#1DB954'}20`,
                borderWidth: 1,
                borderColor: `${SPORT_COLORS[sport] ?? '#1DB954'}60`,
              }}
            >
              <Text
                className="text-xs font-medium"
                style={{ color: SPORT_COLORS[sport] ?? '#1DB954' }}
              >
                {sport}
              </Text>
            </View>
          ))}
          {extraSports > 0 && (
            <View className="bg-dark-300 rounded-full px-3 py-1">
              <Text className="text-muted text-xs font-medium">
                +{extraSports} more
              </Text>
            </View>
          )}
        </View>

        {/* Divider */}
        <View className="h-px bg-dark-300 mt-3" />

        {/* Footer row */}
        <View className="flex-row items-center justify-between mt-3">
          <View className="flex-row items-center">
            <Ionicons name="star" size={14} color="#F59E0B" />
            <Text className="text-white text-sm font-medium ml-1">4.5</Text>
            <Text className="text-muted text-xs ml-1">(120 reviews)</Text>
          </View>
          <Text className="text-primary text-sm font-bold">
            From {formatCurrency(500)}/hr
          </Text>
        </View>
      </View>
    </AnimatedPressable>
  );
};

export default VenueCard;
