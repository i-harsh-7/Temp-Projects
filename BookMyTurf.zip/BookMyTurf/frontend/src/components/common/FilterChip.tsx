import React from 'react';
import { TouchableOpacity, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SPORT_COLORS } from '@/utils/constants';

interface FilterChipProps {
  label: string;
  selected: boolean;
  onPress: () => void;
  sport?: boolean;
  icon?: React.ComponentProps<typeof Ionicons>['name'];
  count?: number;
}

const FilterChip: React.FC<FilterChipProps> = ({
  label,
  selected,
  onPress,
  sport = false,
  icon,
  count,
}) => {
  const sportColor = sport ? (SPORT_COLORS[label] ?? '#1DB954') : '#1DB954';

  const containerStyle = selected
    ? sport
      ? {
          backgroundColor: `${sportColor}20`,
          borderWidth: 1.5,
          borderColor: sportColor,
        }
      : {
          backgroundColor: '#1DB95420',
          borderWidth: 1.5,
          borderColor: '#1DB954',
        }
    : {
        backgroundColor: '#252525',
        borderWidth: 1,
        borderColor: '#303030',
      };

  const textColor = selected ? (sport ? sportColor : '#1DB954') : '#9CA3AF';

  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.7}
      style={[
        {
          flexDirection: 'row',
          alignItems: 'center',
          paddingHorizontal: 14,
          paddingVertical: 7,
          borderRadius: 20,
          marginRight: 8,
        },
        containerStyle,
      ]}
    >
      {icon && (
        <Ionicons
          name={icon}
          size={13}
          color={textColor}
          style={{ marginRight: 5 }}
        />
      )}
      <Text style={{ fontSize: 13, fontWeight: selected ? '600' : '400', color: textColor }}>
        {label}
      </Text>
      {count !== undefined && count > 0 && (
        <View
          style={{
            backgroundColor: selected ? sportColor : '#3A3A3A',
            borderRadius: 10,
            minWidth: 18,
            height: 18,
            alignItems: 'center',
            justifyContent: 'center',
            marginLeft: 6,
            paddingHorizontal: 4,
          }}
        >
          <Text style={{ fontSize: 11, fontWeight: '700', color: '#fff' }}>
            {count}
          </Text>
        </View>
      )}
    </TouchableOpacity>
  );
};

export default FilterChip;
