package com.bookmyturf.dto;

import com.bookmyturf.entity.User;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserResponse {

    private String id;

    private String name;

    private String email;

    private String phone;

    private User.Role role;

    private String profileImage;
}
