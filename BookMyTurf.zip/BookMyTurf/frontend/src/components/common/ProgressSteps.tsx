import React, { useEffect } from 'react'
import { View, Text } from 'react-native'
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withSequence,
  withTiming,
} from 'react-native-reanimated'
import { Ionicons } from '@expo/vector-icons'

interface ProgressStepsProps {
  steps: string[]
  currentStep: number
}

function StepCircle({
  index,
  currentStep,
  total,
}: {
  index: number
  currentStep: number
  total: number
}) {
  const scale = useSharedValue(1)
  const isCompleted = index < currentStep
  const isCurrent = index === currentStep

  useEffect(() => {
    if (isCurrent) {
      scale.value = withRepeat(
        withSequence(
          withTiming(1.15, { duration: 600 }),
          withTiming(1, { duration: 600 })
        ),
        -1,
        false
      )
    } else {
      scale.value = withTiming(1, { duration: 200 })
    }
  }, [isCurrent])

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }))

  return (
    <Animated.View
      style={[
        {
          width: 24,
          height: 24,
          borderRadius: 12,
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor:
            isCompleted || isCurrent ? '#1DB954' : 'transparent',
          borderWidth: isCompleted || isCurrent ? 0 : 1.5,
          borderColor: '#374151',
        },
        isCurrent && animatedStyle,
      ]}
    >
      {isCompleted ? (
        <Ionicons name="checkmark" size={14} color="#FFFFFF" />
      ) : (
        <Text
          style={{
            color: isCurrent ? '#FFFFFF' : '#6B7280',
            fontSize: 11,
            fontWeight: '700',
          }}
        >
          {index + 1}
        </Text>
      )}
    </Animated.View>
  )
}

export default function ProgressSteps({ steps, currentStep }: ProgressStepsProps) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'flex-start' }}>
      {steps.map((step, index) => (
        <React.Fragment key={step + index}>
          <View style={{ alignItems: 'center', flex: index === steps.length - 1 ? 0 : undefined }}>
            <StepCircle index={index} currentStep={currentStep} total={steps.length} />
            <Text
              style={{
                color:
                  index <= currentStep ? '#FFFFFF' : '#6B7280',
                fontSize: 10,
                marginTop: 4,
                textAlign: 'center',
                maxWidth: 60,
              }}
            >
              {step}
            </Text>
          </View>

          {index < steps.length - 1 && (
            <View
              style={{
                flex: 1,
                height: 1.5,
                marginTop: 11,
                backgroundColor:
                  index < currentStep ? '#1DB954' : '#374151',
              }}
            />
          )}
        </React.Fragment>
      ))}
    </View>
  )
}
