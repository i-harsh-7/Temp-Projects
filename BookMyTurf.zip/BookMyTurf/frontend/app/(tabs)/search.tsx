import React, { useState, useCallback, useRef, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  ScrollView,
  Modal,
  RefreshControl,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useSearchStore } from '@/store/searchStore';
import { useVenues, useSearchVenues } from '@/hooks/useVenues';
import VenueCard from '@/components/venue/VenueCard';
import SearchBar from '@/components/common/SearchBar';
import FilterChip from '@/components/common/FilterChip';
import SkeletonLoader from '@/components/common/SkeletonLoader';
import EmptyState from '@/components/common/EmptyState';
import { SPORTS, CITIES, SORT_OPTIONS, DEFAULT_PRICE_RANGE } from '@/utils/constants';
import { Venue } from '@/types';

const PAGE_SIZE = 10;

export default function SearchScreen() {
  const {
    searchQuery,
    setSearchQuery,
    selectedCity,
    setCity,
    selectedSport,
    setSport,
    priceRange,
    setPriceRange,
    sortBy,
    setSortBy,
    resetFilters,
  } = useSearchStore();

  const [filterModalVisible, setFilterModalVisible] = useState(false);
  const [localMinPrice, setLocalMinPrice] = useState(priceRange.min);
  const [localMaxPrice, setLocalMaxPrice] = useState(priceRange.max);
  const [localSports, setLocalSports] = useState<string[]>(
    selectedSport ? [selectedSport] : []
  );
  const [localCity, setLocalCity] = useState(selectedCity ?? '');
  const [localSort, setLocalSort] = useState(sortBy);
  const [page, setPage] = useState(0);

  const debounceTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [debouncedQuery, setDebouncedQuery] = useState(searchQuery);

  useEffect(() => {
    if (debounceTimer.current) clearTimeout(debounceTimer.current);
    debounceTimer.current = setTimeout(() => {
      setDebouncedQuery(searchQuery);
      setPage(0);
    }, 300);
    return () => {
      if (debounceTimer.current) clearTimeout(debounceTimer.current);
    };
  }, [searchQuery]);

  const searchParams = {
    city: selectedCity ?? undefined,
    sport: selectedSport ?? undefined,
    minPrice: priceRange.min > 0 ? priceRange.min : undefined,
    maxPrice: priceRange.max < DEFAULT_PRICE_RANGE.max ? priceRange.max : undefined,
    sortBy: sortBy !== 'relevance' ? sortBy : undefined,
    page,
    size: PAGE_SIZE,
  };

  const isSearching = debouncedQuery.length >= 2;

  const {
    data: browsData,
    isLoading: browsLoading,
    refetch: refetchBrows,
    isRefetching,
  } = useVenues(isSearching ? undefined : searchParams);

  const {
    data: searchData,
    isLoading: searchLoading,
  } = useSearchVenues(debouncedQuery, isSearching ? searchParams : undefined);

  const rawData = isSearching ? searchData : browsData;
  const isLoading = isSearching ? searchLoading : browsLoading;

  const venues: Venue[] = (rawData as any)?.content ?? [];
  const totalPages: number = (rawData as any)?.totalPages ?? 0;
  const isLastPage = page >= totalPages - 1;

  const [allVenues, setAllVenues] = useState<Venue[]>([]);

  useEffect(() => {
    if (page === 0) {
      setAllVenues(venues);
    } else {
      setAllVenues((prev) => {
        const ids = new Set(prev.map((v) => v.id));
        return [...prev, ...venues.filter((v) => !ids.has(v.id))];
      });
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [venues]);

  const loadMore = () => {
    if (!isLoading && !isLastPage) {
      setPage((p) => p + 1);
    }
  };

  const applyFilters = () => {
    setSport(localSports[0] ?? null);
    setCity(localCity || null);
    setPriceRange({ min: localMinPrice, max: localMaxPrice });
    setSortBy(localSort);
    setPage(0);
    setFilterModalVisible(false);
  };

  const clearFilters = () => {
    resetFilters();
    setLocalSports([]);
    setLocalCity('');
    setLocalMinPrice(0);
    setLocalMaxPrice(DEFAULT_PRICE_RANGE.max);
    setLocalSort('relevance');
    setPage(0);
    setFilterModalVisible(false);
  };

  const activeFilterCount =
    (selectedSport ? 1 : 0) +
    (selectedCity ? 1 : 0) +
    (priceRange.min > 0 || priceRange.max < DEFAULT_PRICE_RANGE.max ? 1 : 0);

  return (
    <SafeAreaView className="flex-1 bg-dark" edges={['top']}>
      {/* Search Header */}
      <View className="px-5 pt-3 pb-2">
        <View className="flex-row items-center gap-3">
          <View className="flex-1">
            <SearchBar
              value={searchQuery}
              onChangeText={(t) => {
                setSearchQuery(t);
                setPage(0);
              }}
              placeholder="Search venues, sports..."
              autoFocus={false}
            />
          </View>
          <TouchableOpacity
            onPress={() => {
              setLocalSports(selectedSport ? [selectedSport] : []);
              setLocalCity(selectedCity ?? '');
              setLocalMinPrice(priceRange.min);
              setLocalMaxPrice(priceRange.max);
              setLocalSort(sortBy);
              setFilterModalVisible(true);
            }}
            className="w-12 h-12 rounded-2xl bg-dark-200 border border-dark-300 items-center justify-center"
          >
            <Ionicons name="options-outline" size={22} color="#fff" />
            {activeFilterCount > 0 && (
              <View className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-primary items-center justify-center">
                <Text className="text-white text-xs font-bold">{activeFilterCount}</Text>
              </View>
            )}
          </TouchableOpacity>
        </View>

        {/* Sport filter chips */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingVertical: 10 }}
          style={{ marginHorizontal: -5 }}
        >
          <View style={{ paddingHorizontal: 5 }}>
            <FilterChip
              label="All Sports"
              selected={!selectedSport}
              onPress={() => { setSport(null); setPage(0); }}
            />
          </View>
          {SPORTS.map((sport) => (
            <FilterChip
              key={sport}
              label={sport}
              selected={selectedSport === sport}
              sport
              onPress={() => {
                setSport(selectedSport === sport ? null : sport);
                setPage(0);
              }}
            />
          ))}
        </ScrollView>

        {/* City / active filters row */}
        {(selectedCity || activeFilterCount > 0) && (
          <View className="flex-row items-center flex-wrap gap-2 mb-2">
            {selectedCity && (
              <View className="flex-row items-center bg-dark-200 rounded-full px-3 py-1.5 border border-dark-300">
                <Ionicons name="location-outline" size={13} color="#1DB954" />
                <Text className="text-white text-xs ml-1.5">{selectedCity}</Text>
                <TouchableOpacity onPress={() => { setCity(null); setPage(0); }} className="ml-1.5">
                  <Ionicons name="close" size={13} color="#6B7280" />
                </TouchableOpacity>
              </View>
            )}
            {activeFilterCount > 0 && (
              <TouchableOpacity onPress={clearFilters}>
                <Text className="text-error text-xs font-medium">Clear all filters</Text>
              </TouchableOpacity>
            )}
          </View>
        )}
      </View>

      {/* Results */}
      {isLoading && page === 0 ? (
        <View className="px-5 flex-1">
          <SkeletonLoader variant="card" count={4} />
        </View>
      ) : allVenues.length === 0 ? (
        <EmptyState
          icon="search-outline"
          title="No venues found"
          subtitle={
            searchQuery
              ? `No venues match "${searchQuery}"`
              : 'Try adjusting your filters'
          }
          actionLabel="Clear Filters"
          onAction={clearFilters}
        />
      ) : (
        <FlatList
          data={allVenues}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 24 }}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={isRefetching}
              onRefresh={() => { setPage(0); refetchBrows(); }}
              tintColor="#1DB954"
              colors={['#1DB954']}
            />
          }
          renderItem={({ item }) => (
            <VenueCard
              venue={item}
              onPress={() => router.push(`/venue/${item.id}`)}
            />
          )}
          onEndReached={loadMore}
          onEndReachedThreshold={0.3}
          ListFooterComponent={
            !isLastPage && isLoading ? (
              <View className="py-4 items-center">
                <ActivityIndicator color="#1DB954" />
              </View>
            ) : null
          }
        />
      )}

      {/* Filter Modal */}
      <Modal
        visible={filterModalVisible}
        animationType="slide"
        transparent
        onRequestClose={() => setFilterModalVisible(false)}
      >
        <View className="flex-1 justify-end bg-black/60">
          <View className="bg-dark-100 rounded-t-3xl px-5 pt-5 pb-8">
            {/* Handle */}
            <View className="w-12 h-1 rounded-full bg-dark-400 self-center mb-5" />

            <View className="flex-row items-center justify-between mb-5">
              <Text className="text-white text-xl font-bold">Filters</Text>
              <TouchableOpacity onPress={() => setFilterModalVisible(false)}>
                <Ionicons name="close" size={24} color="#fff" />
              </TouchableOpacity>
            </View>

            <ScrollView showsVerticalScrollIndicator={false}>
              {/* Sort */}
              <Text className="text-white text-sm font-semibold mb-3">Sort By</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} className="mb-5">
                {SORT_OPTIONS.map((opt) => (
                  <FilterChip
                    key={opt.value}
                    label={opt.label}
                    selected={localSort === opt.value}
                    onPress={() => setLocalSort(opt.value)}
                  />
                ))}
              </ScrollView>

              {/* Sports */}
              <Text className="text-white text-sm font-semibold mb-3">Sport</Text>
              <View className="flex-row flex-wrap mb-5">
                {SPORTS.map((sport) => (
                  <View key={sport} className="mb-2">
                    <FilterChip
                      label={sport}
                      selected={localSports.includes(sport)}
                      sport
                      onPress={() => {
                        setLocalSports(
                          localSports.includes(sport) ? [] : [sport]
                        );
                      }}
                    />
                  </View>
                ))}
              </View>

              {/* City */}
              <Text className="text-white text-sm font-semibold mb-3">City</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} className="mb-5">
                <FilterChip
                  label="All Cities"
                  selected={!localCity}
                  onPress={() => setLocalCity('')}
                />
                {CITIES.map((city) => (
                  <FilterChip
                    key={city}
                    label={city}
                    selected={localCity === city}
                    onPress={() => setLocalCity(localCity === city ? '' : city)}
                  />
                ))}
              </ScrollView>

              {/* Price range (simple inputs) */}
              <Text className="text-white text-sm font-semibold mb-3">
                Price Range: ₹{localMinPrice} – ₹{localMaxPrice}
              </Text>
              <View className="flex-row gap-3 mb-5">
                {[
                  { label: '₹0–₹500', min: 0, max: 500 },
                  { label: '₹500–₹1500', min: 500, max: 1500 },
                  { label: '₹1500–₹3000', min: 1500, max: 3000 },
                  { label: '₹3000+', min: 3000, max: 5000 },
                ].map((range) => (
                  <TouchableOpacity
                    key={range.label}
                    onPress={() => {
                      setLocalMinPrice(range.min);
                      setLocalMaxPrice(range.max);
                    }}
                    className="flex-1 py-2.5 rounded-xl border items-center"
                    style={{
                      borderColor:
                        localMinPrice === range.min && localMaxPrice === range.max
                          ? '#1DB954'
                          : '#303030',
                      backgroundColor:
                        localMinPrice === range.min && localMaxPrice === range.max
                          ? '#1DB95420'
                          : '#252525',
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 12,
                        color:
                          localMinPrice === range.min && localMaxPrice === range.max
                            ? '#1DB954'
                            : '#9CA3AF',
                        fontWeight: '500',
                      }}
                    >
                      {range.label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>

            {/* Buttons */}
            <View className="flex-row gap-3 mt-2">
              <TouchableOpacity
                onPress={clearFilters}
                className="flex-1 py-3.5 rounded-xl border border-dark-300 items-center"
              >
                <Text className="text-white font-semibold">Reset</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={applyFilters}
                className="flex-1 py-3.5 rounded-xl bg-primary items-center"
              >
                <Text className="text-white font-bold">Apply Filters</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}
