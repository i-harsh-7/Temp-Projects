import { api } from './api';
import {
  ApiResponse,
  Payment,
  CreateOrderRequest,
  VerifyPaymentRequest,
} from '@/types';

interface RazorpayOrder {
  id: string;
  amount: number;
  currency: string;
  receipt: string;
  bookingId: string;
}

export const paymentService = {
  createOrder: async (
    bookingId: string
  ): Promise<ApiResponse<RazorpayOrder>> => {
    const data: CreateOrderRequest = { bookingId };
    const response = await api.post<ApiResponse<RazorpayOrder>>(
      '/payments/create-order',
      data
    );
    return response.data;
  },

  verifyPayment: async (
    data: VerifyPaymentRequest
  ): Promise<ApiResponse<Payment>> => {
    const response = await api.post<ApiResponse<Payment>>(
      '/payments/verify',
      data
    );
    return response.data;
  },

  getPaymentById: async (id: string): Promise<ApiResponse<Payment>> => {
    const response = await api.get<ApiResponse<Payment>>(`/payments/${id}`);
    return response.data;
  },

  getPaymentByBookingId: async (
    bookingId: string
  ): Promise<ApiResponse<Payment>> => {
    const response = await api.get<ApiResponse<Payment>>(
      `/payments/booking/${bookingId}`
    );
    return response.data;
  },

  initiateRefund: async (
    paymentId: string
  ): Promise<ApiResponse<Payment>> => {
    const response = await api.post<ApiResponse<Payment>>(
      `/payments/${paymentId}/refund`
    );
    return response.data;
  },
};
