package com.bookmyturf.service;

import com.bookmyturf.dto.TimeSlot;
import com.bookmyturf.entity.Booking;
import com.bookmyturf.repository.BookingRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class SlotService {

    private final BookingRepository bookingRepository;

    public boolean checkSlotAvailability(String turfId, LocalDate date, LocalTime startTime, LocalTime endTime) {
        log.debug("Checking slot availability: turfId={}, date={}, {}–{}", turfId, date, startTime, endTime);
        List<Booking> overlapping = bookingRepository.findOverlappingBookings(turfId, date, startTime, endTime);
        boolean available = overlapping.stream()
                .noneMatch(b -> b.getBookingStatus() != Booking.BookingStatus.CANCELLED);
        log.debug("Slot availability result: {}", available);
        return available;
    }

    public List<TimeSlot> getBookedSlots(String turfId, LocalDate date) {
        log.debug("Getting booked slots: turfId={}, date={}", turfId, date);
        return bookingRepository.findByTurfIdAndBookingDate(turfId, date).stream()
                .filter(b -> b.getBookingStatus() != Booking.BookingStatus.CANCELLED)
                .map(b -> TimeSlot.builder()
                        .startTime(b.getStartTime())
                        .endTime(b.getEndTime())
                        .available(false)
                        .build())
                .toList();
    }
}
