package com.bookmyturf.integration;

import com.bookmyturf.cloudinary.CloudinaryService;
import com.bookmyturf.dto.AuthResponse;
import com.bookmyturf.dto.CreateBookingRequest;
import com.bookmyturf.dto.CreateTurfRequest;
import com.bookmyturf.dto.CreateVenueRequest;
import com.bookmyturf.dto.RegisterRequest;
import com.bookmyturf.dto.SlotAvailabilityResponse;
import com.bookmyturf.dto.BookingResponse;
import com.bookmyturf.dto.TurfResponse;
import com.bookmyturf.dto.VenueResponse;
import com.bookmyturf.entity.Booking;
import com.bookmyturf.entity.User;
import com.bookmyturf.entity.Venue;
import com.bookmyturf.exception.ConflictException;
import com.bookmyturf.redis.RedisLockService;
import com.bookmyturf.repository.BookingRepository;
import com.bookmyturf.repository.PaymentRepository;
import com.bookmyturf.repository.RefreshTokenRepository;
import com.bookmyturf.repository.UserRepository;
import com.bookmyturf.repository.VenueRepository;
import com.bookmyturf.service.AuthService;
import com.bookmyturf.service.BookingService;
import com.bookmyturf.service.TurfService;
import com.bookmyturf.service.VenueService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@SpringBootTest
@ActiveProfiles("test")
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@DisplayName("Full booking flow integration test (embedded MongoDB)")
class BookingFlowIntegrationTest {

    @Autowired
    private AuthService authService;
    @Autowired
    private VenueService venueService;
    @Autowired
    private TurfService turfService;
    @Autowired
    private BookingService bookingService;

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private VenueRepository venueRepository;
    @Autowired
    private BookingRepository bookingRepository;
    @Autowired
    private RefreshTokenRepository refreshTokenRepository;
    @Autowired
    private PaymentRepository paymentRepository;

    // Replace external/infra collaborators so no Redis / Cloudinary is needed.
    @MockBean
    private RedisLockService redisLockService;
    @MockBean
    private CloudinaryService cloudinaryService;

    @BeforeEach
    void cleanDatabase() {
        bookingRepository.deleteAll();
        venueRepository.deleteAll();
        userRepository.deleteAll();
        refreshTokenRepository.deleteAll();
        paymentRepository.deleteAll();

        // Default lock behaviour: first acquisition succeeds. isSlotLocked false so slots show available.
        when(redisLockService.acquireSlotLock(any(), any(), any(), any())).thenReturn(true);
        when(redisLockService.isSlotLocked(any(), any(), any(), any())).thenReturn(false);
    }

    @AfterEach
    void tearDown() {
        bookingRepository.deleteAll();
        venueRepository.deleteAll();
        userRepository.deleteAll();
    }

    @Test
    @DisplayName("end-to-end: register, approve venue, add turf, book, prevent double-booking, confirm")
    void fullBookingFlow() {
        // 1. Register a CUSTOMER and a VENUE_OWNER.
        AuthResponse customerAuth = authService.register(RegisterRequest.builder()
                .name("Carol Customer")
                .email("customer@example.com")
                .password("password123")
                .phone("9876543210")
                .role(User.Role.CUSTOMER)
                .build());
        assertThat(customerAuth.getAccessToken()).isNotBlank();
        String customerId = customerAuth.getUser().getId();
        assertThat(customerId).isNotBlank();

        AuthResponse ownerAuth = authService.register(RegisterRequest.builder()
                .name("Olivia Owner")
                .email("owner@example.com")
                .password("password123")
                .phone("9123456780")
                .role(User.Role.VENUE_OWNER)
                .build());
        String ownerId = ownerAuth.getUser().getId();
        assertThat(ownerId).isNotBlank();

        // 2. Owner creates a venue; admin approves it directly via repository; owner adds a turf.
        VenueResponse venueResponse = venueService.createVenue(CreateVenueRequest.builder()
                .name("Greenfield Arena")
                .address("123 Sports Lane")
                .city("Bengaluru")
                .latitude(12.9716)
                .longitude(77.5946)
                .description("Premium turf venue")
                .amenities(List.of("Parking", "Lighting"))
                .sports(List.of("Football"))
                .build(), ownerId);
        assertThat(venueResponse.isApproved()).isFalse();
        String venueId = venueResponse.getId();

        // Admin approval simulated by setting approved=true directly.
        Venue venue = venueRepository.findById(venueId).orElseThrow();
        venue.setApproved(true);
        venueRepository.save(venue);
        assertThat(venueRepository.findById(venueId).orElseThrow().isApproved()).isTrue();

        TurfResponse turfResponse = turfService.createTurf(CreateTurfRequest.builder()
                .venueId(venueId)
                .name("Turf 1")
                .sport("Football")
                .pricePerHour(new BigDecimal("500"))
                .openingTime(LocalTime.of(6, 0))
                .closingTime(LocalTime.of(23, 0))
                .amenities(List.of("Bibs"))
                .build(), ownerId);
        String turfId = turfResponse.getId();
        assertThat(turfId).isNotBlank();
        assertThat(turfResponse.isActive()).isTrue();

        LocalDate bookingDate = LocalDate.now().plusDays(2);

        // 3. Customer fetches available slots -> slots returned.
        SlotAvailabilityResponse slots = turfService.getAvailableSlots(turfId, bookingDate);
        assertThat(slots.getAvailableSlots()).isNotEmpty();
        assertThat(slots.getAvailableSlots()).allMatch(s -> s.isAvailable());

        // 4. Customer creates a booking -> PENDING with a booking number.
        CreateBookingRequest bookingReq = CreateBookingRequest.builder()
                .turfId(turfId)
                .venueId(venueId)
                .bookingDate(bookingDate)
                .startTime(LocalTime.of(10, 0))
                .endTime(LocalTime.of(12, 0))
                .build();

        BookingResponse firstBooking = bookingService.createBooking(bookingReq, customerId);
        assertThat(firstBooking.getBookingStatus()).isEqualTo(Booking.BookingStatus.PENDING);
        assertThat(firstBooking.getPaymentStatus()).isEqualTo(Booking.PaymentStatus.PENDING);
        assertThat(firstBooking.getBookingNumber()).isNotBlank();
        assertThat(firstBooking.getBookingNumber()).startsWith("BMT");
        assertThat(firstBooking.getAmount()).isEqualByComparingTo(new BigDecimal("1000"));
        assertThat(bookingRepository.findAll()).hasSize(1);

        // 5. A second OVERLAPPING booking for the same slot is rejected (double-booking prevented).
        CreateBookingRequest overlapping = CreateBookingRequest.builder()
                .turfId(turfId)
                .venueId(venueId)
                .bookingDate(bookingDate)
                .startTime(LocalTime.of(11, 0)) // overlaps 10:00-12:00
                .endTime(LocalTime.of(13, 0))
                .build();

        assertThatThrownBy(() -> bookingService.createBooking(overlapping, customerId))
                .isInstanceOf(ConflictException.class);

        // Still only the one booking persisted -> no double booking.
        assertThat(bookingRepository.findAll()).hasSize(1);

        // 6. Confirm the first booking -> CONFIRMED + PAID.
        BookingResponse confirmed = bookingService.confirmBooking(firstBooking.getId());
        assertThat(confirmed.getBookingStatus()).isEqualTo(Booking.BookingStatus.CONFIRMED);
        assertThat(confirmed.getPaymentStatus()).isEqualTo(Booking.PaymentStatus.PAID);

        Booking persisted = bookingRepository.findById(firstBooking.getId()).orElseThrow();
        assertThat(persisted.getBookingStatus()).isEqualTo(Booking.BookingStatus.CONFIRMED);
        assertThat(persisted.getPaymentStatus()).isEqualTo(Booking.PaymentStatus.PAID);
    }
}
