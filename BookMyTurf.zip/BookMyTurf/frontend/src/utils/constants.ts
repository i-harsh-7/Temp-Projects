export const SPORTS = [
  'Football',
  'Cricket',
  'Basketball',
  'Badminton',
  'Tennis',
  'Volleyball',
  'Hockey',
] as const;

export type Sport = (typeof SPORTS)[number];

export const CITIES = [
  'Mumbai',
  'Delhi',
  'Bangalore',
  'Hyderabad',
  'Chennai',
  'Kolkata',
  'Pune',
  'Ahmedabad',
  'Jaipur',
  'Surat',
] as const;

export type City = (typeof CITIES)[number];

export const AMENITIES = [
  'Parking',
  'Changing Room',
  'Cafeteria',
  'Floodlights',
  'First Aid',
  'Washrooms',
  'Drinking Water',
  'CCTV',
  'Locker Room',
  'Equipment Rental',
] as const;

export type Amenity = (typeof AMENITIES)[number];

export const SLOT_DURATION = 60; // minutes

export const BOOKING_LOCK_TTL = 300; // seconds

export const MAX_IMAGES_PER_VENUE = 10;
export const MAX_IMAGES_PER_TURF = 5;

export const SORT_OPTIONS = [
  { label: 'Relevance', value: 'relevance' },
  { label: 'Price: Low to High', value: 'price_asc' },
  { label: 'Price: High to Low', value: 'price_desc' },
  { label: 'Newest First', value: 'newest' },
  { label: 'Most Popular', value: 'popular' },
] as const;

export const DEFAULT_PRICE_RANGE = {
  min: 0,
  max: 5000,
};

export const QUERY_KEYS = {
  VENUES: 'venues',
  VENUE: 'venue',
  MY_VENUES: 'my-venues',
  TURFS: 'turfs',
  TURF: 'turf',
  SLOTS: 'slots',
  BOOKINGS: 'bookings',
  MY_BOOKINGS: 'my-bookings',
  BOOKING: 'booking',
  VENUE_BOOKINGS: 'venue-bookings',
  ALL_BOOKINGS: 'all-bookings',
  PAYMENT: 'payment',
  USER: 'user',
  ADMIN_VENUES: 'admin-venues',
  ADMIN_USERS: 'admin-users',
} as const;

export const SPORT_ICONS: Record<string, string> = {
  Football: 'football',
  Cricket: 'baseball',
  Basketball: 'basketball',
  Badminton: 'tennisball',
  Tennis: 'tennisball',
  Volleyball: 'football-outline',
  Hockey: 'football-outline',
};

export const SPORT_COLORS: Record<string, string> = {
  Football: '#22C55E',
  Cricket: '#F59E0B',
  Basketball: '#F97316',
  Badminton: '#3B82F6',
  Tennis: '#EAB308',
  Volleyball: '#8B5CF6',
  Hockey: '#EC4899',
};

export const APP_NAME = 'BookMyTurf';
export const APP_VERSION = '1.0.0';

export const RAZORPAY_KEY_ID = process.env.EXPO_PUBLIC_RAZORPAY_KEY_ID ?? '';

export const PAGINATION = {
  DEFAULT_PAGE: 0,
  DEFAULT_SIZE: 10,
  MAX_SIZE: 50,
} as const;
