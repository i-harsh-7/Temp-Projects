import React from 'react'
import { View, Text, TouchableOpacity } from 'react-native'
import { Ionicons } from '@expo/vector-icons'

interface MultiSelectProps {
  options: string[]
  selected: string[]
  onToggle: (option: string) => void
  label?: string
  columns?: number // default 3
}

export default function MultiSelect({
  options,
  selected,
  onToggle,
  label,
  columns = 3,
}: MultiSelectProps) {
  return (
    <View>
      {label ? (
        <Text className="text-white text-sm font-medium mb-2">{label}</Text>
      ) : null}
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
        {options.map((option) => {
          const isSelected = selected.includes(option)
          return (
            <TouchableOpacity
              key={option}
              onPress={() => onToggle(option)}
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                paddingHorizontal: 12,
                paddingVertical: 6,
                borderRadius: 999,
                borderWidth: 1,
                backgroundColor: isSelected ? '#1DB954' : '#1A1A1A',
                borderColor: isSelected ? '#1DB954' : '#374151',
                gap: 4,
              }}
            >
              {isSelected && (
                <Ionicons name="checkmark" size={14} color="#FFFFFF" />
              )}
              <Text
                style={{
                  color: isSelected ? '#FFFFFF' : '#6B7280',
                  fontSize: 13,
                  fontWeight: '500',
                }}
              >
                {option}
              </Text>
            </TouchableOpacity>
          )
        })}
      </View>
    </View>
  )
}
