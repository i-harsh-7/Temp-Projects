import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TextInputProps,
  TouchableOpacity,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

interface CustomInputProps extends TextInputProps {
  label?: string;
  error?: string;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  containerClassName?: string;
}

const CustomInput = React.forwardRef<TextInput, CustomInputProps>(
  (
    {
      label,
      error,
      leftIcon,
      rightIcon,
      secureTextEntry,
      containerClassName,
      ...props
    },
    ref
  ) => {
    const [isSecureVisible, setIsSecureVisible] = useState(false);
    const [isFocused, setIsFocused] = useState(false);

    const isSecureEntry = secureTextEntry && !isSecureVisible;

    const borderClass = error
      ? 'border-error'
      : isFocused
      ? 'border-primary'
      : 'border-dark-300';

    return (
      <View className={`mb-4 ${containerClassName ?? ''}`}>
        {label ? (
          <Text className="text-white text-sm font-medium mb-1.5">{label}</Text>
        ) : null}

        <View
          className={`flex-row items-center bg-dark-100 border ${borderClass} rounded-xl px-4 h-14`}
        >
          {leftIcon ? (
            <View className="mr-3">{leftIcon}</View>
          ) : null}

          <TextInput
            ref={ref}
            className="flex-1 text-white text-base"
            placeholderTextColor="#6B7280"
            secureTextEntry={isSecureEntry}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
            selectionColor="#1DB954"
            cursorColor="#1DB954"
            {...props}
          />

          {secureTextEntry ? (
            <TouchableOpacity
              onPress={() => setIsSecureVisible((prev) => !prev)}
              className="ml-2 p-1"
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
            >
              <Ionicons
                name={isSecureVisible ? 'eye-off-outline' : 'eye-outline'}
                size={20}
                color="#6B7280"
              />
            </TouchableOpacity>
          ) : rightIcon ? (
            <View className="ml-2">{rightIcon}</View>
          ) : null}
        </View>

        {error ? (
          <View className="flex-row items-center mt-1.5">
            <Ionicons name="alert-circle-outline" size={14} color="#EF4444" />
            <Text className="text-error text-xs ml-1 flex-1">{error}</Text>
          </View>
        ) : null}
      </View>
    );
  }
);

CustomInput.displayName = 'CustomInput';

export default CustomInput;
