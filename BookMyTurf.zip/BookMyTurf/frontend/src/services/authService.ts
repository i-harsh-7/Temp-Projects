import { api } from './api';
import {
  ApiResponse,
  AuthResponse,
  LoginRequest,
  RegisterRequest,
} from '@/types';

export const authService = {
  login: async (data: LoginRequest): Promise<ApiResponse<AuthResponse>> => {
    const response = await api.post<ApiResponse<AuthResponse>>(
      '/auth/login',
      data
    );
    return response.data;
  },

  register: async (
    data: RegisterRequest
  ): Promise<ApiResponse<AuthResponse>> => {
    const response = await api.post<ApiResponse<AuthResponse>>(
      '/auth/register',
      data
    );
    return response.data;
  },

  logout: async (refreshToken: string): Promise<ApiResponse<null>> => {
    const response = await api.post<ApiResponse<null>>('/auth/logout', {
      refreshToken,
    });
    return response.data;
  },

  refreshToken: async (token: string): Promise<ApiResponse<AuthResponse>> => {
    const response = await api.post<ApiResponse<AuthResponse>>(
      '/auth/refresh',
      { refreshToken: token }
    );
    return response.data;
  },

  getMe: async (): Promise<ApiResponse<AuthResponse['user']>> => {
    const response = await api.get<ApiResponse<AuthResponse['user']>>(
      '/auth/me'
    );
    return response.data;
  },

  forgotPassword: async (email: string): Promise<ApiResponse<null>> => {
    const response = await api.post<ApiResponse<null>>(
      '/auth/forgot-password',
      { email }
    );
    return response.data;
  },

  resetPassword: async (
    token: string,
    newPassword: string
  ): Promise<ApiResponse<null>> => {
    const response = await api.post<ApiResponse<null>>(
      '/auth/reset-password',
      { token, newPassword }
    );
    return response.data;
  },
};
