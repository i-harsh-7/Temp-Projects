import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

interface ErrorScreenProps {
  message?: string;
  onRetry?: () => void;
}

const ErrorScreen: React.FC<ErrorScreenProps> = ({
  message = 'Something went wrong. Please try again.',
  onRetry,
}) => {
  return (
    <View className="flex-1 items-center justify-center bg-dark px-6">
      <View className="w-20 h-20 rounded-full bg-dark-200 items-center justify-center mb-6">
        <Ionicons name="alert-circle-outline" size={44} color="#EF4444" />
      </View>

      <Text className="text-white text-xl font-semibold mb-3 text-center">
        Oops!
      </Text>

      <Text className="text-muted text-base text-center leading-6 mb-8 max-w-xs">
        {message}
      </Text>

      {onRetry ? (
        <TouchableOpacity
          onPress={onRetry}
          className="bg-primary px-8 py-3.5 rounded-xl active:opacity-80"
          activeOpacity={0.8}
        >
          <Text className="text-white font-semibold text-base">Try Again</Text>
        </TouchableOpacity>
      ) : null}
    </View>
  );
};

export default ErrorScreen;
