package com.bookmyturf.repository;

import com.bookmyturf.entity.Venue;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VenueRepository extends MongoRepository<Venue, String> {

    List<Venue> findByOwnerId(String ownerId);

    List<Venue> findByCityIgnoreCase(String city);

    List<Venue> findByApprovedTrueAndActiveTrue();

    List<Venue> findByCityIgnoreCaseAndApprovedTrueAndActiveTrue(String city);

    @Query("{ '$or': [ { 'name': { '$regex': ?0, '$options': 'i' } }, { 'city': { '$regex': ?0, '$options': 'i' } } ], 'approved': true, 'active': true }")
    List<Venue> searchVenues(String query);

    List<Venue> findByApprovedTrueAndActiveTrueAndSportsContaining(String sport);
}
