# Sprint 1 — Verification Checklist

A reviewer can tick through this list to confirm every Sprint 1 feature is implemented. Paths are relative
to the repo root. Backend base URL: `http://localhost:8080/api`.

**Legend:** BE = backend file · FE = frontend screen.

---

## Authentication

- [ ] **Register** — `POST /api/auth/register`
  - BE: `backend/.../controller/AuthController.java` → `backend/.../service/AuthService.java` (`register`)
  - FE: `frontend/app/(auth)/register.tsx`
  - Verify: register a `CUSTOMER`; expect `201` with `accessToken`, `refreshToken`, `user`; user appears in Mongo `users`.

- [ ] **Login** — `POST /api/auth/login`
  - BE: `AuthController.login` → `AuthService.login` (BCrypt verify, active check)
  - FE: `frontend/app/(auth)/login.tsx`
  - Verify: login with the credentials above → `200` + tokens. Wrong password → `401`.

- [ ] **JWT issuance & validation**
  - BE: `backend/.../security/JwtTokenProvider.java` (HMAC-SHA256, 15-min access token), `backend/.../security/JwtAuthenticationFilter.java`, `backend/.../config/SecurityConfig.java`
  - FE: `frontend/src/services/api.ts` (attaches `Authorization: Bearer`), `frontend/src/store/authStore.ts`
  - Verify: call `GET /api/users/me` with the token → `200`; without it → `401`.

- [ ] **Refresh token** — `POST /api/auth/refresh`
  - BE: `AuthController.refresh` → `AuthService.refreshToken`; persisted in `refresh_tokens` (`backend/.../entity/RefreshToken.java`)
  - FE: auto-refresh on `401` in `frontend/src/services/api.ts`
  - Verify: post a valid refresh token → new `accessToken`. Revoked/expired → `401`.

- [ ] **Logout** — `POST /api/auth/logout`
  - BE: `AuthController.logout` → `AuthService.logout` (sets `revoked = true`)
  - FE: profile sign-out (`frontend/app/(tabs)/profile.tsx`, `frontend/src/hooks/useAuth.ts`)
  - Verify: logout, then try to refresh the same token → `401`.

---

## Customer features

- [ ] **Browse venues** — `GET /api/venues/public`
  - BE: `controller/VenueController.getPublicVenues` → `service/VenueService`
  - FE: `frontend/app/(tabs)/home.tsx`
  - Verify: returns paginated approved+active venues.

- [ ] **Search venues** — `GET /api/venues/public/search?query=&city=&sport=`
  - BE: `VenueController.searchVenues`
  - FE: `frontend/app/(tabs)/search.tsx`, `frontend/src/store/searchStore.ts`
  - Verify: filter by `city` / `sport` narrows results.

- [ ] **Filter** (city / sport chips)
  - FE: `frontend/src/components/common/FilterChip.tsx`, `frontend/app/(tabs)/search.tsx`
  - Verify: selecting a chip changes the query params sent.

- [ ] **Venue details** — `GET /api/venues/public/{id}`
  - BE: `VenueController.getVenueById`
  - FE: `frontend/app/venue/[id].tsx`

- [ ] **Turf details** — `GET /api/turfs/public/{id}` and `GET /api/turfs/public/venue/{venueId}`
  - BE: `controller/TurfController.getTurfById`, `getTurfsByVenue`
  - FE: `frontend/app/turf/[id].tsx`

- [ ] **View slots** — `GET /api/turfs/public/{id}/slots?date=YYYY-MM-DD`
  - BE: `TurfController.getAvailableSlots` → `TurfService.getAvailableSlots` (1-hour slots, overlap check)
  - FE: `frontend/app/booking/slot-selection.tsx`, `frontend/src/components/booking/TimeSlotPicker.tsx`
  - Verify: booked slots return `available: false`.

- [ ] **Book a slot** — `POST /api/bookings/`
  - BE: `controller/BookingController.createBooking` → `service/BookingService.createBooking`
  - FE: `frontend/app/booking/slot-selection.tsx` → `frontend/app/booking/checkout.tsx`, `frontend/src/hooks/useBookings.ts`
  - Verify: creates `PENDING` booking and acquires the Redis lock; amount = price × hours.

- [ ] **Pay** — `POST /api/payments/create-order` then `POST /api/payments/verify`
  - BE: `controller/PaymentController` → `service/PaymentService`
  - FE: `frontend/app/booking/checkout.tsx`, `frontend/src/hooks/usePayment.ts`, `frontend/src/services/paymentService.ts`
  - Verify: order created with `keyId`; after a successful (test) payment, verify confirms the booking.

- [ ] **My bookings** — `GET /api/bookings/my`
  - BE: `BookingController.getMyBookings`
  - FE: `frontend/app/(tabs)/bookings.tsx`, `frontend/src/components/booking/BookingCard.tsx`

- [ ] **Cancel booking** — `PUT /api/bookings/{id}/cancel`
  - BE: `BookingController.cancelBooking` → `BookingService.cancelBooking` (releases lock if unpaid)
  - FE: `frontend/app/(tabs)/bookings.tsx`, `frontend/src/components/common/ConfirmDialog.tsx`
  - Verify: status becomes `CANCELLED`; cancelling twice → `400`.

- [ ] **Profile** — `GET/PUT /api/users/me`, `PUT /api/users/me/avatar`
  - BE: `controller/UserController` → `service/UserService`
  - FE: `frontend/app/(tabs)/profile.tsx`, `frontend/src/components/common/ImageUploader.tsx`

---

## Venue Owner features

- [ ] **Create venue** — `POST /api/venues/` (VENUE_OWNER)
  - BE: `VenueController.createVenue` → `VenueService`
  - FE: `frontend/app/(owner)/venues/create.tsx`, `frontend/app/(owner)/add-venue.tsx`

- [ ] **Read / list my venues** — `GET /api/venues/my`
  - BE: `VenueController.getMyVenues`
  - FE: `frontend/app/(owner)/venues/index.tsx`, `frontend/app/(owner)/venues.tsx`, `frontend/src/components/owner/VenueManageCard.tsx`

- [ ] **Update venue** — `PUT /api/venues/{id}` (owner only)
  - BE: `VenueController.updateVenue` (ownership enforced in service)
  - FE: `frontend/app/(owner)/venues/index.tsx`

- [ ] **Delete venue** — `DELETE /api/venues/{id}` (owner only)
  - BE: `VenueController.deleteVenue`
  - FE: `frontend/app/(owner)/venues/index.tsx`

- [ ] **Create turf** — `POST /api/turfs/` (VENUE_OWNER)
  - BE: `TurfController.createTurf` → `TurfService`
  - FE: `frontend/app/(owner)/turfs/create.tsx`, `frontend/app/(owner)/venues/[id]/turfs.tsx`

- [ ] **Read / update / delete turf** — `PUT /api/turfs/{id}`, `DELETE /api/turfs/{id}`
  - BE: `TurfController.updateTurf`, `deleteTurf` (ownership enforced)
  - FE: `frontend/app/(owner)/turfs/[id]/edit.tsx`, `frontend/src/components/owner/TurfManageCard.tsx`

- [ ] **Image upload (venue & turf)** — `POST /api/venues/{id}/images`, `POST /api/turfs/{id}/images`
  - BE: `VenueController.uploadVenueImages` / `TurfController.uploadTurfImages` → `cloudinary/CloudinaryService.uploadImage` (folders `venues/`, `turfs/`)
  - FE: `frontend/src/components/common/ImageUploader.tsx`
  - Verify: multipart `files` part returns the entity with Cloudinary URLs appended.

- [ ] **View venue bookings** — `GET /api/bookings/venue/{venueId}` (owner only)
  - BE: `BookingController.getVenueBookings`
  - FE: `frontend/app/(owner)/bookings.tsx`

- [ ] **Owner dashboard**
  - FE: `frontend/app/(owner)/dashboard.tsx`, `frontend/src/components/owner/StatsCard.tsx`
  - Verify: aggregates the owner's venues/turfs/bookings.

---

## Admin features

- [ ] **View users** — `GET /api/admin/users` (also `GET /api/users/`)
  - BE: `controller/AdminController.getAllUsers`, `UserController.getAllUsers`
  - FE: `frontend/app/(admin)/users.tsx`

- [ ] **Toggle user active** — `PUT /api/users/{id}/toggle`
  - BE: `UserController.toggleUserActive` → `UserService`
  - FE: `frontend/app/(admin)/users.tsx`

- [ ] **View venues** — `GET /api/admin/venues` (also `GET /api/venues/admin`)
  - BE: `AdminController.getAllVenues`, `VenueController.getAllVenuesAdmin`
  - FE: `frontend/app/(admin)/venues.tsx`

- [ ] **Approve venue** — `PUT /api/venues/admin/{id}/approve`
  - BE: `VenueController.approveVenue` → `VenueService.approveVenue`
  - FE: `frontend/app/(admin)/venues.tsx`
  - Verify: venue `approved` flips to `true` and then appears in `/venues/public`.

- [ ] **View bookings** — `GET /api/admin/bookings` (also `GET /api/bookings/admin`)
  - BE: `AdminController.getAllBookings`, `BookingController.getAllBookingsAdmin`
  - FE: `frontend/app/(admin)/bookings.tsx`

- [ ] **Admin dashboard** — `GET /api/admin/dashboard`
  - BE: `AdminController.getDashboard` (totals + revenue from CONFIRMED bookings)
  - FE: `frontend/app/(admin)/dashboard.tsx`

---

## Cross-cutting critical features

- [ ] **Slot booking with Redis locking**
  - BE: `backend/.../redis/RedisLockService.java`, used in `backend/.../service/BookingService.java`
  - How race conditions are prevented: atomic Redis `SET NX` with a 5-minute TTL on key
    `slot_lock:{turfId}:{date}:{start}-{end}`; a concurrent request fails the lock and gets `409`. A DB
    overlap check (`findOverlappingBookings`) runs first for confirmed bookings. Lock is released on
    confirm/cancel, or auto-expires if payment is abandoned.
  - Verify: create a booking for a slot, then immediately create another for the same slot before paying →
    second request returns `409 "Slot temporarily locked"`. Check Redis: `redis-cli KEYS "slot_lock:*"`.

- [ ] **Payment with Razorpay signature verification**
  - BE: `backend/.../service/PaymentService.java` (`verifySignature` = HMAC-SHA256 of
    `razorpayOrderId|razorpayPaymentId` compared to `razorpaySignature`; on match → mark `PAID` and
    `confirmBooking`)
  - FE: `frontend/src/hooks/usePayment.ts`, `frontend/app/booking/checkout.tsx`
  - Verify: tampering with the signature on `POST /api/payments/verify` → `401`; valid signature →
    booking `CONFIRMED`.

- [ ] **Cloudinary image upload**
  - BE: `backend/.../cloudinary/CloudinaryService.java` (`uploadImage` returns `secure_url`), config in
    `backend/.../config/CloudinaryConfig.java`
  - Used by: avatar (`UserService`, folder `avatars/`), venues (`VenueService`, `venues/`), turfs
    (`TurfService`, `turfs/`)
  - Verify: upload an image and confirm a `https://res.cloudinary.com/...` URL is stored on the entity.