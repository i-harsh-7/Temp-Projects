package com.bookmyturf.controller;

import com.bookmyturf.dto.*;
import com.bookmyturf.security.CustomUserDetails;
import com.bookmyturf.service.BookingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
@Slf4j
public class BookingController {

    private final BookingService bookingService;

    @PostMapping("/")
    @PreAuthorize("hasRole('CUSTOMER')")
    public ResponseEntity<ApiResponse<BookingResponse>> createBooking(
            @Valid @RequestBody CreateBookingRequest req,
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        BookingResponse response = bookingService.createBooking(req, userDetails.getId());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Booking created successfully", response));
    }

    @GetMapping("/my")
    public ResponseEntity<ApiResponse<PageResponse<BookingResponse>>> getMyBookings(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            Pageable pageable) {
        PageResponse<BookingResponse> response = bookingService.getMyBookings(userDetails.getId(), pageable);
        return ResponseEntity.ok(ApiResponse.success("Bookings retrieved", response));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<BookingResponse>> getBookingById(
            @PathVariable String id,
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        BookingResponse response = bookingService.getBookingById(id, userDetails.getId());
        return ResponseEntity.ok(ApiResponse.success("Booking retrieved", response));
    }

    @PutMapping("/{id}/cancel")
    public ResponseEntity<ApiResponse<BookingResponse>> cancelBooking(
            @PathVariable String id,
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        BookingResponse response = bookingService.cancelBooking(id, userDetails.getId());
        return ResponseEntity.ok(ApiResponse.success("Booking cancelled successfully", response));
    }

    @GetMapping("/venue/{venueId}")
    @PreAuthorize("hasRole('VENUE_OWNER')")
    public ResponseEntity<ApiResponse<PageResponse<BookingResponse>>> getVenueBookings(
            @PathVariable String venueId,
            @AuthenticationPrincipal CustomUserDetails userDetails,
            Pageable pageable) {
        PageResponse<BookingResponse> response = bookingService.getVenueBookings(venueId, userDetails.getId(), pageable);
        return ResponseEntity.ok(ApiResponse.success("Venue bookings retrieved", response));
    }

    @GetMapping("/admin")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<PageResponse<BookingResponse>>> getAllBookingsAdmin(Pageable pageable) {
        PageResponse<BookingResponse> response = bookingService.getAllBookingsAdmin(pageable);
        return ResponseEntity.ok(ApiResponse.success("All bookings retrieved", response));
    }
}
