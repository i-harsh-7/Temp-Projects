import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  RefreshControl,
  Pressable,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useRouter } from 'expo-router';
import Toast from 'react-native-toast-message';

import { api } from '@/services/api';
import { venueService } from '@/services/venueService';
import { useAuthStore } from '@/store/authStore';
import { QUERY_KEYS } from '@/utils/constants';
import { formatCurrency, getInitials } from '@/utils/helpers';
import { ApiResponse, PageResponse, User, Venue } from '@/types';
import StatsCard from '@/components/owner/StatsCard';
import CustomButton from '@/components/common/CustomButton';

interface DashboardStats {
  totalUsers: number;
  totalVenues: number;
  pendingApprovals: number;
  totalBookings: number;
  totalRevenue: number;
}

interface AdminVenue extends Venue {
  ownerName?: string;
}

const ROLE_COLORS: Record<string, string> = {
  CUSTOMER: '#3B82F6',
  VENUE_OWNER: '#1DB954',
  ADMIN: '#F59E0B',
};

export default function AdminDashboard() {
  const router = useRouter();
  const queryClient = useQueryClient();
  const [refreshing, setRefreshing] = useState(false);

  const { data: stats, isLoading: statsLoading, refetch: refetchStats } = useQuery({
    queryKey: ['admin-dashboard'],
    queryFn: async () => {
      const res = await api.get<ApiResponse<DashboardStats>>('/admin/dashboard');
      return res.data.data;
    },
  });

  const { data: pendingData, refetch: refetchPending } = useQuery({
    queryKey: [QUERY_KEYS.ADMIN_VENUES, 'pending'],
    queryFn: async () => {
      const res = await api.get<ApiResponse<PageResponse<AdminVenue>>>('/admin/venues', {
        params: { approved: false, page: 0, size: 5 },
      });
      return res.data.data;
    },
  });

  const { data: usersData, refetch: refetchUsers } = useQuery({
    queryKey: [QUERY_KEYS.ADMIN_USERS, 'recent'],
    queryFn: async () => {
      const res = await api.get<ApiResponse<PageResponse<User>>>('/admin/users', {
        params: { page: 0, size: 5 },
      });
      return res.data.data;
    },
  });

  const approveMutation = useMutation({
    mutationFn: (id: string) => venueService.approveVenue(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.ADMIN_VENUES] });
      queryClient.invalidateQueries({ queryKey: ['admin-dashboard'] });
      Toast.show({ type: 'success', text1: 'Venue approved!' });
    },
    onError: () => {
      Toast.show({ type: 'error', text1: 'Failed to approve venue' });
    },
  });

  const handleRefresh = async () => {
    setRefreshing(true);
    await Promise.all([refetchStats(), refetchPending(), refetchUsers()]);
    setRefreshing(false);
  };

  const pendingVenues = pendingData?.content ?? [];
  const recentUsers = usersData?.content ?? [];

  return (
    <SafeAreaView className="flex-1 bg-dark">
      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={handleRefresh}
            tintColor="#1DB954"
          />
        }
      >
        {/* Header */}
        <View className="px-4 pt-4 pb-2">
          <Text className="text-white text-2xl font-bold">Admin Dashboard</Text>
          <Text className="text-muted text-sm mt-1">Platform Overview</Text>
        </View>

        {/* Stats Row */}
        {statsLoading ? (
          <View className="px-4 mt-4">
            <View className="bg-card rounded-2xl p-4 h-24 opacity-50" />
          </View>
        ) : (
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: 16, paddingVertical: 12, gap: 12 }}
          >
            <StatsCard
              icon="people-outline"
              label="Total Users"
              value={stats?.totalUsers ?? 0}
              color="#3B82F6"
            />
            <StatsCard
              icon="business-outline"
              label="Total Venues"
              value={stats?.totalVenues ?? 0}
              color="#1DB954"
            />
            <StatsCard
              icon="time-outline"
              label="Pending Approvals"
              value={stats?.pendingApprovals ?? 0}
              color="#F59E0B"
            />
            <StatsCard
              icon="calendar-outline"
              label="Total Bookings"
              value={stats?.totalBookings ?? 0}
              color="#8B5CF6"
            />
            <StatsCard
              icon="cash-outline"
              label="Revenue"
              value={formatCurrency(stats?.totalRevenue ?? 0)}
              color="#EC4899"
            />
          </ScrollView>
        )}

        {/* Pending Approvals Section */}
        <View className="px-4 mt-2">
          <View className="flex-row items-center justify-between mb-3">
            <Text className="text-white text-lg font-bold">Pending Approvals</Text>
            <Pressable onPress={() => router.push('/(admin)/venues')}>
              <Text className="text-primary text-sm">See All</Text>
            </Pressable>
          </View>

          {pendingVenues.length === 0 ? (
            <View className="bg-card rounded-xl p-4">
              <Text className="text-muted text-sm text-center">All venues are approved</Text>
            </View>
          ) : (
            pendingVenues.map((venue) => (
              <View key={venue.id} className="bg-card rounded-xl p-3 mb-2">
                <View className="flex-row items-center justify-between">
                  <View className="flex-1 mr-3">
                    <Text className="text-white font-semibold" numberOfLines={1}>
                      {venue.name}
                    </Text>
                    <Text className="text-muted text-xs mt-0.5">
                      {venue.city}
                      {venue.ownerName ? ` · ${venue.ownerName}` : ''}
                    </Text>
                  </View>
                  <CustomButton
                    title={approveMutation.isPending ? 'Approving...' : 'Approve'}
                    onPress={() => approveMutation.mutate(venue.id)}
                    size="sm"
                    variant="primary"
                    disabled={approveMutation.isPending}
                  />
                </View>
              </View>
            ))
          )}
        </View>

        {/* Recent Users Section */}
        <View className="px-4 mt-4">
          <View className="flex-row items-center justify-between mb-3">
            <Text className="text-white text-lg font-bold">Recent Users</Text>
            <Pressable onPress={() => router.push('/(admin)/users')}>
              <Text className="text-primary text-sm">See All</Text>
            </Pressable>
          </View>

          {recentUsers.length === 0 ? (
            <View className="bg-card rounded-xl p-4">
              <Text className="text-muted text-sm text-center">No users found</Text>
            </View>
          ) : (
            recentUsers.map((user) => (
              <View key={user.id} className="bg-card rounded-xl p-3 mb-2 flex-row items-center">
                {/* Avatar */}
                <View
                  className="w-10 h-10 rounded-full items-center justify-center mr-3"
                  style={{ backgroundColor: ROLE_COLORS[user.role] ?? '#6B7280' }}
                >
                  <Text className="text-white text-sm font-bold">
                    {getInitials(user.name)}
                  </Text>
                </View>

                {/* Info */}
                <View className="flex-1">
                  <Text className="text-white font-semibold text-sm" numberOfLines={1}>
                    {user.name}
                  </Text>
                  <Text className="text-muted text-xs" numberOfLines={1}>
                    {user.email}
                  </Text>
                </View>

                {/* Role Badge */}
                <View
                  className="px-2 py-0.5 rounded-full"
                  style={{ backgroundColor: (ROLE_COLORS[user.role] ?? '#6B7280') + '33' }}
                >
                  <Text
                    className="text-xs font-medium"
                    style={{ color: ROLE_COLORS[user.role] ?? '#6B7280' }}
                  >
                    {user.role === 'VENUE_OWNER' ? 'Owner' : user.role.charAt(0) + user.role.slice(1).toLowerCase()}
                  </Text>
                </View>
              </View>
            ))
          )}
        </View>

        {/* Quick Links */}
        <View className="px-4 mt-4 mb-8">
          <Text className="text-white text-lg font-bold mb-3">Quick Links</Text>
          <View className="flex-row gap-3">
            <View className="flex-1">
              <CustomButton
                title="Manage Users"
                onPress={() => router.push('/(admin)/users')}
                variant="outline"
                size="sm"
                fullWidth
              />
            </View>
            <View className="flex-1">
              <CustomButton
                title="Manage Venues"
                onPress={() => router.push('/(admin)/venues')}
                variant="outline"
                size="sm"
                fullWidth
              />
            </View>
            <View className="flex-1">
              <CustomButton
                title="All Bookings"
                onPress={() => router.push('/(admin)/bookings')}
                variant="outline"
                size="sm"
                fullWidth
              />
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
