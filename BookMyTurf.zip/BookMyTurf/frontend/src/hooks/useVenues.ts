import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { venueService } from '@/services/venueService';
import { CreateVenueRequest, VenueSearchParams } from '@/types';
import { QUERY_KEYS } from '@/utils/constants';

export const useVenues = (params?: VenueSearchParams) => {
  return useQuery({
    queryKey: [QUERY_KEYS.VENUES, params],
    queryFn: () => venueService.getVenues(params),
    staleTime: 5 * 60 * 1000,
    select: (data) => data.data,
  });
};

export const useVenueById = (id: string) => {
  return useQuery({
    queryKey: [QUERY_KEYS.VENUE, id],
    queryFn: () => venueService.getVenueById(id),
    enabled: !!id,
    staleTime: 5 * 60 * 1000,
    select: (data) => data.data,
  });
};

export const useMyVenues = () => {
  return useQuery({
    queryKey: [QUERY_KEYS.MY_VENUES],
    queryFn: () => venueService.getMyVenues(),
    staleTime: 2 * 60 * 1000,
    select: (data) => data.data,
  });
};

export const useSearchVenues = (query: string, params?: VenueSearchParams) => {
  return useQuery({
    queryKey: [QUERY_KEYS.VENUES, 'search', query, params],
    queryFn: () => venueService.searchVenues(query, params),
    enabled: query.length >= 2,
    staleTime: 2 * 60 * 1000,
    select: (data) => data.data,
  });
};

export const useCreateVenue = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: CreateVenueRequest) => venueService.createVenue(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.VENUES] });
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.MY_VENUES] });
    },
  });
};

export const useUpdateVenue = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      data,
    }: {
      id: string;
      data: Partial<CreateVenueRequest>;
    }) => venueService.updateVenue(id, data),
    onSuccess: (_, { id }) => {
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.VENUE, id] });
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.VENUES] });
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.MY_VENUES] });
    },
  });
};

export const useDeleteVenue = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => venueService.deleteVenue(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.VENUES] });
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.MY_VENUES] });
    },
  });
};

export const useUploadVenueImages = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, files }: { id: string; files: FormData }) =>
      venueService.uploadVenueImages(id, files),
    onSuccess: (_, { id }) => {
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.VENUE, id] });
    },
  });
};
