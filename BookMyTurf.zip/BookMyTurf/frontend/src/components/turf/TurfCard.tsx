import React from 'react';
import { View, Text, Pressable } from 'react-native';
import { Image } from 'expo-image';
import { Ionicons } from '@expo/vector-icons';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';
import { Turf } from '@/types';
import { formatCurrency, formatTime } from '@/utils/helpers';
import { SPORT_COLORS } from '@/utils/constants';

interface TurfCardProps {
  turf: Turf;
  onPress: () => void;
}

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

const PLACEHOLDER_IMAGE =
  'https://placehold.co/400x180/1A1A1A/1DB954?text=Turf';

const TurfCard: React.FC<TurfCardProps> = ({ turf, onPress }) => {
  const scale = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const handlePressIn = () => {
    scale.value = withSpring(0.97, { damping: 15, stiffness: 300 });
  };

  const handlePressOut = () => {
    scale.value = withSpring(1, { damping: 15, stiffness: 300 });
  };

  const sportColor = SPORT_COLORS[turf.sport] ?? '#1DB954';
  const coverImage =
    turf.images.length > 0 ? turf.images[0] : PLACEHOLDER_IMAGE;

  return (
    <AnimatedPressable
      onPress={onPress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      style={animatedStyle}
      className="bg-card rounded-2xl overflow-hidden mb-3"
    >
      {/* Image */}
      <Image
        source={{ uri: coverImage }}
        style={{ width: '100%', height: 140 }}
        contentFit="cover"
        placeholder={PLACEHOLDER_IMAGE}
        transition={300}
      />

      {/* Content */}
      <View className="p-3">
        <View className="flex-row items-center justify-between">
          <Text className="text-white text-base font-bold flex-1 mr-2" numberOfLines={1}>
            {turf.name}
          </Text>

          {/* Active badge */}
          <View
            className={`rounded-full px-2.5 py-0.5 ${
              turf.active ? 'bg-success/20' : 'bg-dark-300'
            }`}
          >
            <Text
              className={`text-xs font-medium ${
                turf.active ? 'text-success' : 'text-muted'
              }`}
            >
              {turf.active ? 'Active' : 'Inactive'}
            </Text>
          </View>
        </View>

        {/* Sport badge */}
        <View
          className="self-start rounded-full px-3 py-1 mt-2"
          style={{
            backgroundColor: `${sportColor}20`,
            borderWidth: 1,
            borderColor: `${sportColor}60`,
          }}
        >
          <Text className="text-xs font-semibold" style={{ color: sportColor }}>
            {turf.sport}
          </Text>
        </View>

        {/* Price and Time */}
        <View className="flex-row items-center justify-between mt-3">
          <View className="flex-row items-center">
            <Ionicons name="pricetag-outline" size={14} color="#1DB954" />
            <Text className="text-primary font-bold text-sm ml-1">
              {formatCurrency(turf.pricePerHour)}/hr
            </Text>
          </View>

          <View className="flex-row items-center">
            <Ionicons name="time-outline" size={14} color="#6B7280" />
            <Text className="text-muted text-xs ml-1">
              {formatTime(turf.openingTime)} - {formatTime(turf.closingTime)}
            </Text>
          </View>
        </View>

        {/* Amenities preview */}
        {turf.amenities.length > 0 && (
          <View className="flex-row items-center mt-2">
            <Ionicons name="checkmark-circle-outline" size={13} color="#6B7280" />
            <Text className="text-muted text-xs ml-1">
              {turf.amenities.slice(0, 3).join(' · ')}
              {turf.amenities.length > 3 ? ` +${turf.amenities.length - 3}` : ''}
            </Text>
          </View>
        )}
      </View>
    </AnimatedPressable>
  );
};

export default TurfCard;
