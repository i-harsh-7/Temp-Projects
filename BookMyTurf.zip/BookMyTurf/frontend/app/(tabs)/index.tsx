import React from 'react';
import { View, Text, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuthStore } from '@/store/authStore';

export default function HomeScreen() {
  const user = useAuthStore((state) => state.user);

  return (
    <SafeAreaView className="flex-1 bg-dark">
      <ScrollView className="flex-1 px-4">
        <View className="pt-6 pb-4">
          <Text className="text-muted text-sm">Welcome back,</Text>
          <Text className="text-white text-2xl font-bold mt-1">
            {user?.name ?? 'Player'}
          </Text>
        </View>

        <View className="bg-card rounded-2xl p-4 mb-4">
          <Text className="text-white text-lg font-semibold mb-2">
            Find a Turf
          </Text>
          <Text className="text-muted text-sm">
            Browse and book sports turfs near you.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
