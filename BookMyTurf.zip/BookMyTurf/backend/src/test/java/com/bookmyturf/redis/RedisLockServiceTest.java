package com.bookmyturf.redis;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("RedisLockService unit tests")
class RedisLockServiceTest {

    @Mock
    private RedisTemplate<String, String> redisTemplate;
    @Mock
    private ValueOperations<String, String> valueOperations;

    @InjectMocks
    private RedisLockService redisLockService;

    private static final String TURF_ID = "turf-1";
    private final LocalDate date = LocalDate.of(2026, 7, 1);
    private final LocalTime start = LocalTime.of(10, 0);
    private final LocalTime end = LocalTime.of(11, 0);

    private static final String EXPECTED_KEY = "slot_lock:turf-1:2026-07-01:10:00-11:00";

    @BeforeEach
    void setUp() {
        // Only stub opsForValue where needed (lenient lookups are configured per-test).
    }

    @Test
    @DisplayName("acquireSlotLock: returns true when the key is absent (setIfAbsent succeeds)")
    void acquireSlotLock_whenKeyAbsent_returnsTrue() {
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        when(valueOperations.setIfAbsent(eq(EXPECTED_KEY), eq("locked"), any(Duration.class)))
                .thenReturn(true);

        boolean acquired = redisLockService.acquireSlotLock(TURF_ID, date, start, end);

        assertThat(acquired).isTrue();
        verify(valueOperations).setIfAbsent(eq(EXPECTED_KEY), eq("locked"), any(Duration.class));
    }

    @Test
    @DisplayName("acquireSlotLock: returns false when the key is present (setIfAbsent fails)")
    void acquireSlotLock_whenKeyPresent_returnsFalse() {
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        when(valueOperations.setIfAbsent(eq(EXPECTED_KEY), eq("locked"), any(Duration.class)))
                .thenReturn(false);

        boolean acquired = redisLockService.acquireSlotLock(TURF_ID, date, start, end);

        assertThat(acquired).isFalse();
    }

    @Test
    @DisplayName("releaseSlotLock: deletes the correctly formatted key")
    void releaseSlotLock_deletesKey() {
        when(redisTemplate.delete(EXPECTED_KEY)).thenReturn(true);

        redisLockService.releaseSlotLock(TURF_ID, date, start, end);

        verify(redisTemplate).delete(EXPECTED_KEY);
    }

    @Test
    @DisplayName("isSlotLocked: returns true when the key exists")
    void isSlotLocked_returnsTrueWhenKeyExists() {
        when(redisTemplate.hasKey(EXPECTED_KEY)).thenReturn(true);

        boolean locked = redisLockService.isSlotLocked(TURF_ID, date, start, end);

        assertThat(locked).isTrue();
        verify(redisTemplate).hasKey(EXPECTED_KEY);
    }

    @Test
    @DisplayName("isSlotLocked: returns false when the key does not exist")
    void isSlotLocked_returnsFalseWhenKeyAbsent() {
        when(redisTemplate.hasKey(EXPECTED_KEY)).thenReturn(false);

        assertThat(redisLockService.isSlotLocked(TURF_ID, date, start, end)).isFalse();
    }

    @Test
    @DisplayName("key format is slot_lock:{turfId}:{date}:{startTime}-{endTime}")
    void keyFormat_isCorrect() {
        // Verified indirectly: the service must hit this exact key for delete().
        when(redisTemplate.delete(EXPECTED_KEY)).thenReturn(true);

        redisLockService.releaseSlotLock(TURF_ID, date, start, end);

        verify(redisTemplate).delete("slot_lock:turf-1:2026-07-01:10:00-11:00");
    }
}