package com.bookmyturf.service;

import com.bookmyturf.dto.AuthResponse;
import com.bookmyturf.dto.LoginRequest;
import com.bookmyturf.dto.RegisterRequest;
import com.bookmyturf.dto.UserResponse;
import com.bookmyturf.entity.RefreshToken;
import com.bookmyturf.entity.User;
import com.bookmyturf.exception.ConflictException;
import com.bookmyturf.exception.UnauthorizedException;
import com.bookmyturf.mapper.UserMapper;
import com.bookmyturf.repository.RefreshTokenRepository;
import com.bookmyturf.repository.UserRepository;
import com.bookmyturf.security.JwtTokenProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("AuthService unit tests")
class AuthServiceTest {

    @Mock
    private UserRepository userRepository;
    @Mock
    private RefreshTokenRepository refreshTokenRepository;
    @Mock
    private PasswordEncoder passwordEncoder;
    @Mock
    private JwtTokenProvider jwtTokenProvider;
    @Mock
    private UserMapper userMapper;

    @InjectMocks
    private AuthService authService;

    private RegisterRequest registerRequest;
    private LoginRequest loginRequest;
    private User user;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(authService, "refreshExpiry", 604_800_000L);

        registerRequest = RegisterRequest.builder()
                .name("Alice")
                .email("alice@example.com")
                .password("password123")
                .phone("9876543210")
                .role(User.Role.CUSTOMER)
                .build();

        loginRequest = LoginRequest.builder()
                .email("alice@example.com")
                .password("password123")
                .build();

        user = User.builder()
                .id("user-1")
                .name("Alice")
                .email("alice@example.com")
                .password("encoded-pw")
                .phone("9876543210")
                .role(User.Role.CUSTOMER)
                .active(true)
                .build();
    }

    private void stubTokenGeneration() {
        when(jwtTokenProvider.generateAccessToken(any(UserDetails.class))).thenReturn("access-token");
        when(jwtTokenProvider.generateRefreshToken()).thenReturn("refresh-token");
        when(userMapper.toResponse(any(User.class)))
                .thenReturn(UserResponse.builder().id("user-1").email("alice@example.com").build());
    }

    @Test
    @DisplayName("register: succeeds when email is not taken and returns tokens")
    void register_success() {
        when(userRepository.existsByEmail("alice@example.com")).thenReturn(false);
        when(userMapper.toUser(registerRequest)).thenReturn(
                User.builder().name("Alice").email("alice@example.com").password("password123").build());
        when(passwordEncoder.encode("password123")).thenReturn("encoded-pw");
        when(userRepository.save(any(User.class))).thenReturn(user);
        stubTokenGeneration();

        AuthResponse response = authService.register(registerRequest);

        assertThat(response).isNotNull();
        assertThat(response.getAccessToken()).isEqualTo("access-token");
        assertThat(response.getRefreshToken()).isEqualTo("refresh-token");
        assertThat(response.getUser()).isNotNull();
        assertThat(response.getUser().getEmail()).isEqualTo("alice@example.com");

        // password must be encoded before save
        ArgumentCaptor<User> userCaptor = ArgumentCaptor.forClass(User.class);
        verify(userRepository).save(userCaptor.capture());
        assertThat(userCaptor.getValue().getPassword()).isEqualTo("encoded-pw");
        verify(passwordEncoder).encode("password123");

        // refresh token must be persisted
        ArgumentCaptor<RefreshToken> tokenCaptor = ArgumentCaptor.forClass(RefreshToken.class);
        verify(refreshTokenRepository).save(tokenCaptor.capture());
        assertThat(tokenCaptor.getValue().getToken()).isEqualTo("refresh-token");
        assertThat(tokenCaptor.getValue().getUserId()).isEqualTo("user-1");
        assertThat(tokenCaptor.getValue().isRevoked()).isFalse();
        verify(refreshTokenRepository).deleteByUserId("user-1");
    }

    @Test
    @DisplayName("register: throws ConflictException when email already exists")
    void register_emailExists_throwsConflict() {
        when(userRepository.existsByEmail("alice@example.com")).thenReturn(true);

        assertThatThrownBy(() -> authService.register(registerRequest))
                .isInstanceOf(ConflictException.class)
                .hasMessageContaining("alice@example.com");

        verify(userRepository, never()).save(any());
        verify(refreshTokenRepository, never()).save(any());
    }

    @Test
    @DisplayName("login: succeeds with valid credentials and returns tokens")
    void login_success() {
        when(userRepository.findByEmail("alice@example.com")).thenReturn(Optional.of(user));
        when(passwordEncoder.matches("password123", "encoded-pw")).thenReturn(true);
        stubTokenGeneration();

        AuthResponse response = authService.login(loginRequest);

        assertThat(response).isNotNull();
        assertThat(response.getAccessToken()).isEqualTo("access-token");
        assertThat(response.getRefreshToken()).isEqualTo("refresh-token");
        verify(refreshTokenRepository).save(any(RefreshToken.class));
    }

    @Test
    @DisplayName("login: throws UnauthorizedException on wrong password")
    void login_wrongPassword_throwsUnauthorized() {
        when(userRepository.findByEmail("alice@example.com")).thenReturn(Optional.of(user));
        when(passwordEncoder.matches("password123", "encoded-pw")).thenReturn(false);

        assertThatThrownBy(() -> authService.login(loginRequest))
                .isInstanceOf(UnauthorizedException.class)
                .hasMessageContaining("Invalid email or password");

        verify(refreshTokenRepository, never()).save(any());
    }

    @Test
    @DisplayName("login: throws UnauthorizedException when user not found")
    void login_userNotFound_throwsException() {
        when(userRepository.findByEmail("alice@example.com")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> authService.login(loginRequest))
                .isInstanceOf(UnauthorizedException.class)
                .hasMessageContaining("Invalid email or password");
    }

    @Test
    @DisplayName("refreshToken: valid token returns a new access token")
    void refreshToken_valid_returnsNewAccessToken() {
        RefreshToken refreshToken = RefreshToken.builder()
                .token("refresh-token")
                .userId("user-1")
                .expiryDate(Instant.now().plusSeconds(3600))
                .revoked(false)
                .build();
        when(refreshTokenRepository.findByToken("refresh-token")).thenReturn(Optional.of(refreshToken));
        when(userRepository.findById("user-1")).thenReturn(Optional.of(user));
        when(jwtTokenProvider.generateAccessToken(any(UserDetails.class))).thenReturn("new-access-token");
        when(userMapper.toResponse(user))
                .thenReturn(UserResponse.builder().id("user-1").email("alice@example.com").build());

        AuthResponse response = authService.refreshToken("refresh-token");

        assertThat(response.getAccessToken()).isEqualTo("new-access-token");
        assertThat(response.getRefreshToken()).isEqualTo("refresh-token");
        assertThat(response.getUser().getId()).isEqualTo("user-1");
    }

    @Test
    @DisplayName("refreshToken: throws when token expired")
    void refreshToken_expired_throwsException() {
        RefreshToken refreshToken = RefreshToken.builder()
                .token("refresh-token")
                .userId("user-1")
                .expiryDate(Instant.now().minusSeconds(3600))
                .revoked(false)
                .build();
        when(refreshTokenRepository.findByToken("refresh-token")).thenReturn(Optional.of(refreshToken));

        assertThatThrownBy(() -> authService.refreshToken("refresh-token"))
                .isInstanceOf(UnauthorizedException.class)
                .hasMessageContaining("expired");

        verify(jwtTokenProvider, never()).generateAccessToken(any());
    }

    @Test
    @DisplayName("refreshToken: throws when token revoked")
    void refreshToken_revoked_throwsException() {
        RefreshToken refreshToken = RefreshToken.builder()
                .token("refresh-token")
                .userId("user-1")
                .expiryDate(Instant.now().plusSeconds(3600))
                .revoked(true)
                .build();
        when(refreshTokenRepository.findByToken("refresh-token")).thenReturn(Optional.of(refreshToken));

        assertThatThrownBy(() -> authService.refreshToken("refresh-token"))
                .isInstanceOf(UnauthorizedException.class)
                .hasMessageContaining("revoked");

        verify(jwtTokenProvider, never()).generateAccessToken(any());
    }

    @Test
    @DisplayName("logout: revokes the refresh token")
    void logout_revokesToken() {
        RefreshToken refreshToken = RefreshToken.builder()
                .token("refresh-token")
                .userId("user-1")
                .expiryDate(Instant.now().plusSeconds(3600))
                .revoked(false)
                .build();
        when(refreshTokenRepository.findByToken("refresh-token")).thenReturn(Optional.of(refreshToken));

        authService.logout("refresh-token");

        ArgumentCaptor<RefreshToken> captor = ArgumentCaptor.forClass(RefreshToken.class);
        verify(refreshTokenRepository).save(captor.capture());
        assertThat(captor.getValue().isRevoked()).isTrue();
    }

    @Test
    @DisplayName("logout: does nothing when token is unknown")
    void logout_unknownToken_doesNothing() {
        when(refreshTokenRepository.findByToken("unknown")).thenReturn(Optional.empty());

        authService.logout("unknown");

        verify(refreshTokenRepository, never()).save(any());
    }
}
