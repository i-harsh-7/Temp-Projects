import React, { useEffect } from 'react';
import { View } from 'react-native';
import { router } from 'expo-router';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  withTiming,
  withSequence,
  withDelay,
  Easing,
  runOnJS,
} from 'react-native-reanimated';
import { useAuthStore } from '@/store/authStore';

export default function Index() {
  const { isAuthenticated, user } = useAuthStore();

  const logoScale = useSharedValue(0.4);
  const logoOpacity = useSharedValue(0);
  const taglineOpacity = useSharedValue(0);

  const logoStyle = useAnimatedStyle(() => ({
    transform: [{ scale: logoScale.value }],
    opacity: logoOpacity.value,
  }));

  const taglineStyle = useAnimatedStyle(() => ({
    opacity: taglineOpacity.value,
  }));

  function navigate() {
    if (!isAuthenticated) {
      router.replace('/(auth)/login');
    } else if (user?.role === 'VENUE_OWNER') {
      router.replace('/(owner)/dashboard');
    } else if (user?.role === 'ADMIN') {
      router.replace('/(admin)/dashboard');
    } else {
      router.replace('/(tabs)/home');
    }
  }

  useEffect(() => {
    logoOpacity.value = withTiming(1, { duration: 500 });
    logoScale.value = withSpring(1, { damping: 12, stiffness: 180 });
    taglineOpacity.value = withDelay(400, withTiming(1, { duration: 500 }));

    // After animation, redirect
    const timer = setTimeout(() => {
      navigate();
    }, 1800);

    return () => clearTimeout(timer);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <View className="flex-1 bg-dark items-center justify-center">
      <Animated.View style={logoStyle} className="items-center">
        {/* Logo mark */}
        <View className="w-24 h-24 rounded-3xl bg-primary items-center justify-center mb-6 shadow-2xl">
          <Animated.Text style={{ fontSize: 48 }}>⚽</Animated.Text>
        </View>

        <Animated.Text className="text-white text-4xl font-bold tracking-tight">
          BookMy<Animated.Text className="text-primary">Turf</Animated.Text>
        </Animated.Text>
      </Animated.View>

      <Animated.Text
        style={taglineStyle}
        className="text-muted text-base mt-3 tracking-wide"
      >
        Find. Book. Play.
      </Animated.Text>

      {/* Loading dots */}
      <Animated.View
        style={taglineStyle}
        className="flex-row items-center gap-2 mt-12"
      >
        {[0, 1, 2].map((i) => (
          <View
            key={i}
            className="w-2 h-2 rounded-full bg-primary"
            style={{ opacity: 0.4 + i * 0.2 }}
          />
        ))}
      </Animated.View>
    </View>
  );
}
