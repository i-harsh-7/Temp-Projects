package com.bookmyturf.dto;

import lombok.*;

import java.math.BigDecimal;
import java.time.LocalTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TimeSlot {

    private LocalTime startTime;

    private LocalTime endTime;

    private boolean available;

    private BigDecimal price;
}
