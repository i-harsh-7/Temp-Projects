package com.bookmyturf.mapper;

import com.bookmyturf.dto.BookingResponse;
import com.bookmyturf.entity.Booking;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface BookingMapper {

    @Mapping(target = "venueName", ignore = true)
    @Mapping(target = "turfName", ignore = true)
    @Mapping(target = "userName", ignore = true)
    BookingResponse toResponse(Booking booking);
}
