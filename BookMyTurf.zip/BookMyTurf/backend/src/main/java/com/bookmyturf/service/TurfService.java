package com.bookmyturf.service;

import com.bookmyturf.cloudinary.CloudinaryService;
import com.bookmyturf.dto.*;
import com.bookmyturf.entity.Booking;
import com.bookmyturf.entity.Turf;
import com.bookmyturf.entity.Venue;
import com.bookmyturf.exception.BadRequestException;
import com.bookmyturf.exception.ResourceNotFoundException;
import com.bookmyturf.exception.UnauthorizedException;
import com.bookmyturf.mapper.TurfMapper;
import com.bookmyturf.redis.RedisLockService;
import com.bookmyturf.repository.BookingRepository;
import com.bookmyturf.repository.TurfRepository;
import com.bookmyturf.repository.VenueRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class TurfService {

    private final TurfRepository turfRepository;
    private final VenueRepository venueRepository;
    private final BookingRepository bookingRepository;
    private final TurfMapper turfMapper;
    private final CloudinaryService cloudinaryService;
    private final RedisLockService redisLockService;

    public TurfResponse createTurf(CreateTurfRequest req, String ownerId) {
        log.info("Creating turf for venue: {} by owner: {}", req.getVenueId(), ownerId);
        Venue venue = venueRepository.findById(req.getVenueId())
                .orElseThrow(() -> new ResourceNotFoundException("Venue", "id", req.getVenueId()));

        if (!venue.getOwnerId().equals(ownerId)) {
            throw new UnauthorizedException("You do not have permission to add turfs to this venue");
        }

        if (req.getOpeningTime().isAfter(req.getClosingTime()) || req.getOpeningTime().equals(req.getClosingTime())) {
            throw new BadRequestException("Opening time must be before closing time");
        }

        Turf turf = turfMapper.toTurf(req);
        turf.setActive(true);
        turf.setImages(new ArrayList<>());
        turf = turfRepository.save(turf);
        log.info("Turf created with id: {}", turf.getId());
        return turfMapper.toResponse(turf);
    }

    public TurfResponse updateTurf(String turfId, UpdateTurfRequest req, String ownerId) {
        log.info("Updating turf: {} by owner: {}", turfId, ownerId);
        Turf turf = getTurfEntityById(turfId);
        verifyTurfOwnership(turf, ownerId);

        turfMapper.updateTurf(req, turf);
        turf = turfRepository.save(turf);
        log.info("Turf updated: {}", turfId);
        return turfMapper.toResponse(turf);
    }

    public void deleteTurf(String turfId, String ownerId) {
        log.info("Soft deleting turf: {} by owner: {}", turfId, ownerId);
        Turf turf = getTurfEntityById(turfId);
        verifyTurfOwnership(turf, ownerId);
        turf.setActive(false);
        turfRepository.save(turf);
        log.info("Turf soft deleted: {}", turfId);
    }

    public TurfResponse getTurfById(String id) {
        log.debug("Fetching turf by id: {}", id);
        return turfMapper.toResponse(getTurfEntityById(id));
    }

    public List<TurfResponse> getTurfsByVenue(String venueId) {
        log.debug("Fetching turfs for venue: {}", venueId);
        return turfRepository.findByVenueIdAndActiveTrue(venueId).stream()
                .map(turfMapper::toResponse)
                .toList();
    }

    public TurfResponse uploadTurfImages(String turfId, List<MultipartFile> files, String ownerId) {
        log.info("Uploading {} images for turf: {}", files.size(), turfId);
        Turf turf = getTurfEntityById(turfId);
        verifyTurfOwnership(turf, ownerId);

        List<String> images = turf.getImages() != null ? new ArrayList<>(turf.getImages()) : new ArrayList<>();
        for (MultipartFile file : files) {
            String url = cloudinaryService.uploadImage(file, "turfs");
            images.add(url);
        }
        turf.setImages(images);
        turf = turfRepository.save(turf);
        log.info("Turf images updated: {}", turfId);
        return turfMapper.toResponse(turf);
    }

    public SlotAvailabilityResponse getAvailableSlots(String turfId, LocalDate date) {
        log.debug("Getting available slots for turf: {} on date: {}", turfId, date);
        Turf turf = getTurfEntityById(turfId);

        List<TimeSlot> slots = new ArrayList<>();
        LocalTime current = turf.getOpeningTime();
        LocalTime closing = turf.getClosingTime();

        while (current.plusHours(1).compareTo(closing) <= 0) {
            LocalTime slotStart = current;
            LocalTime slotEnd = current.plusHours(1);

            List<Booking> overlapping = bookingRepository.findOverlappingBookings(
                    turfId, date, slotStart, slotEnd);
            boolean bookedInDb = overlapping.stream()
                    .anyMatch(b -> b.getBookingStatus() != Booking.BookingStatus.CANCELLED);

            boolean locked = redisLockService.isSlotLocked(turfId, date, slotStart, slotEnd);

            boolean available = !bookedInDb && !locked;

            slots.add(TimeSlot.builder()
                    .startTime(slotStart)
                    .endTime(slotEnd)
                    .available(available)
                    .price(turf.getPricePerHour())
                    .build());

            current = slotEnd;
        }

        return SlotAvailabilityResponse.builder()
                .turfId(turfId)
                .date(date)
                .availableSlots(slots)
                .build();
    }

    private Turf getTurfEntityById(String id) {
        return turfRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Turf", "id", id));
    }

    private void verifyTurfOwnership(Turf turf, String ownerId) {
        Venue venue = venueRepository.findById(turf.getVenueId())
                .orElseThrow(() -> new ResourceNotFoundException("Venue", "id", turf.getVenueId()));
        if (!venue.getOwnerId().equals(ownerId)) {
            throw new UnauthorizedException("You do not have permission to modify this turf");
        }
    }
}
