import React, { useRef, useState } from 'react';
import {
  View,
  Text,
  Dimensions,
  TouchableOpacity,
  FlatList,
  NativeSyntheticEvent,
  NativeScrollEvent,
} from 'react-native';
import { router } from 'expo-router';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  interpolate,
  withSpring,
} from 'react-native-reanimated';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { SPORT_COLORS, SPORTS } from '@/utils/constants';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

const ONBOARDING_KEY = 'onboarding_seen';

interface OnboardingSlide {
  id: string;
  title: string;
  subtitle: string;
  emoji: string;
  color: string;
}

const SLIDES: OnboardingSlide[] = [
  {
    id: '1',
    title: 'Find & Book\nSports Turfs',
    subtitle:
      'Discover top-rated sports venues near you. Book a turf for your favorite sport in just a few taps.',
    emoji: '🏟️',
    color: '#1DB954',
  },
  {
    id: '2',
    title: 'Choose\nYour Sport',
    subtitle:
      'Football, Cricket, Basketball, Badminton and more — find the perfect turf for every sport you love.',
    emoji: '⚽',
    color: '#FF6B35',
  },
  {
    id: '3',
    title: 'Book in\nMinutes',
    subtitle:
      'Select your date and time slot, pay securely, and get instant confirmation. It\'s that simple.',
    emoji: '⚡',
    color: '#3B82F6',
  },
];

const SPORT_ICONS: Record<string, string> = {
  Football: '⚽',
  Cricket: '🏏',
  Basketball: '🏀',
  Badminton: '🏸',
  Tennis: '🎾',
  Volleyball: '🏐',
  Hockey: '🏑',
};

async function markOnboardingSeen() {
  try {
    await AsyncStorage.setItem(ONBOARDING_KEY, 'true');
  } catch {}
}

function handleGetStarted() {
  markOnboardingSeen();
  router.replace('/(auth)/login');
}

export default function Onboarding() {
  const [activeIndex, setActiveIndex] = useState(0);
  const flatListRef = useRef<FlatList<OnboardingSlide>>(null);
  const scrollX = useSharedValue(0);

  const handleScroll = (e: NativeSyntheticEvent<NativeScrollEvent>) => {
    scrollX.value = e.nativeEvent.contentOffset.x;
    const idx = Math.round(e.nativeEvent.contentOffset.x / SCREEN_WIDTH);
    setActiveIndex(idx);
  };

  const goNext = () => {
    if (activeIndex < SLIDES.length - 1) {
      flatListRef.current?.scrollToIndex({ index: activeIndex + 1, animated: true });
    } else {
      handleGetStarted();
    }
  };

  const isLast = activeIndex === SLIDES.length - 1;
  const currentColor = SLIDES[activeIndex]?.color ?? '#1DB954';

  return (
    <SafeAreaView className="flex-1 bg-dark" edges={['top', 'bottom']}>
      {/* Skip */}
      <View className="flex-row justify-end px-6 pt-2 pb-4">
        <TouchableOpacity onPress={handleGetStarted} activeOpacity={0.7}>
          <Text className="text-muted text-base font-medium">Skip</Text>
        </TouchableOpacity>
      </View>

      {/* Slides */}
      <FlatList
        ref={flatListRef}
        data={SLIDES}
        keyExtractor={(item) => item.id}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScroll={handleScroll}
        scrollEventThrottle={16}
        renderItem={({ item, index }) => (
          <View style={{ width: SCREEN_WIDTH }} className="px-8 items-center">
            {/* Illustration area */}
            <View
              className="w-56 h-56 rounded-full items-center justify-center mb-10"
              style={{ backgroundColor: `${item.color}15` }}
            >
              <View
                className="w-44 h-44 rounded-full items-center justify-center"
                style={{ backgroundColor: `${item.color}25` }}
              >
                {index === 1 ? (
                  // Sport icons grid for slide 2
                  <View className="flex-row flex-wrap justify-center" style={{ width: 140 }}>
                    {SPORTS.slice(0, 6).map((sport) => (
                      <View
                        key={sport}
                        className="m-1.5 w-14 h-14 rounded-2xl items-center justify-center"
                        style={{ backgroundColor: `${SPORT_COLORS[sport] ?? '#1DB954'}20` }}
                      >
                        <Text style={{ fontSize: 26 }}>{SPORT_ICONS[sport] ?? '🏅'}</Text>
                      </View>
                    ))}
                  </View>
                ) : (
                  <Text style={{ fontSize: 80 }}>{item.emoji}</Text>
                )}
              </View>
            </View>

            {/* Text */}
            <Text
              className="text-white text-4xl font-bold text-center mb-4 leading-tight"
            >
              {item.title}
            </Text>
            <Text className="text-muted text-base text-center leading-7 max-w-xs">
              {item.subtitle}
            </Text>
          </View>
        )}
      />

      {/* Bottom: dots + button */}
      <View className="px-8 pb-8 pt-6">
        {/* Dots */}
        <View className="flex-row items-center justify-center mb-8 gap-2">
          {SLIDES.map((_, i) => (
            <View
              key={i}
              style={{
                width: i === activeIndex ? 24 : 8,
                height: 8,
                borderRadius: 4,
                backgroundColor: i === activeIndex ? currentColor : '#303030',
              }}
            />
          ))}
        </View>

        {/* Button */}
        <TouchableOpacity
          onPress={goNext}
          activeOpacity={0.85}
          className="w-full py-4 rounded-2xl items-center flex-row justify-center"
          style={{ backgroundColor: currentColor }}
        >
          <Text className="text-white text-base font-bold mr-2">
            {isLast ? 'Get Started' : 'Continue'}
          </Text>
          <Ionicons
            name={isLast ? 'rocket-outline' : 'arrow-forward'}
            size={20}
            color="#fff"
          />
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}
