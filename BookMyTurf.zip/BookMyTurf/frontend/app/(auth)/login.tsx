import React from 'react';
import { View, Text, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Link } from 'expo-router';
import Toast from 'react-native-toast-message';
import CustomInput from '@/components/common/CustomInput';
import CustomButton from '@/components/common/CustomButton';
import { useAuth } from '@/hooks/useAuth';
import { loginSchema, LoginFormData } from '@/utils/validation';
import { Ionicons } from '@expo/vector-icons';

export default function LoginScreen() {
  const { login, isLoginLoading, loginError } = useAuth();

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: '', password: '' },
  });

  const onSubmit = (data: LoginFormData) => {
    login(data, {
      onError: (error) => {
        Toast.show({
          type: 'error',
          text1: 'Login Failed',
          text2:
            error instanceof Error
              ? error.message
              : 'Invalid email or password',
        });
      },
    });
  };

  return (
    <SafeAreaView className="flex-1 bg-dark">
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        className="flex-1"
      >
        <ScrollView
          className="flex-1 px-6"
          contentContainerStyle={{ flexGrow: 1, justifyContent: 'center' }}
          keyboardShouldPersistTaps="handled"
        >
          {/* Logo/Brand */}
          <View className="items-center mb-10">
            <View className="w-16 h-16 rounded-2xl bg-primary/20 items-center justify-center mb-4">
              <Ionicons name="football" size={32} color="#1DB954" />
            </View>
            <Text className="text-white text-3xl font-bold">BookMyTurf</Text>
            <Text className="text-muted text-sm mt-1">Your sports ground, booked instantly</Text>
          </View>

          <Text className="text-white text-2xl font-bold mb-2">Welcome back</Text>
          <Text className="text-muted text-sm mb-8">
            Sign in to your account to continue
          </Text>

          <Controller
            control={control}
            name="email"
            render={({ field: { onChange, onBlur, value } }) => (
              <CustomInput
                label="Email"
                placeholder="you@example.com"
                keyboardType="email-address"
                autoCapitalize="none"
                autoComplete="email"
                onChangeText={onChange}
                onBlur={onBlur}
                value={value}
                error={errors.email?.message}
                leftIcon={<Ionicons name="mail-outline" size={18} color="#6B7280" />}
              />
            )}
          />

          <Controller
            control={control}
            name="password"
            render={({ field: { onChange, onBlur, value } }) => (
              <CustomInput
                label="Password"
                placeholder="Enter your password"
                secureTextEntry
                onChangeText={onChange}
                onBlur={onBlur}
                value={value}
                error={errors.password?.message}
                leftIcon={<Ionicons name="lock-closed-outline" size={18} color="#6B7280" />}
              />
            )}
          />

          <View className="items-end mb-6">
            <Link href="/(auth)/forgot-password">
              <Text className="text-primary text-sm font-medium">
                Forgot password?
              </Text>
            </Link>
          </View>

          <CustomButton
            title="Sign In"
            onPress={handleSubmit(onSubmit)}
            loading={isLoginLoading}
            fullWidth
          />

          <View className="flex-row items-center justify-center mt-6">
            <Text className="text-muted text-sm">Don't have an account? </Text>
            <Link href="/(auth)/register">
              <Text className="text-primary text-sm font-semibold">
                Sign Up
              </Text>
            </Link>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
