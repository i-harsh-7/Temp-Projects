import React, { useCallback } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  FlatList,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '@/store/authStore';
import { useSearchStore } from '@/store/searchStore';
import { useVenues } from '@/hooks/useVenues';
import VenueCard from '@/components/venue/VenueCard';
import SkeletonLoader from '@/components/common/SkeletonLoader';
import EmptyState from '@/components/common/EmptyState';
import SearchBar from '@/components/common/SearchBar';
import { SPORTS, SPORT_COLORS, SPORT_ICONS } from '@/utils/constants';
import { Venue } from '@/types';

const SPORT_EMOJIS: Record<string, string> = {
  Football: '⚽',
  Cricket: '🏏',
  Basketball: '🏀',
  Badminton: '🏸',
  Tennis: '🎾',
  Volleyball: '🏐',
  Hockey: '🏑',
};

function getGreeting(): string {
  const h = new Date().getHours();
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  return 'Good evening';
}

export default function HomeScreen() {
  const user = useAuthStore((s) => s.user);
  const { selectedCity, setSport } = useSearchStore();

  const {
    data: featuredData,
    isLoading: featuredLoading,
    refetch: refetchFeatured,
    isRefetching,
  } = useVenues({ size: 10 });

  const { data: nearbyData, isLoading: nearbyLoading } = useVenues({
    city: selectedCity ?? undefined,
    size: 6,
  });

  const featuredVenues: Venue[] = (featuredData as any)?.content ?? [];
  const nearbyVenues: Venue[] = (nearbyData as any)?.content ?? [];

  const onRefresh = useCallback(() => {
    refetchFeatured();
  }, [refetchFeatured]);

  const handleVenuePress = (id: string) => {
    router.push(`/venue/${id}`);
  };

  const handleSportPress = (sport: string) => {
    setSport(sport);
    router.push('/(tabs)/search');
  };

  return (
    <SafeAreaView className="flex-1 bg-dark" edges={['top']}>
      <ScrollView
        className="flex-1"
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={isRefetching}
            onRefresh={onRefresh}
            tintColor="#1DB954"
            colors={['#1DB954']}
          />
        }
      >
        {/* Header */}
        <View className="flex-row items-center justify-between px-5 pt-4 pb-3">
          <View>
            <Text className="text-muted text-sm">{getGreeting()},</Text>
            <Text className="text-white text-xl font-bold mt-0.5">
              {user?.name?.split(' ')[0] ?? 'Player'} 👋
            </Text>
          </View>
          <TouchableOpacity
            onPress={() => router.push('/(tabs)/bookings')}
            className="w-10 h-10 rounded-full bg-dark-200 items-center justify-center"
          >
            <Ionicons name="notifications-outline" size={20} color="#fff" />
          </TouchableOpacity>
        </View>

        {/* Search bar (tappable, navigates to search) */}
        <View className="px-5 mb-5">
          <SearchBar
            value=""
            onChangeText={() => {}}
            placeholder="Search venues, sports, cities..."
            editable={false}
            onPress={() => router.push('/(tabs)/search')}
          />
        </View>

        {/* Popular Sports */}
        <View className="mb-6">
          <View className="flex-row items-center justify-between px-5 mb-3">
            <Text className="text-white text-lg font-bold">Popular Sports</Text>
            <TouchableOpacity onPress={() => router.push('/(tabs)/search')}>
              <Text className="text-primary text-sm font-medium">See all</Text>
            </TouchableOpacity>
          </View>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: 20 }}
          >
            {SPORTS.map((sport) => {
              const color = SPORT_COLORS[sport] ?? '#1DB954';
              return (
                <TouchableOpacity
                  key={sport}
                  onPress={() => handleSportPress(sport)}
                  activeOpacity={0.75}
                  className="mr-3 items-center"
                >
                  <View
                    className="w-16 h-16 rounded-2xl items-center justify-center mb-1.5"
                    style={{ backgroundColor: `${color}20` }}
                  >
                    <Text style={{ fontSize: 28 }}>{SPORT_EMOJIS[sport] ?? '🏅'}</Text>
                  </View>
                  <Text className="text-white text-xs font-medium">{sport}</Text>
                </TouchableOpacity>
              );
            })}
          </ScrollView>
        </View>

        {/* Featured Venues */}
        <View className="mb-6">
          <View className="flex-row items-center justify-between px-5 mb-3">
            <Text className="text-white text-lg font-bold">Featured Venues</Text>
            <TouchableOpacity onPress={() => router.push('/(tabs)/search')}>
              <Text className="text-primary text-sm font-medium">See all</Text>
            </TouchableOpacity>
          </View>

          {featuredLoading ? (
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ paddingHorizontal: 20 }}
            >
              {[1, 2, 3].map((i) => (
                <View key={i} style={{ width: 280, marginRight: 16 }}>
                  <SkeletonLoader variant="card" count={1} />
                </View>
              ))}
            </ScrollView>
          ) : featuredVenues.length === 0 ? (
            <View className="px-5">
              <EmptyState
                icon="location-outline"
                title="No venues found"
                subtitle="Check back later for featured venues"
              />
            </View>
          ) : (
            <FlatList
              data={featuredVenues}
              keyExtractor={(item) => item.id}
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ paddingHorizontal: 20 }}
              renderItem={({ item }) => (
                <View style={{ width: 300, marginRight: 16 }}>
                  <VenueCard
                    venue={item}
                    onPress={() => handleVenuePress(item.id)}
                  />
                </View>
              )}
            />
          )}
        </View>

        {/* Nearby Venues */}
        <View className="px-5 mb-8">
          <View className="flex-row items-center justify-between mb-3">
            <Text className="text-white text-lg font-bold">
              {selectedCity ? `Venues in ${selectedCity}` : 'All Venues'}
            </Text>
            <TouchableOpacity onPress={() => router.push('/(tabs)/search')}>
              <Text className="text-primary text-sm font-medium">View all</Text>
            </TouchableOpacity>
          </View>

          {nearbyLoading ? (
            <SkeletonLoader variant="card" count={3} />
          ) : nearbyVenues.length === 0 ? (
            <EmptyState
              icon="location-outline"
              title="No venues nearby"
              subtitle={
                selectedCity
                  ? `No venues found in ${selectedCity}`
                  : 'No venues available yet'
              }
              actionLabel="Search Venues"
              onAction={() => router.push('/(tabs)/search')}
            />
          ) : (
            nearbyVenues.map((venue) => (
              <VenueCard
                key={venue.id}
                venue={venue}
                onPress={() => handleVenuePress(venue.id)}
              />
            ))
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
