import React, { useState } from 'react';
import {
  View,
  Text,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { router } from 'expo-router';
import Toast from 'react-native-toast-message';
import { Ionicons } from '@expo/vector-icons';
import CustomInput from '@/components/common/CustomInput';
import CustomButton from '@/components/common/CustomButton';
import { forgotPasswordSchema, ForgotPasswordFormData } from '@/utils/validation';
import { authService } from '@/services/authService';

export default function ForgotPasswordScreen() {
  const [isLoading, setIsLoading] = useState(false);
  const [emailSent, setEmailSent] = useState(false);

  const {
    control,
    handleSubmit,
    formState: { errors },
    getValues,
  } = useForm<ForgotPasswordFormData>({
    resolver: zodResolver(forgotPasswordSchema),
    defaultValues: { email: '' },
  });

  const onSubmit = async (data: ForgotPasswordFormData) => {
    setIsLoading(true);
    try {
      await authService.forgotPassword(data.email);
      setEmailSent(true);
    } catch {
      Toast.show({
        type: 'error',
        text1: 'Error',
        text2: 'Could not send reset email. Please try again.',
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (emailSent) {
    return (
      <SafeAreaView className="flex-1 bg-dark">
        <View className="flex-1 items-center justify-center px-6">
          <View className="w-20 h-20 rounded-full bg-primary/20 items-center justify-center mb-6">
            <Ionicons name="mail-open-outline" size={40} color="#1DB954" />
          </View>
          <Text className="text-white text-2xl font-bold text-center mb-3">
            Check your email
          </Text>
          <Text className="text-muted text-sm text-center leading-6 mb-8 max-w-xs">
            We've sent password reset instructions to{' '}
            <Text className="text-white">{getValues('email')}</Text>
          </Text>
          <CustomButton
            title="Back to Login"
            onPress={() => router.replace('/(auth)/login')}
            fullWidth
          />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView className="flex-1 bg-dark">
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        className="flex-1"
      >
        <ScrollView
          className="flex-1 px-6"
          contentContainerStyle={{ flexGrow: 1, justifyContent: 'center' }}
          keyboardShouldPersistTaps="handled"
        >
          <CustomButton
            title="Back"
            variant="ghost"
            size="sm"
            onPress={() => router.back()}
            icon={<Ionicons name="arrow-back" size={18} color="#1DB954" />}
          />

          <View className="mt-8 mb-8">
            <Text className="text-white text-2xl font-bold mb-2">
              Forgot Password
            </Text>
            <Text className="text-muted text-sm leading-6">
              Enter your email address and we'll send you a link to reset your
              password.
            </Text>
          </View>

          <Controller
            control={control}
            name="email"
            render={({ field: { onChange, onBlur, value } }) => (
              <CustomInput
                label="Email"
                placeholder="you@example.com"
                keyboardType="email-address"
                autoCapitalize="none"
                onChangeText={onChange}
                onBlur={onBlur}
                value={value}
                error={errors.email?.message}
                leftIcon={<Ionicons name="mail-outline" size={18} color="#6B7280" />}
              />
            )}
          />

          <CustomButton
            title="Send Reset Link"
            onPress={handleSubmit(onSubmit)}
            loading={isLoading}
            fullWidth
          />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
