import React from 'react';
import { View, Text, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Booking } from '@/types';
import {
  formatCurrency,
  formatDate,
  formatTime,
  getBookingStatusColor,
  getPaymentStatusColor,
} from '@/utils/helpers';

interface BookingCardProps {
  booking: Booking;
  onPress?: () => void;
}

const BookingCard: React.FC<BookingCardProps> = ({ booking, onPress }) => {
  const bookingStatusColor = getBookingStatusColor(booking.bookingStatus);
  const paymentStatusColor = getPaymentStatusColor(booking.paymentStatus);

  const content = (
    <View className="bg-card rounded-2xl p-4 mb-3">
      {/* Header: booking number + status badges */}
      <View className="flex-row items-center justify-between mb-3">
        <View>
          <Text className="text-muted text-xs">Booking #</Text>
          <Text className="text-white text-sm font-bold mt-0.5">
            {booking.bookingNumber}
          </Text>
        </View>

        <View className="flex-row items-center gap-2">
          {/* Booking status badge */}
          <View
            className="rounded-full px-2.5 py-1"
            style={{ backgroundColor: `${bookingStatusColor}20`, borderWidth: 1, borderColor: `${bookingStatusColor}40` }}
          >
            <Text className="text-xs font-semibold" style={{ color: bookingStatusColor }}>
              {booking.bookingStatus}
            </Text>
          </View>

          {/* Payment status badge */}
          <View
            className="rounded-full px-2.5 py-1"
            style={{ backgroundColor: `${paymentStatusColor}20`, borderWidth: 1, borderColor: `${paymentStatusColor}40` }}
          >
            <Text className="text-xs font-medium" style={{ color: paymentStatusColor }}>
              {booking.paymentStatus}
            </Text>
          </View>
        </View>
      </View>

      {/* Venue and turf info */}
      <View className="h-px bg-dark-300 mb-3" />

      <View className="flex-row items-start mb-2">
        <Ionicons name="location" size={16} color="#1DB954" style={{ marginTop: 1 }} />
        <View className="ml-2 flex-1">
          <Text className="text-white text-sm font-semibold" numberOfLines={1}>
            {booking.venueName}
          </Text>
          <Text className="text-muted text-xs mt-0.5">{booking.turfName}</Text>
        </View>
      </View>

      {/* Date and time */}
      <View className="flex-row items-center mb-2">
        <Ionicons name="calendar-outline" size={15} color="#6B7280" />
        <Text className="text-white text-sm ml-2">
          {formatDate(booking.bookingDate)}
        </Text>
      </View>

      <View className="flex-row items-center mb-3">
        <Ionicons name="time-outline" size={15} color="#6B7280" />
        <Text className="text-white text-sm ml-2">
          {formatTime(booking.startTime)} – {formatTime(booking.endTime)}
        </Text>
      </View>

      {/* Footer: amount + arrow */}
      <View className="h-px bg-dark-300 mb-3" />

      <View className="flex-row items-center justify-between">
        <View>
          <Text className="text-muted text-xs">Total Amount</Text>
          <Text className="text-primary font-bold text-lg mt-0.5">
            {formatCurrency(booking.amount)}
          </Text>
        </View>

        {onPress && (
          <View className="flex-row items-center">
            <Text className="text-muted text-xs mr-1">Details</Text>
            <Ionicons name="chevron-forward" size={16} color="#6B7280" />
          </View>
        )}
      </View>
    </View>
  );

  if (onPress) {
    return (
      <Pressable onPress={onPress} className="active:opacity-80">
        {content}
      </Pressable>
    );
  }

  return content;
};

export default BookingCard;
