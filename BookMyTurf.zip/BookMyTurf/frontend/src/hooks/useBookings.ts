import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { bookingService } from '@/services/bookingService';
import { CreateBookingRequest } from '@/types';
import { QUERY_KEYS } from '@/utils/constants';

export const useMyBookings = () => {
  return useQuery({
    queryKey: [QUERY_KEYS.MY_BOOKINGS],
    queryFn: () => bookingService.getMyBookings(),
    staleTime: 2 * 60 * 1000,
    select: (data) => data.data,
  });
};

export const useBookingById = (id: string) => {
  return useQuery({
    queryKey: [QUERY_KEYS.BOOKING, id],
    queryFn: () => bookingService.getBookingById(id),
    enabled: !!id,
    staleTime: 2 * 60 * 1000,
    select: (data) => data.data,
  });
};

export const useVenueBookings = (
  venueId: string,
  params?: { page?: number; size?: number; date?: string }
) => {
  return useQuery({
    queryKey: [QUERY_KEYS.VENUE_BOOKINGS, venueId, params],
    queryFn: () => bookingService.getVenueBookings(venueId, params),
    enabled: !!venueId,
    staleTime: 2 * 60 * 1000,
    select: (data) => data.data,
  });
};

export const useAllBookings = (params?: {
  page?: number;
  size?: number;
  status?: string;
}) => {
  return useQuery({
    queryKey: [QUERY_KEYS.ALL_BOOKINGS, params],
    queryFn: () => bookingService.getAllBookings(params),
    staleTime: 2 * 60 * 1000,
    select: (data) => data.data,
  });
};

export const useCreateBooking = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: CreateBookingRequest) =>
      bookingService.createBooking(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.MY_BOOKINGS] });
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.SLOTS] });
    },
  });
};

export const useCancelBooking = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => bookingService.cancelBooking(id),
    onSuccess: (response) => {
      const booking = response.data;
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.MY_BOOKINGS] });
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEYS.BOOKING, booking.id],
      });
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.SLOTS] });
    },
  });
};
