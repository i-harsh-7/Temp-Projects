import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as Clipboard from 'expo-clipboard';
import Toast from 'react-native-toast-message';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  withTiming,
  withDelay,
  withRepeat,
  Easing,
} from 'react-native-reanimated';

import { useBookingById } from '@/hooks/useBookings';
import { formatCurrency, formatDate, formatTime } from '@/utils/helpers';
import CustomButton from '@/components/common/CustomButton';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

// ---------------------------------------------------------------------------
// Confetti dot
// ---------------------------------------------------------------------------
const CONFETTI_COLORS = ['#1DB954', '#FF6B35', '#3B82F6', '#F59E0B', '#EC4899'];

interface ConfettiDotProps {
  index: number;
}

const ConfettiDot: React.FC<ConfettiDotProps> = ({ index }) => {
  const translateY = useSharedValue(-40);
  const translateX = useSharedValue(0);
  const opacity = useSharedValue(0);
  const rotate = useSharedValue(0);

  const startX = (index * 37) % SCREEN_WIDTH;
  const size = 6 + (index % 4) * 2;
  const color = CONFETTI_COLORS[index % CONFETTI_COLORS.length];
  const duration = 2600 + (index % 5) * 400;
  const delay = (index % 8) * 180;
  const drift = ((index % 5) - 2) * 30;

  useEffect(() => {
    opacity.value = withDelay(delay, withTiming(1, { duration: 200 }));
    translateY.value = withDelay(
      delay,
      withRepeat(
        withTiming(SCREEN_HEIGHT * 0.85, {
          duration,
          easing: Easing.in(Easing.quad),
        }),
        -1,
        false
      )
    );
    translateX.value = withDelay(
      delay,
      withRepeat(
        withTiming(drift, { duration: duration / 2, easing: Easing.inOut(Easing.ease) }),
        -1,
        true
      )
    );
    rotate.value = withDelay(
      delay,
      withRepeat(withTiming(360, { duration: duration / 1.5, easing: Easing.linear }), -1, false)
    );
  }, []);

  const style = useAnimatedStyle(() => ({
    opacity: opacity.value,
    transform: [
      { translateX: translateX.value },
      { translateY: translateY.value },
      { rotate: `${rotate.value}deg` },
    ],
  }));

  return (
    <Animated.View
      pointerEvents="none"
      style={[
        {
          position: 'absolute',
          top: 0,
          left: startX,
          width: size,
          height: size * 1.6,
          borderRadius: 2,
          backgroundColor: color,
        },
        style,
      ]}
    />
  );
};

// ---------------------------------------------------------------------------
// Screen
// ---------------------------------------------------------------------------
export default function BookingSuccessScreen() {
  const params = useLocalSearchParams<{
    bookingId?: string;
    bookingNumber?: string;
    venueName?: string;
    turfName?: string;
    bookingDate?: string;
    startTime?: string;
    endTime?: string;
    amount?: string;
  }>();

  // The booking is fetched (when an id is available) so we can resolve the
  // canonical booking number; params remain as a fast fallback.
  const { data: booking } = useBookingById(params.bookingId ?? '');

  const bookingNumber =
    booking?.bookingNumber ?? params.bookingNumber ?? params.bookingId ?? '—';
  const venueName = booking?.venueName ?? params.venueName ?? '—';
  const turfName = booking?.turfName ?? params.turfName ?? '—';
  const bookingDate = booking?.bookingDate ?? params.bookingDate ?? '';
  const startTime = booking?.startTime ?? params.startTime ?? '';
  const endTime = booking?.endTime ?? params.endTime ?? '';
  const amount = booking?.amount ?? Number(params.amount ?? 0);

  const [copied, setCopied] = useState(false);

  // Animations -------------------------------------------------------------
  const checkScale = useSharedValue(0);
  const checkOpacity = useSharedValue(0);
  const ringScale = useSharedValue(0.6);
  const ringOpacity = useSharedValue(0);

  useEffect(() => {
    checkScale.value = withDelay(
      150,
      withSpring(1, { damping: 9, stiffness: 140, mass: 0.7 })
    );
    checkOpacity.value = withDelay(150, withTiming(1, { duration: 300 }));
    ringScale.value = withDelay(120, withSpring(1, { damping: 12, stiffness: 120 }));
    ringOpacity.value = withDelay(120, withTiming(1, { duration: 350 }));
  }, []);

  const checkStyle = useAnimatedStyle(() => ({
    opacity: checkOpacity.value,
    transform: [{ scale: checkScale.value }],
  }));

  const ringStyle = useAnimatedStyle(() => ({
    opacity: ringOpacity.value,
    transform: [{ scale: ringScale.value }],
  }));

  const handleCopy = async () => {
    if (bookingNumber === '—') return;
    await Clipboard.setStringAsync(bookingNumber);
    setCopied(true);
    Toast.show({ type: 'success', text1: 'Booking number copied' });
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <SafeAreaView className="flex-1 bg-dark" edges={['top', 'bottom']}>
      {/* Confetti layer */}
      <View
        pointerEvents="none"
        style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}
      >
        {Array.from({ length: 24 }, (_, i) => (
          <ConfettiDot key={i} index={i} />
        ))}
      </View>

      <ScrollView
        className="flex-1"
        contentContainerStyle={{ flexGrow: 1, paddingHorizontal: 24, paddingTop: 40, paddingBottom: 24 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Animated checkmark */}
        <View className="items-center mb-6">
          <View style={{ width: 120, height: 120, alignItems: 'center', justifyContent: 'center' }}>
            <Animated.View
              style={[
                {
                  position: 'absolute',
                  width: 120,
                  height: 120,
                  borderRadius: 60,
                  backgroundColor: 'rgba(29,185,84,0.12)',
                },
                ringStyle,
              ]}
            />
            <Animated.View
              style={[
                {
                  width: 84,
                  height: 84,
                  borderRadius: 42,
                  backgroundColor: '#1DB954',
                  alignItems: 'center',
                  justifyContent: 'center',
                },
                checkStyle,
              ]}
            >
              <Ionicons name="checkmark" size={48} color="#FFFFFF" />
            </Animated.View>
          </View>
        </View>

        {/* Title */}
        <Text className="text-white text-2xl font-bold text-center">
          Booking Confirmed!
        </Text>
        <Text className="text-muted text-sm text-center mt-2 mb-6">
          Your slot is reserved. We&apos;ve sent the details to your account.
        </Text>

        {/* Booking number */}
        <View className="bg-card rounded-2xl p-5 mb-4 border border-dark-300 items-center">
          <Text className="text-muted text-xs uppercase tracking-wide">
            Booking Number
          </Text>
          <Text className="text-primary text-2xl font-bold mt-1.5 tracking-wider">
            {bookingNumber}
          </Text>
          <TouchableOpacity
            onPress={handleCopy}
            activeOpacity={0.7}
            className="flex-row items-center mt-3 px-4 py-2 rounded-full bg-dark-200"
          >
            <Ionicons
              name={copied ? 'checkmark-circle' : 'copy-outline'}
              size={16}
              color="#1DB954"
            />
            <Text className="text-primary text-sm font-medium ml-1.5">
              {copied ? 'Copied' : 'Copy'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Summary card */}
        <View className="bg-card rounded-2xl p-5 mb-6 border border-dark-300">
          <Text className="text-white text-base font-bold mb-4">Summary</Text>

          <SummaryRow icon="location-outline" label="Venue" value={venueName} />
          <SummaryRow icon="football-outline" label="Turf" value={turfName} />
          <SummaryRow
            icon="calendar-outline"
            label="Date"
            value={bookingDate ? formatDate(bookingDate) : '—'}
          />
          <SummaryRow
            icon="time-outline"
            label="Time"
            value={
              startTime && endTime
                ? `${formatTime(startTime)} – ${formatTime(endTime)}`
                : '—'
            }
          />

          <View className="h-px bg-dark-300 my-3" />

          <View className="flex-row items-center justify-between">
            <Text className="text-white text-base font-bold">Amount Paid</Text>
            <Text className="text-primary text-xl font-bold">
              {formatCurrency(amount)}
            </Text>
          </View>
        </View>

        <View className="flex-1" />

        {/* Actions */}
        <View style={{ gap: 12 }}>
          <CustomButton
            title="View My Bookings"
            onPress={() => router.replace('/(tabs)/bookings' as any)}
            variant="primary"
            fullWidth
            icon={<Ionicons name="list-outline" size={18} color="#fff" />}
          />
          <CustomButton
            title="Go Home"
            onPress={() => router.replace('/(tabs)/home' as any)}
            variant="outline"
            fullWidth
            icon={<Ionicons name="home-outline" size={18} color="#1DB954" />}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function SummaryRow({
  icon,
  label,
  value,
}: {
  icon: React.ComponentProps<typeof Ionicons>['name'];
  label: string;
  value: string;
}) {
  return (
    <View className="flex-row items-center justify-between mb-3">
      <View className="flex-row items-center">
        <View className="w-8 h-8 rounded-lg bg-dark-300 items-center justify-center mr-2.5">
          <Ionicons name={icon} size={15} color="#6B7280" />
        </View>
        <Text className="text-muted text-sm">{label}</Text>
      </View>
      <Text
        className="text-white text-sm font-medium flex-1 text-right ml-4"
        numberOfLines={1}
      >
        {value}
      </Text>
    </View>
  );
}
