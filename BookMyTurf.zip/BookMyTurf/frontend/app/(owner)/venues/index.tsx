import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  RefreshControl,
  TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useQueryClient } from '@tanstack/react-query';
import Toast from 'react-native-toast-message';

import { useMyVenues, useDeleteVenue } from '@/hooks/useVenues';
import { QUERY_KEYS } from '@/utils/constants';
import { venueService } from '@/services/venueService';
import { Venue } from '@/types';

import VenueManageCard from '@/components/owner/VenueManageCard';
import SkeletonLoader from '@/components/common/SkeletonLoader';
import EmptyState from '@/components/common/EmptyState';
import ConfirmDialog from '@/components/common/ConfirmDialog';

export default function VenueListScreen() {
  const router = useRouter();
  const queryClient = useQueryClient();

  const { data: venues = [], isLoading, refetch } = useMyVenues();
  const { mutateAsync: deleteVenue, isPending: isDeleting } = useDeleteVenue();

  const [refreshing, setRefreshing] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Venue | null>(null);
  const [togglingId, setTogglingId] = useState<string | null>(null);

  const onRefresh = async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  };

  const handleToggleActive = async (venue: Venue) => {
    if (togglingId === venue.id) return;
    setTogglingId(venue.id);
    try {
      await venueService.toggleVenueActive(venue.id);
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.MY_VENUES] });
    } catch {
      Toast.show({ type: 'error', text1: 'Failed to update venue status' });
    } finally {
      setTogglingId(null);
    }
  };

  const handleDeleteConfirm = async () => {
    if (!deleteTarget) return;
    try {
      await deleteVenue(deleteTarget.id);
      Toast.show({
        type: 'success',
        text1: 'Venue deleted',
        text2: `${deleteTarget.name} has been removed.`,
      });
    } catch {
      Toast.show({ type: 'error', text1: 'Failed to delete venue' });
    } finally {
      setDeleteTarget(null);
    }
  };

  return (
    <SafeAreaView className="flex-1 bg-dark">
      {/* Header */}
      <View className="flex-row items-center px-4 pt-2 pb-4 border-b border-dark-300">
        <TouchableOpacity
          onPress={() => router.back()}
          activeOpacity={0.7}
          style={{
            width: 40,
            height: 40,
            borderRadius: 20,
            backgroundColor: '#1A1A1A',
            alignItems: 'center',
            justifyContent: 'center',
            marginRight: 12,
          }}
        >
          <Ionicons name="arrow-back" size={20} color="#FFFFFF" />
        </TouchableOpacity>
        <Text className="text-white text-xl font-bold flex-1">My Venues</Text>
        <View
          style={{
            backgroundColor: '#1A1A1A',
            paddingHorizontal: 10,
            paddingVertical: 4,
            borderRadius: 12,
          }}
        >
          <Text style={{ color: '#6B7280', fontSize: 13 }}>
            {venues.length} venue{venues.length !== 1 ? 's' : ''}
          </Text>
        </View>
      </View>

      {/* List */}
      {isLoading ? (
        <View className="px-4 mt-4">
          <SkeletonLoader variant="list" count={4} />
        </View>
      ) : venues.length === 0 ? (
        <EmptyState
          icon="business-outline"
          title="No venues yet"
          subtitle="Add your first venue and start accepting bookings!"
          actionLabel="Add Venue"
          onAction={() => router.push('/(owner)/venues/create' as any)}
        />
      ) : (
        <ScrollView
          className="flex-1 px-4"
          contentContainerStyle={{ paddingTop: 16, paddingBottom: 100 }}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              tintColor="#1DB954"
              colors={['#1DB954']}
            />
          }
        >
          {venues.map((venue) => (
            <VenueManageCard
              key={venue.id}
              venue={venue}
              onEdit={(v) =>
                router.push(`/(owner)/venues/${v.id}/edit` as any)
              }
              onDelete={(v) => setDeleteTarget(v)}
              onToggleActive={handleToggleActive}
              onManageTurfs={(v) =>
                router.push(`/(owner)/venues/${v.id}/turfs` as any)
              }
            />
          ))}
        </ScrollView>
      )}

      {/* FAB */}
      <TouchableOpacity
        onPress={() => router.push('/(owner)/venues/create' as any)}
        activeOpacity={0.85}
        style={{
          position: 'absolute',
          bottom: 32,
          right: 24,
          width: 56,
          height: 56,
          borderRadius: 28,
          backgroundColor: '#1DB954',
          alignItems: 'center',
          justifyContent: 'center',
          shadowColor: '#1DB954',
          shadowOffset: { width: 0, height: 4 },
          shadowOpacity: 0.4,
          shadowRadius: 8,
          elevation: 8,
        }}
      >
        <Ionicons name="add" size={28} color="#FFFFFF" />
      </TouchableOpacity>

      <ConfirmDialog
        visible={!!deleteTarget}
        title="Delete Venue"
        message={`Are you sure you want to delete "${deleteTarget?.name}"? This action cannot be undone.`}
        confirmLabel="Delete"
        cancelLabel="Cancel"
        destructive
        loading={isDeleting}
        onConfirm={handleDeleteConfirm}
        onCancel={() => setDeleteTarget(null)}
      />
    </SafeAreaView>
  );
}
