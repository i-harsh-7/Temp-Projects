package com.bookmyturf.redis;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class RedisLockService {

    private final RedisTemplate<String, String> redisTemplate;

    private static final long LOCK_TTL_MS = 300_000L; // 5 minutes
    private static final String LOCK_VALUE = "locked";

    private String buildLockKey(String turfId, LocalDate date, LocalTime startTime, LocalTime endTime) {
        return String.format("slot_lock:%s:%s:%s-%s", turfId, date, startTime, endTime);
    }

    /**
     * Attempts to acquire a distributed lock for a turf slot.
     * Uses Redis SET NX (set if not exists) with a 5-minute TTL.
     *
     * @return true if lock was acquired, false if slot is already locked
     */
    public boolean acquireSlotLock(String turfId, LocalDate date, LocalTime startTime, LocalTime endTime) {
        String key = buildLockKey(turfId, date, startTime, endTime);
        Boolean acquired = redisTemplate.opsForValue()
                .setIfAbsent(key, LOCK_VALUE, Duration.ofMillis(LOCK_TTL_MS));
        boolean result = Boolean.TRUE.equals(acquired);
        log.debug("Slot lock acquisition for key '{}': {}", key, result ? "SUCCESS" : "FAILED");
        return result;
    }

    /**
     * Releases the distributed lock for a turf slot.
     */
    public void releaseSlotLock(String turfId, LocalDate date, LocalTime startTime, LocalTime endTime) {
        String key = buildLockKey(turfId, date, startTime, endTime);
        Boolean deleted = redisTemplate.delete(key);
        log.debug("Slot lock released for key '{}': {}", key, Boolean.TRUE.equals(deleted));
    }

    /**
     * Checks whether a turf slot is currently locked.
     *
     * @return true if the slot is locked, false otherwise
     */
    public boolean isSlotLocked(String turfId, LocalDate date, LocalTime startTime, LocalTime endTime) {
        String key = buildLockKey(turfId, date, startTime, endTime);
        Boolean exists = redisTemplate.hasKey(key);
        return Boolean.TRUE.equals(exists);
    }
}
