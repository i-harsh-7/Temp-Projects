package com.bookmyturf.service;

import com.bookmyturf.dto.BookingResponse;
import com.bookmyturf.dto.PaymentVerificationRequest;
import com.bookmyturf.entity.Booking;
import com.bookmyturf.entity.Payment;
import com.bookmyturf.exception.BadRequestException;
import com.bookmyturf.exception.ResourceNotFoundException;
import com.bookmyturf.exception.UnauthorizedException;
import com.bookmyturf.repository.BookingRepository;
import com.bookmyturf.repository.PaymentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("PaymentService unit tests (signature verification)")
class PaymentServiceTest {

    private static final String SECRET = "test_secret_key";
    private static final String ORDER_ID = "order_ABC123";
    private static final String PAYMENT_ID = "pay_XYZ789";
    private static final String BOOKING_ID = "booking-1";

    @Mock
    private BookingRepository bookingRepository;
    @Mock
    private PaymentRepository paymentRepository;
    @Mock
    private BookingService bookingService;

    @InjectMocks
    private PaymentService paymentService;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(paymentService, "razorpayKeySecret", SECRET);
        ReflectionTestUtils.setField(paymentService, "razorpayKeyId", "rzp_test_key");
    }

    private static String hmacSha256Hex(String data, String secret) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        byte[] hash = mac.doFinal(data.getBytes(StandardCharsets.UTF_8));
        StringBuilder hex = new StringBuilder();
        for (byte b : hash) {
            String h = Integer.toHexString(0xff & b);
            if (h.length() == 1) hex.append('0');
            hex.append(h);
        }
        return hex.toString();
    }

    @Test
    @DisplayName("verifyAndCompletePayment: a valid signature marks payment PAID and confirms booking")
    void verifyAndCompletePayment_validSignature_confirmsBooking() throws Exception {
        String payload = ORDER_ID + "|" + PAYMENT_ID;
        String validSignature = hmacSha256Hex(payload, SECRET);

        PaymentVerificationRequest req = PaymentVerificationRequest.builder()
                .razorpayOrderId(ORDER_ID)
                .razorpayPaymentId(PAYMENT_ID)
                .razorpaySignature(validSignature)
                .bookingId(BOOKING_ID)
                .build();

        Payment payment = Payment.builder()
                .id("pay-1")
                .bookingId(BOOKING_ID)
                .razorpayOrderId(ORDER_ID)
                .status(Payment.PaymentStatus.CREATED)
                .build();
        when(paymentRepository.findByRazorpayOrderId(ORDER_ID)).thenReturn(Optional.of(payment));

        BookingResponse confirmed = BookingResponse.builder()
                .id(BOOKING_ID)
                .bookingStatus(Booking.BookingStatus.CONFIRMED)
                .paymentStatus(Booking.PaymentStatus.PAID)
                .build();
        when(bookingService.confirmBooking(BOOKING_ID)).thenReturn(confirmed);

        BookingResponse response = paymentService.verifyAndCompletePayment(req, "user-1");

        assertThat(response.getBookingStatus()).isEqualTo(Booking.BookingStatus.CONFIRMED);
        assertThat(response.getPaymentStatus()).isEqualTo(Booking.PaymentStatus.PAID);

        ArgumentCaptor<Payment> captor = ArgumentCaptor.forClass(Payment.class);
        verify(paymentRepository).save(captor.capture());
        assertThat(captor.getValue().getStatus()).isEqualTo(Payment.PaymentStatus.PAID);
        assertThat(captor.getValue().getRazorpayPaymentId()).isEqualTo(PAYMENT_ID);
        assertThat(captor.getValue().getRazorpaySignature()).isEqualTo(validSignature);
        verify(bookingService).confirmBooking(BOOKING_ID);
    }

    @Test
    @DisplayName("verifyAndCompletePayment: an invalid signature throws UnauthorizedException")
    void verifyAndCompletePayment_invalidSignature_throwsUnauthorized() {
        PaymentVerificationRequest req = PaymentVerificationRequest.builder()
                .razorpayOrderId(ORDER_ID)
                .razorpayPaymentId(PAYMENT_ID)
                .razorpaySignature("deadbeefgarbagesignature")
                .bookingId(BOOKING_ID)
                .build();

        assertThatThrownBy(() -> paymentService.verifyAndCompletePayment(req, "user-1"))
                .isInstanceOf(UnauthorizedException.class)
                .hasMessageContaining("signature verification failed");

        verify(paymentRepository, never()).save(any());
        verify(bookingService, never()).confirmBooking(any());
    }

    @Test
    @DisplayName("handlePaymentFailure: sets payment FAILED and booking payment status FAILED")
    void handlePaymentFailure_setsFailedStatus() {
        Payment payment = Payment.builder()
                .id("pay-1")
                .bookingId(BOOKING_ID)
                .razorpayOrderId(ORDER_ID)
                .status(Payment.PaymentStatus.CREATED)
                .build();
        Booking booking = Booking.builder()
                .id(BOOKING_ID)
                .paymentStatus(Booking.PaymentStatus.PENDING)
                .bookingStatus(Booking.BookingStatus.PENDING)
                .build();
        when(paymentRepository.findByRazorpayOrderId(ORDER_ID)).thenReturn(Optional.of(payment));
        when(bookingRepository.findById(BOOKING_ID)).thenReturn(Optional.of(booking));

        paymentService.handlePaymentFailure(ORDER_ID);

        ArgumentCaptor<Payment> paymentCaptor = ArgumentCaptor.forClass(Payment.class);
        verify(paymentRepository).save(paymentCaptor.capture());
        assertThat(paymentCaptor.getValue().getStatus()).isEqualTo(Payment.PaymentStatus.FAILED);

        ArgumentCaptor<Booking> bookingCaptor = ArgumentCaptor.forClass(Booking.class);
        verify(bookingRepository).save(bookingCaptor.capture());
        assertThat(bookingCaptor.getValue().getPaymentStatus()).isEqualTo(Booking.PaymentStatus.FAILED);
    }

    @Test
    @DisplayName("createRazorpayOrder: throws ResourceNotFoundException when booking does not exist")
    void createRazorpayOrder_bookingNotFound_throws() {
        when(bookingRepository.findById(BOOKING_ID)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> paymentService.createRazorpayOrder(BOOKING_ID, "user-1"))
                .isInstanceOf(ResourceNotFoundException.class);

        verify(paymentRepository, never()).save(any());
    }

    @Test
    @DisplayName("createRazorpayOrder: throws BadRequestException when booking payment status is not PENDING")
    void createRazorpayOrder_notPending_throwsBadRequest() {
        Booking booking = Booking.builder()
                .id(BOOKING_ID)
                .userId("user-1")
                .paymentStatus(Booking.PaymentStatus.PAID)
                .bookingStatus(Booking.BookingStatus.CONFIRMED)
                .build();
        when(bookingRepository.findById(BOOKING_ID)).thenReturn(Optional.of(booking));

        assertThatThrownBy(() -> paymentService.createRazorpayOrder(BOOKING_ID, "user-1"))
                .isInstanceOf(BadRequestException.class)
                .hasMessageContaining("not PENDING");

        verify(paymentRepository, never()).save(any());
    }
}
