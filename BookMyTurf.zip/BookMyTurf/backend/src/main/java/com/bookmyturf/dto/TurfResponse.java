package com.bookmyturf.dto;

import lombok.*;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TurfResponse {

    private String id;

    private String venueId;

    private String name;

    private String sport;

    private BigDecimal pricePerHour;

    private LocalTime openingTime;

    private LocalTime closingTime;

    private List<String> images;

    private List<String> amenities;

    private boolean active;

    private Instant createdAt;

    private Instant updatedAt;
}
