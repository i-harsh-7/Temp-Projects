import { api } from './api';
import {
  ApiResponse,
  Booking,
  CreateBookingRequest,
  PageResponse,
} from '@/types';

export const bookingService = {
  createBooking: async (
    data: CreateBookingRequest
  ): Promise<ApiResponse<Booking>> => {
    const response = await api.post<ApiResponse<Booking>>('/bookings', data);
    return response.data;
  },

  getMyBookings: async (): Promise<ApiResponse<Booking[]>> => {
    const response = await api.get<ApiResponse<Booking[]>>('/bookings/my');
    return response.data;
  },

  getBookingById: async (id: string): Promise<ApiResponse<Booking>> => {
    const response = await api.get<ApiResponse<Booking>>(`/bookings/${id}`);
    return response.data;
  },

  cancelBooking: async (id: string): Promise<ApiResponse<Booking>> => {
    const response = await api.patch<ApiResponse<Booking>>(
      `/bookings/${id}/cancel`
    );
    return response.data;
  },

  getVenueBookings: async (
    venueId: string,
    params?: { page?: number; size?: number; date?: string }
  ): Promise<ApiResponse<PageResponse<Booking>>> => {
    const response = await api.get<ApiResponse<PageResponse<Booking>>>(
      `/venues/${venueId}/bookings`,
      { params }
    );
    return response.data;
  },

  getAllBookings: async (params?: {
    page?: number;
    size?: number;
    status?: string;
  }): Promise<ApiResponse<PageResponse<Booking>>> => {
    const response = await api.get<ApiResponse<PageResponse<Booking>>>(
      '/admin/bookings',
      { params }
    );
    return response.data;
  },

  getBookingByNumber: async (
    bookingNumber: string
  ): Promise<ApiResponse<Booking>> => {
    const response = await api.get<ApiResponse<Booking>>(
      `/bookings/number/${bookingNumber}`
    );
    return response.data;
  },
};
