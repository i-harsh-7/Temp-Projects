import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  TextInput,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Image } from 'expo-image';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import Toast from 'react-native-toast-message';

import {
  useVenueById,
  useUpdateVenue,
  useUploadVenueImages,
} from '@/hooks/useVenues';
import { CITIES, SPORTS, AMENITIES } from '@/utils/constants';

import CustomButton from '@/components/common/CustomButton';
import CustomInput from '@/components/common/CustomInput';
import MultiSelect from '@/components/common/MultiSelect';
import ImageUploader from '@/components/common/ImageUploader';
import SkeletonLoader from '@/components/common/SkeletonLoader';
import EmptyState from '@/components/common/EmptyState';

// ---------------------------------------------------------------------------
// Schema (mirrors create.tsx)
// ---------------------------------------------------------------------------
const schema = z.object({
  name: z.string().min(3, 'Name must be at least 3 characters'),
  description: z.string().min(10, 'Description must be at least 10 characters'),
  address: z.string().min(5, 'Address is required'),
  city: z.string().min(1, 'City is required'),
  sports: z.array(z.string()).min(1, 'Select at least one sport'),
  amenities: z.array(z.string()),
  latitude: z.number({ invalid_type_error: 'Enter a valid number' }),
  longitude: z.number({ invalid_type_error: 'Enter a valid number' }),
});

type FormValues = z.infer<typeof schema>;

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------
export default function EditVenueScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const venueId = id ?? '';

  const { data: venue, isLoading, isError, refetch } = useVenueById(venueId);
  const { mutateAsync: updateVenue, isPending: isUpdating } = useUpdateVenue();
  const { mutateAsync: uploadImages, isPending: isUploading } =
    useUploadVenueImages();

  // Existing images already stored on the venue.
  const [existingImages, setExistingImages] = useState<string[]>([]);
  // Newly picked local images (to be uploaded on save).
  const [newImages, setNewImages] = useState<string[]>([]);

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      name: '',
      description: '',
      address: '',
      city: '',
      sports: [],
      amenities: [],
      latitude: undefined as unknown as number,
      longitude: undefined as unknown as number,
    },
  });

  // Pre-fill the form once the venue has loaded.
  useEffect(() => {
    if (venue) {
      reset({
        name: venue.name,
        description: venue.description,
        address: venue.address,
        city: venue.city,
        sports: venue.sports ?? [],
        amenities: venue.amenities ?? [],
        latitude: venue.location?.latitude,
        longitude: venue.location?.longitude,
      });
      setExistingImages(venue.images ?? []);
    }
  }, [venue, reset]);

  const handleRemoveExisting = (uri: string) => {
    setExistingImages((imgs) => imgs.filter((i) => i !== uri));
  };

  // -------------------------------------------------------------------------
  // Submit
  // -------------------------------------------------------------------------
  const onSubmit = async (values: FormValues) => {
    try {
      await updateVenue({
        id: venueId,
        data: {
          name: values.name,
          description: values.description,
          address: values.address,
          city: values.city,
          sports: values.sports,
          amenities: values.amenities,
          latitude: values.latitude,
          longitude: values.longitude,
        },
      });

      if (newImages.length > 0) {
        try {
          const formData = new FormData();
          newImages.forEach((uri, idx) => {
            const filename = uri.split('/').pop() ?? `image_${idx}.jpg`;
            const ext = filename.split('.').pop() ?? 'jpg';
            formData.append('files', {
              uri,
              name: filename,
              type: `image/${ext}`,
            } as any);
          });
          await uploadImages({ id: venueId, files: formData });
        } catch {
          // Image upload failure should not block the save.
        }
      }

      Toast.show({
        type: 'success',
        text1: 'Changes saved',
        text2: `${values.name} has been updated.`,
      });
      router.back();
    } catch (err: any) {
      Toast.show({
        type: 'error',
        text1: 'Failed to save changes',
        text2: err?.message ?? 'Please try again.',
      });
    }
  };

  const isSaving = isUpdating || isUploading;

  // -------------------------------------------------------------------------
  // Loading / error
  // -------------------------------------------------------------------------
  if (isLoading) {
    return (
      <SafeAreaView className="flex-1 bg-dark">
        <View className="flex-row items-center px-4 pt-2 pb-4 border-b border-dark-300">
          <TouchableOpacity
            onPress={() => router.back()}
            activeOpacity={0.7}
            className="w-10 h-10 rounded-full bg-card items-center justify-center mr-3"
          >
            <Ionicons name="arrow-back" size={20} color="#FFFFFF" />
          </TouchableOpacity>
          <Text className="text-white text-xl font-bold flex-1">Edit Venue</Text>
        </View>
        <View className="px-4 pt-4">
          <SkeletonLoader variant="card" count={2} />
        </View>
      </SafeAreaView>
    );
  }

  if (isError || !venue) {
    return (
      <SafeAreaView className="flex-1 bg-dark">
        <EmptyState
          icon="alert-circle-outline"
          title="Couldn't load venue"
          subtitle="Something went wrong while fetching this venue. Please try again."
          actionLabel="Retry"
          onAction={() => refetch()}
        />
      </SafeAreaView>
    );
  }

  // -------------------------------------------------------------------------
  // Layout
  // -------------------------------------------------------------------------
  return (
    <SafeAreaView className="flex-1 bg-dark">
      <KeyboardAvoidingView
        className="flex-1"
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={0}
      >
        {/* Header */}
        <View className="flex-row items-center px-4 pt-2 pb-4 border-b border-dark-300">
          <TouchableOpacity
            onPress={() => router.back()}
            activeOpacity={0.7}
            style={{
              width: 40,
              height: 40,
              borderRadius: 20,
              backgroundColor: '#1A1A1A',
              alignItems: 'center',
              justifyContent: 'center',
              marginRight: 12,
            }}
          >
            <Ionicons name="arrow-back" size={20} color="#FFFFFF" />
          </TouchableOpacity>
          <Text className="text-white text-xl font-bold flex-1">Edit Venue</Text>
        </View>

        {/* Form */}
        <ScrollView
          className="flex-1 px-4"
          contentContainerStyle={{ paddingTop: 16, paddingBottom: 32 }}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {/* Basic info */}
          <Text className="text-white text-lg font-bold mb-4">Basic Info</Text>

          <Controller
            control={control}
            name="name"
            render={({ field: { value, onChange, onBlur } }) => (
              <CustomInput
                label="Venue Name"
                placeholder="e.g. Green Park Sports Arena"
                value={value}
                onChangeText={onChange}
                onBlur={onBlur}
                error={errors.name?.message}
              />
            )}
          />

          <View className="mb-4">
            <Text className="text-white text-sm font-medium mb-1.5">
              Description
            </Text>
            <Controller
              control={control}
              name="description"
              render={({ field: { value, onChange, onBlur } }) => (
                <View
                  style={{
                    backgroundColor: '#1A1A1A',
                    borderWidth: 1,
                    borderColor: errors.description ? '#EF4444' : '#374151',
                    borderRadius: 12,
                    paddingHorizontal: 16,
                    paddingVertical: 12,
                  }}
                >
                  <TextInput
                    value={value}
                    onChangeText={onChange}
                    onBlur={onBlur}
                    placeholder="Describe your venue, facilities, and what makes it special..."
                    placeholderTextColor="#6B7280"
                    multiline
                    numberOfLines={4}
                    textAlignVertical="top"
                    style={{ color: '#FFFFFF', fontSize: 15, minHeight: 100 }}
                    selectionColor="#1DB954"
                  />
                </View>
              )}
            />
            {errors.description && (
              <View className="flex-row items-center mt-1.5">
                <Ionicons name="alert-circle-outline" size={14} color="#EF4444" />
                <Text className="text-red-400 text-xs ml-1">
                  {errors.description.message}
                </Text>
              </View>
            )}
          </View>

          <Controller
            control={control}
            name="address"
            render={({ field: { value, onChange, onBlur } }) => (
              <CustomInput
                label="Address"
                placeholder="Full street address of the venue"
                value={value}
                onChangeText={onChange}
                onBlur={onBlur}
                error={errors.address?.message}
                leftIcon={
                  <Ionicons name="location-outline" size={18} color="#6B7280" />
                }
              />
            )}
          />

          {/* City picker */}
          <View className="mb-5">
            <Text className="text-white text-sm font-medium mb-2">City</Text>
            <Controller
              control={control}
              name="city"
              render={({ field: { value, onChange } }) => (
                <ScrollView
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={{ gap: 8, paddingBottom: 4 }}
                >
                  {CITIES.map((city) => {
                    const selected = value === city;
                    return (
                      <TouchableOpacity
                        key={city}
                        onPress={() => onChange(city)}
                        activeOpacity={0.75}
                        style={{
                          paddingHorizontal: 16,
                          paddingVertical: 8,
                          borderRadius: 999,
                          borderWidth: 1,
                          backgroundColor: selected ? '#1DB954' : '#1A1A1A',
                          borderColor: selected ? '#1DB954' : '#374151',
                        }}
                      >
                        <Text
                          style={{
                            color: selected ? '#FFFFFF' : '#6B7280',
                            fontSize: 13,
                            fontWeight: '500',
                          }}
                        >
                          {city}
                        </Text>
                      </TouchableOpacity>
                    );
                  })}
                </ScrollView>
              )}
            />
            {errors.city && (
              <View className="flex-row items-center mt-1.5">
                <Ionicons name="alert-circle-outline" size={14} color="#EF4444" />
                <Text className="text-red-400 text-xs ml-1">
                  {errors.city.message}
                </Text>
              </View>
            )}
          </View>

          {/* Details */}
          <Text className="text-white text-lg font-bold mb-4">Details</Text>

          <View className="mb-5">
            <Controller
              control={control}
              name="sports"
              render={({ field: { value, onChange } }) => (
                <MultiSelect
                  label="Sports Available"
                  options={[...SPORTS]}
                  selected={value}
                  onToggle={(option) => {
                    if (value.includes(option)) {
                      onChange(value.filter((s) => s !== option));
                    } else {
                      onChange([...value, option]);
                    }
                  }}
                />
              )}
            />
            {errors.sports && (
              <View className="flex-row items-center mt-1.5">
                <Ionicons name="alert-circle-outline" size={14} color="#EF4444" />
                <Text className="text-red-400 text-xs ml-1">
                  {errors.sports.message}
                </Text>
              </View>
            )}
          </View>

          <View className="mb-5">
            <Controller
              control={control}
              name="amenities"
              render={({ field: { value, onChange } }) => (
                <MultiSelect
                  label="Amenities"
                  options={[...AMENITIES]}
                  selected={value}
                  onToggle={(option) => {
                    if (value.includes(option)) {
                      onChange(value.filter((a) => a !== option));
                    } else {
                      onChange([...value, option]);
                    }
                  }}
                />
              )}
            />
          </View>

          {/* Existing images */}
          {existingImages.length > 0 && (
            <View className="mb-5">
              <Text className="text-white text-sm font-medium mb-2">
                Current Photos
              </Text>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
                {existingImages.map((uri) => (
                  <View
                    key={uri}
                    style={{ position: 'relative', width: 80, height: 80 }}
                  >
                    <Image
                      source={{ uri }}
                      style={{ width: 80, height: 80, borderRadius: 8 }}
                      contentFit="cover"
                    />
                    <TouchableOpacity
                      onPress={() => handleRemoveExisting(uri)}
                      style={{
                        position: 'absolute',
                        top: 4,
                        right: 4,
                        width: 20,
                        height: 20,
                        borderRadius: 10,
                        backgroundColor: '#EF4444',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <Ionicons name="close" size={12} color="#FFFFFF" />
                    </TouchableOpacity>
                  </View>
                ))}
              </View>
            </View>
          )}

          {/* New images */}
          <ImageUploader
            label="Add New Photos"
            images={newImages}
            onImagesChange={setNewImages}
            maxCount={5}
          />

          {/* Location */}
          <Text className="text-white text-lg font-bold mb-4 mt-6">Location</Text>

          <Controller
            control={control}
            name="latitude"
            render={({ field: { value, onChange, onBlur } }) => (
              <CustomInput
                label="Latitude"
                placeholder="e.g. 19.0760"
                value={value !== undefined && !isNaN(value) ? String(value) : ''}
                onChangeText={(t) => {
                  const n = parseFloat(t);
                  onChange(isNaN(n) ? (undefined as unknown as number) : n);
                }}
                onBlur={onBlur}
                keyboardType="numeric"
                error={errors.latitude?.message}
                leftIcon={
                  <Ionicons name="navigate-outline" size={18} color="#6B7280" />
                }
              />
            )}
          />

          <Controller
            control={control}
            name="longitude"
            render={({ field: { value, onChange, onBlur } }) => (
              <CustomInput
                label="Longitude"
                placeholder="e.g. 72.8777"
                value={value !== undefined && !isNaN(value) ? String(value) : ''}
                onChangeText={(t) => {
                  const n = parseFloat(t);
                  onChange(isNaN(n) ? (undefined as unknown as number) : n);
                }}
                onBlur={onBlur}
                keyboardType="numeric"
                error={errors.longitude?.message}
                leftIcon={
                  <Ionicons name="navigate-outline" size={18} color="#6B7280" />
                }
              />
            )}
          />
        </ScrollView>

        {/* Footer */}
        <View className="px-4 py-4 border-t border-dark-300">
          <CustomButton
            title={isSaving ? 'Saving…' : 'Save Changes'}
            onPress={handleSubmit(onSubmit)}
            variant="primary"
            fullWidth
            loading={isSaving}
            disabled={isSaving}
          />
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}