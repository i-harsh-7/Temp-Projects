import React, { useEffect } from 'react';
import { View, Text } from 'react-native';
import Animated, {
  useSharedValue,
  withTiming,
  useDerivedValue,
  useAnimatedProps,
  Easing,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';

interface StatsCardProps {
  icon: string;
  label: string;
  value: string | number;
  color: string;
  trend?: string;
  trendUp?: boolean;
}

const AnimatedText = Animated.createAnimatedComponent(Text);

const StatsCard: React.FC<StatsCardProps> = ({
  icon,
  label,
  value,
  color,
  trend,
  trendUp,
}) => {
  const isNumeric = typeof value === 'number';
  const animatedValue = useSharedValue(0);

  useEffect(() => {
    if (isNumeric) {
      animatedValue.value = withTiming(value as number, {
        duration: 800,
        easing: Easing.out(Easing.cubic),
      });
    }
  }, [value, isNumeric]);

  const derivedText = useDerivedValue(() => {
    return String(Math.floor(animatedValue.value));
  });

  const animatedProps = useAnimatedProps(() => ({
    text: derivedText.value,
  } as any));

  const iconBg = `${color}33`;
  const gradientEnd = `${color}0D`;

  return (
    <View className="bg-dark-100 rounded-2xl overflow-hidden flex-1">
      <LinearGradient
        colors={['transparent', gradientEnd]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{ flex: 1 }}
      >
        <View className="p-4 flex-1">
          {/* Icon circle */}
          <View
            style={{ backgroundColor: iconBg, width: 40, height: 40, borderRadius: 20 }}
            className="items-center justify-center"
          >
            <Ionicons name={icon as any} size={20} color={color} />
          </View>

          {/* Animated or static value */}
          {isNumeric ? (
            <AnimatedText
              animatedProps={animatedProps}
              className="text-white text-2xl font-bold mt-3"
            >
              {String(Math.floor(value as number))}
            </AnimatedText>
          ) : (
            <Text className="text-white text-2xl font-bold mt-3">{value}</Text>
          )}

          {/* Label */}
          <Text className="text-muted text-xs mt-1">{label}</Text>

          {/* Trend */}
          {trend !== undefined && (
            <Text
              className={`text-xs mt-1 font-medium ${
                trendUp ? 'text-green-400' : 'text-red-400'
              }`}
            >
              {trend}
            </Text>
          )}
        </View>
      </LinearGradient>
    </View>
  );
};

export default StatsCard;
