import React, { useState } from 'react';
import {
  View,
  Text,
  FlatList,
  RefreshControl,
  Pressable,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import Toast from 'react-native-toast-message';

import { api } from '@/services/api';
import { venueService } from '@/services/venueService';
import { QUERY_KEYS } from '@/utils/constants';
import { ApiResponse, PageResponse, Venue } from '@/types';
import CustomButton from '@/components/common/CustomButton';
import EmptyState from '@/components/common/EmptyState';
import SkeletonLoader from '@/components/common/SkeletonLoader';

type FilterStatus = 'ALL' | 'PENDING' | 'APPROVED' | 'INACTIVE';

interface AdminVenue extends Venue {
  ownerName?: string;
}

const FILTER_OPTIONS: { key: FilterStatus; label: string }[] = [
  { key: 'ALL', label: 'All' },
  { key: 'PENDING', label: 'Pending' },
  { key: 'APPROVED', label: 'Approved' },
  { key: 'INACTIVE', label: 'Inactive' },
];

export default function AdminVenues() {
  const queryClient = useQueryClient();
  const [filterStatus, setFilterStatus] = useState<FilterStatus>('ALL');
  const [page, setPage] = useState(0);
  const [refreshing, setRefreshing] = useState(false);

  const { data, isLoading, refetch } = useQuery({
    queryKey: [QUERY_KEYS.ADMIN_VENUES, { filter: filterStatus, page }],
    queryFn: async () => {
      const params: Record<string, unknown> = { page, size: 10 };
      if (filterStatus === 'PENDING') params.approved = false;
      else if (filterStatus === 'APPROVED') params.approved = true;
      else if (filterStatus === 'INACTIVE') params.active = false;
      const res = await api.get<ApiResponse<PageResponse<AdminVenue>>>('/admin/venues', { params });
      return res.data.data;
    },
  });

  const approveMutation = useMutation({
    mutationFn: (id: string) => venueService.approveVenue(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.ADMIN_VENUES] });
      Toast.show({ type: 'success', text1: 'Venue approved!' });
    },
    onError: () => {
      Toast.show({ type: 'error', text1: 'Failed to approve venue' });
    },
  });

  const handleRefresh = async () => {
    setRefreshing(true);
    setPage(0);
    await refetch();
    setRefreshing(false);
  };

  const handleFilterChange = (filter: FilterStatus) => {
    setFilterStatus(filter);
    setPage(0);
  };

  const venues = data?.content ?? [];

  const renderVenue = ({ item }: { item: AdminVenue }) => (
    <View className="bg-card rounded-xl p-4 mb-3">
      <View className="flex-row items-start justify-between">
        {/* Info */}
        <View className="flex-1 mr-3">
          <Text className="text-white font-semibold text-base" numberOfLines={1}>
            {item.name}
          </Text>
          <Text className="text-muted text-xs mt-0.5">{item.city}</Text>
          {item.ownerName ? (
            <Text className="text-muted text-xs mt-0.5">Owner: {item.ownerName}</Text>
          ) : null}
        </View>

        {/* Status badges */}
        <View className="items-end gap-1">
          {/* Approval badge */}
          <View
            className="px-2 py-0.5 rounded-full"
            style={{
              backgroundColor: item.approved ? '#1DB95433' : '#F59E0B33',
            }}
          >
            <Text
              className="text-xs font-medium"
              style={{ color: item.approved ? '#1DB954' : '#F59E0B' }}
            >
              {item.approved ? 'Approved' : 'Pending'}
            </Text>
          </View>

          {/* Active dot */}
          <View className="flex-row items-center gap-1">
            <View
              className="w-2 h-2 rounded-full"
              style={{ backgroundColor: item.active ? '#22C55E' : '#EF4444' }}
            />
            <Text className="text-xs text-muted">
              {item.active ? 'Active' : 'Inactive'}
            </Text>
          </View>
        </View>
      </View>

      {/* Approve button */}
      {!item.approved && (
        <View className="mt-3">
          <CustomButton
            title={approveMutation.isPending ? 'Approving...' : 'Approve Venue'}
            onPress={() => approveMutation.mutate(item.id)}
            size="sm"
            variant="primary"
            disabled={approveMutation.isPending}
          />
        </View>
      )}
    </View>
  );

  return (
    <SafeAreaView className="flex-1 bg-dark">
      {/* Header */}
      <View className="px-4 pt-4 pb-2">
        <Text className="text-white text-2xl font-bold">Venues</Text>
      </View>

      {/* Filter Tabs */}
      <View className="mt-2 mb-2">
        <FlatList
          horizontal
          data={FILTER_OPTIONS}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: 16, gap: 8 }}
          keyExtractor={(item) => item.key}
          renderItem={({ item }) => (
            <Pressable
              onPress={() => handleFilterChange(item.key)}
              className="px-4 py-2 rounded-full"
              style={{
                backgroundColor: filterStatus === item.key ? '#1DB954' : '#1A1A1A',
                borderWidth: 1,
                borderColor: filterStatus === item.key ? '#1DB954' : '#303030',
              }}
            >
              <Text
                className="text-sm font-medium"
                style={{ color: filterStatus === item.key ? '#0F0F0F' : '#6B7280' }}
              >
                {item.label}
              </Text>
            </Pressable>
          )}
        />
      </View>

      {/* List */}
      {isLoading && !data ? (
        <View className="px-4 mt-2">
          <SkeletonLoader variant="venue" count={5} />
        </View>
      ) : (
        <FlatList
          data={venues}
          keyExtractor={(item) => item.id}
          renderItem={renderVenue}
          contentContainerStyle={{ paddingHorizontal: 16, paddingTop: 8, paddingBottom: 24 }}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={handleRefresh}
              tintColor="#1DB954"
            />
          }
          ListEmptyComponent={
            <EmptyState
              icon="business-outline"
              title="No venues found"
              subtitle="No venues match the selected filter"
            />
          }
          ListFooterComponent={
            data && !data.last ? (
              <CustomButton
                title="Load More"
                onPress={() => setPage((p) => p + 1)}
                variant="outline"
                size="sm"
                fullWidth
              />
            ) : null
          }
        />
      )}
    </SafeAreaView>
  );
}
