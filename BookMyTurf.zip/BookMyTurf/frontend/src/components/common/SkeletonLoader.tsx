import React, { useEffect } from 'react';
import { View, Dimensions } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
  interpolate,
  Easing,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

interface SkeletonBlockProps {
  width?: number | string;
  height?: number;
  borderRadius?: number;
  style?: object;
}

const SkeletonBlock: React.FC<SkeletonBlockProps> = ({
  width = '100%',
  height = 16,
  borderRadius = 8,
  style,
}) => {
  const shimmerTranslate = useSharedValue(-1);

  useEffect(() => {
    shimmerTranslate.value = withRepeat(
      withTiming(1, { duration: 1200, easing: Easing.inOut(Easing.ease) }),
      -1,
      false
    );
  }, [shimmerTranslate]);

  const shimmerStyle = useAnimatedStyle(() => {
    const translateX = interpolate(
      shimmerTranslate.value,
      [-1, 1],
      [-SCREEN_WIDTH, SCREEN_WIDTH]
    );
    return {
      transform: [{ translateX }],
    };
  });

  return (
    <View
      style={[
        {
          width: width as number,
          height,
          borderRadius,
          backgroundColor: '#252525',
          overflow: 'hidden',
        },
        style,
      ]}
    >
      <Animated.View
        style={[{ position: 'absolute', top: 0, bottom: 0, width: '100%' }, shimmerStyle]}
      >
        <LinearGradient
          colors={['transparent', 'rgba(255,255,255,0.05)', 'transparent']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={{ flex: 1 }}
        />
      </Animated.View>
    </View>
  );
};

const CardSkeleton: React.FC = () => (
  <View className="bg-card rounded-2xl overflow-hidden mb-4">
    <SkeletonBlock width="100%" height={180} borderRadius={0} />
    <View className="p-4">
      <SkeletonBlock width="70%" height={18} borderRadius={6} />
      <View className="mt-2">
        <SkeletonBlock width="50%" height={14} borderRadius={6} />
      </View>
      <View className="mt-3 flex-row gap-2">
        <SkeletonBlock width={60} height={24} borderRadius={12} />
        <SkeletonBlock width={60} height={24} borderRadius={12} />
      </View>
      <View className="mt-3 flex-row justify-between items-center">
        <SkeletonBlock width="40%" height={16} borderRadius={6} />
        <SkeletonBlock width="25%" height={16} borderRadius={6} />
      </View>
    </View>
  </View>
);

const ListSkeleton: React.FC = () => (
  <View className="bg-card rounded-xl p-4 mb-3 flex-row items-center">
    <SkeletonBlock width={56} height={56} borderRadius={28} />
    <View className="flex-1 ml-4">
      <SkeletonBlock width="70%" height={16} borderRadius={6} />
      <View className="mt-2">
        <SkeletonBlock width="50%" height={14} borderRadius={6} />
      </View>
      <View className="mt-2">
        <SkeletonBlock width="40%" height={12} borderRadius={6} />
      </View>
    </View>
  </View>
);

const VenueSkeleton: React.FC = () => (
  <View className="bg-card rounded-2xl overflow-hidden mb-4">
    <SkeletonBlock width="100%" height={220} borderRadius={0} />
    <View className="p-4">
      <View className="flex-row justify-between items-start">
        <View className="flex-1 mr-4">
          <SkeletonBlock width="80%" height={20} borderRadius={6} />
          <View className="mt-2">
            <SkeletonBlock width="60%" height={14} borderRadius={6} />
          </View>
        </View>
        <SkeletonBlock width={70} height={32} borderRadius={8} />
      </View>
      <View className="mt-3 flex-row gap-2">
        <SkeletonBlock width={70} height={26} borderRadius={13} />
        <SkeletonBlock width={70} height={26} borderRadius={13} />
        <SkeletonBlock width={70} height={26} borderRadius={13} />
      </View>
      <View className="mt-3">
        <SkeletonBlock width="100%" height={1} borderRadius={0} />
      </View>
      <View className="mt-3 flex-row justify-between">
        <SkeletonBlock width="35%" height={14} borderRadius={6} />
        <SkeletonBlock width="25%" height={14} borderRadius={6} />
      </View>
    </View>
  </View>
);

interface SkeletonLoaderProps {
  variant?: 'card' | 'list' | 'venue';
  count?: number;
}

const SkeletonLoader: React.FC<SkeletonLoaderProps> = ({
  variant = 'card',
  count = 3,
}) => {
  const items = Array.from({ length: count }, (_, i) => i);

  return (
    <View>
      {items.map((i) => {
        if (variant === 'list') return <ListSkeleton key={i} />;
        if (variant === 'venue') return <VenueSkeleton key={i} />;
        return <CardSkeleton key={i} />;
      })}
    </View>
  );
};

export { SkeletonBlock };
export default SkeletonLoader;
