import { z } from 'zod';
import { UserRole } from '@/types';

export const loginSchema = z.object({
  email: z
    .string()
    .min(1, 'Email is required')
    .email('Please enter a valid email address'),
  password: z
    .string()
    .min(6, 'Password must be at least 6 characters'),
});

export const registerSchema = z.object({
  name: z
    .string()
    .min(2, 'Name must be at least 2 characters')
    .max(50, 'Name must be less than 50 characters')
    .regex(/^[a-zA-Z\s]+$/, 'Name can only contain letters and spaces'),
  email: z
    .string()
    .min(1, 'Email is required')
    .email('Please enter a valid email address'),
  password: z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
    .regex(/[0-9]/, 'Password must contain at least one number'),
  phone: z
    .string()
    .regex(/^[6-9]\d{9}$/, 'Please enter a valid 10-digit Indian mobile number'),
  role: z.enum(['CUSTOMER', 'VENUE_OWNER', 'ADMIN'] as [UserRole, ...UserRole[]]),
});

export const createVenueSchema = z.object({
  name: z
    .string()
    .min(3, 'Venue name must be at least 3 characters')
    .max(100, 'Venue name must be less than 100 characters'),
  address: z
    .string()
    .min(10, 'Please enter a complete address')
    .max(200, 'Address must be less than 200 characters'),
  city: z
    .string()
    .min(2, 'City name must be at least 2 characters'),
  latitude: z
    .number({ invalid_type_error: 'Latitude must be a number' })
    .min(-90, 'Latitude must be between -90 and 90')
    .max(90, 'Latitude must be between -90 and 90'),
  longitude: z
    .number({ invalid_type_error: 'Longitude must be a number' })
    .min(-180, 'Longitude must be between -180 and 180')
    .max(180, 'Longitude must be between -180 and 180'),
  description: z
    .string()
    .min(20, 'Description must be at least 20 characters')
    .max(500, 'Description must be less than 500 characters'),
  amenities: z
    .array(z.string())
    .min(1, 'Please select at least one amenity'),
  sports: z
    .array(z.string())
    .min(1, 'Please select at least one sport'),
});

const timeRegex = /^([01]\d|2[0-3]):([0-5]\d)$/;

export const createTurfSchema = z
  .object({
    name: z
      .string()
      .min(3, 'Turf name must be at least 3 characters')
      .max(100, 'Turf name must be less than 100 characters'),
    sport: z.string().min(1, 'Please select a sport'),
    pricePerHour: z
      .number({ invalid_type_error: 'Price must be a number' })
      .positive('Price must be greater than 0')
      .max(50000, 'Price seems too high'),
    openingTime: z
      .string()
      .regex(timeRegex, 'Opening time must be in HH:mm format'),
    closingTime: z
      .string()
      .regex(timeRegex, 'Closing time must be in HH:mm format'),
    amenities: z.array(z.string()).default([]),
  })
  .refine(
    (data) => {
      const [openHour, openMin] = data.openingTime.split(':').map(Number);
      const [closeHour, closeMin] = data.closingTime.split(':').map(Number);
      const openMinutes = openHour * 60 + openMin;
      const closeMinutes = closeHour * 60 + closeMin;
      return closeMinutes > openMinutes;
    },
    {
      message: 'Closing time must be after opening time',
      path: ['closingTime'],
    }
  );

export const bookingSchema = z.object({
  turfId: z.string().min(1, 'Turf is required'),
  venueId: z.string().min(1, 'Venue is required'),
  bookingDate: z
    .string()
    .min(1, 'Booking date is required')
    .regex(/^\d{4}-\d{2}-\d{2}$/, 'Date must be in YYYY-MM-DD format'),
  startTime: z
    .string()
    .min(1, 'Start time is required')
    .regex(timeRegex, 'Start time must be in HH:mm format'),
  endTime: z
    .string()
    .min(1, 'End time is required')
    .regex(timeRegex, 'End time must be in HH:mm format'),
}).refine(
  (data) => {
    const [startHour, startMin] = data.startTime.split(':').map(Number);
    const [endHour, endMin] = data.endTime.split(':').map(Number);
    const startMinutes = startHour * 60 + startMin;
    const endMinutes = endHour * 60 + endMin;
    return endMinutes > startMinutes;
  },
  {
    message: 'End time must be after start time',
    path: ['endTime'],
  }
);

export const forgotPasswordSchema = z.object({
  email: z
    .string()
    .min(1, 'Email is required')
    .email('Please enter a valid email address'),
});

export const resetPasswordSchema = z
  .object({
    password: z
      .string()
      .min(8, 'Password must be at least 8 characters')
      .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
      .regex(/[0-9]/, 'Password must contain at least one number'),
    confirmPassword: z.string().min(1, 'Please confirm your password'),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: 'Passwords do not match',
    path: ['confirmPassword'],
  });

export type LoginFormData = z.infer<typeof loginSchema>;
export type RegisterFormData = z.infer<typeof registerSchema>;
export type CreateVenueFormData = z.infer<typeof createVenueSchema>;
export type CreateTurfFormData = z.infer<typeof createTurfSchema>;
export type BookingFormData = z.infer<typeof bookingSchema>;
export type ForgotPasswordFormData = z.infer<typeof forgotPasswordSchema>;
export type ResetPasswordFormData = z.infer<typeof resetPasswordSchema>;
