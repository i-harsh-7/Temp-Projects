import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { turfService } from '@/services/turfService';
import { CreateTurfRequest } from '@/types';
import { QUERY_KEYS } from '@/utils/constants';

export const useTurfsByVenue = (venueId: string) => {
  return useQuery({
    queryKey: [QUERY_KEYS.TURFS, venueId],
    queryFn: () => turfService.getTurfsByVenue(venueId),
    enabled: !!venueId,
    staleTime: 5 * 60 * 1000,
    select: (data) => data.data,
  });
};

export const useTurfById = (id: string) => {
  return useQuery({
    queryKey: [QUERY_KEYS.TURF, id],
    queryFn: () => turfService.getTurfById(id),
    enabled: !!id,
    staleTime: 5 * 60 * 1000,
    select: (data) => data.data,
  });
};

export const useAvailableSlots = (turfId: string, date: string) => {
  return useQuery({
    queryKey: [QUERY_KEYS.SLOTS, turfId, date],
    queryFn: () => turfService.getAvailableSlots(turfId, date),
    enabled: !!turfId && !!date,
    staleTime: 60 * 1000, // 1 minute — slot availability changes frequently
    select: (data) => data.data,
  });
};

export const useCreateTurf = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: CreateTurfRequest) => turfService.createTurf(data),
    onSuccess: (_, data) => {
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEYS.TURFS, data.venueId],
      });
    },
  });
};

export const useUpdateTurf = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      data,
    }: {
      id: string;
      data: Partial<CreateTurfRequest>;
    }) => turfService.updateTurf(id, data),
    onSuccess: (response) => {
      const turf = response.data;
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.TURF, turf.id] });
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEYS.TURFS, turf.venueId],
      });
    },
  });
};

export const useDeleteTurf = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, venueId }: { id: string; venueId: string }) =>
      turfService.deleteTurf(id),
    onSuccess: (_, { venueId }) => {
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.TURFS, venueId] });
    },
  });
};

export const useToggleTurfActive = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => turfService.toggleTurfActive(id),
    onSuccess: (response) => {
      const turf = response.data;
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.TURF, turf.id] });
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEYS.TURFS, turf.venueId],
      });
    },
  });
};
