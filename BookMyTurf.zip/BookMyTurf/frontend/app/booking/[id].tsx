import React, { useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import Toast from 'react-native-toast-message';

import { useBookingById, useCancelBooking } from '@/hooks/useBookings';
import { BookingStatus } from '@/types';
import {
  formatCurrency,
  formatDate,
  formatTime,
  getBookingStatusColor,
} from '@/utils/helpers';
import StatusBadge from '@/components/common/StatusBadge';
import SkeletonLoader from '@/components/common/SkeletonLoader';
import EmptyState from '@/components/common/EmptyState';
import ConfirmDialog from '@/components/common/ConfirmDialog';
import CustomButton from '@/components/common/CustomButton';

// ---------------------------------------------------------------------------
// Status timeline
// ---------------------------------------------------------------------------
const TIMELINE_STEPS: { key: BookingStatus; label: string; description: string }[] = [
  { key: 'PENDING', label: 'Pending', description: 'Booking created, awaiting confirmation' },
  { key: 'CONFIRMED', label: 'Confirmed', description: 'Your slot is reserved' },
];

interface TimelineProps {
  status: BookingStatus;
}

const StatusTimeline: React.FC<TimelineProps> = ({ status }) => {
  // Cancelled bookings show a dedicated single-step timeline.
  if (status === 'CANCELLED') {
    return (
      <View>
        <TimelineRow
          color={getBookingStatusColor('CANCELLED')}
          label="Cancelled"
          description="This booking has been cancelled"
          active
          last
          icon="close"
        />
      </View>
    );
  }

  const currentIndex = TIMELINE_STEPS.findIndex((s) => s.key === status);

  return (
    <View>
      {TIMELINE_STEPS.map((step, index) => {
        const reached = index <= currentIndex;
        const isCurrent = index === currentIndex;
        const color = reached ? getBookingStatusColor(step.key) : '#374151';
        return (
          <TimelineRow
            key={step.key}
            color={color}
            label={step.label}
            description={step.description}
            active={reached}
            current={isCurrent}
            last={index === TIMELINE_STEPS.length - 1}
            icon={reached ? 'checkmark' : undefined}
          />
        );
      })}
    </View>
  );
};

interface TimelineRowProps {
  color: string;
  label: string;
  description: string;
  active: boolean;
  current?: boolean;
  last?: boolean;
  icon?: React.ComponentProps<typeof Ionicons>['name'];
}

const TimelineRow: React.FC<TimelineRowProps> = ({
  color,
  label,
  description,
  active,
  current,
  last,
  icon,
}) => (
  <View className="flex-row">
    {/* Marker + connector */}
    <View className="items-center" style={{ width: 28 }}>
      <View
        style={{
          width: 24,
          height: 24,
          borderRadius: 12,
          backgroundColor: active ? color : '#1A1A1A',
          borderWidth: 2,
          borderColor: active ? color : '#374151',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        {icon ? <Ionicons name={icon} size={13} color="#FFFFFF" /> : null}
      </View>
      {!last && (
        <View
          style={{
            width: 2,
            flex: 1,
            minHeight: 28,
            backgroundColor: active ? color : '#374151',
          }}
        />
      )}
    </View>

    {/* Label */}
    <View className="flex-1 ml-3 pb-5">
      <Text
        className="text-sm font-semibold"
        style={{ color: active ? '#FFFFFF' : '#6B7280' }}
      >
        {label}
        {current ? '  •  Current' : ''}
      </Text>
      <Text className="text-muted text-xs mt-0.5">{description}</Text>
    </View>
  </View>
);

// ---------------------------------------------------------------------------
// Screen
// ---------------------------------------------------------------------------
export default function BookingDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();

  const { data: booking, isLoading, isError, refetch } = useBookingById(id ?? '');
  const { mutateAsync: cancelBooking, isPending: isCancelling } = useCancelBooking();

  const [showCancel, setShowCancel] = useState(false);

  const handleCancel = async () => {
    if (!booking) return;
    try {
      await cancelBooking(booking.id);
      Toast.show({
        type: 'success',
        text1: 'Booking cancelled',
        text2: `${booking.bookingNumber} has been cancelled.`,
      });
      setShowCancel(false);
    } catch (err) {
      Toast.show({
        type: 'error',
        text1: 'Cancellation failed',
        text2: err instanceof Error ? err.message : 'Please try again.',
      });
      setShowCancel(false);
    }
  };

  return (
    <SafeAreaView className="flex-1 bg-dark" edges={['top', 'bottom']}>
      {/* Header */}
      <View className="flex-row items-center px-4 pt-2 pb-4 border-b border-dark-300">
        <TouchableOpacity
          onPress={() => router.back()}
          activeOpacity={0.7}
          className="w-10 h-10 rounded-full bg-card items-center justify-center mr-3"
        >
          <Ionicons name="arrow-back" size={20} color="#FFFFFF" />
        </TouchableOpacity>
        <Text className="text-white text-xl font-bold flex-1">Booking Details</Text>
      </View>

      {isLoading ? (
        <View className="px-4 pt-4">
          <SkeletonLoader variant="list" count={1} />
          <View className="mt-2">
            <SkeletonLoader variant="card" count={1} />
          </View>
        </View>
      ) : isError || !booking ? (
        <EmptyState
          icon="alert-circle-outline"
          title="Couldn't load booking"
          subtitle="Something went wrong while fetching this booking. Please try again."
          actionLabel="Retry"
          onAction={() => refetch()}
        />
      ) : (
        <>
          <ScrollView
            className="flex-1 px-4"
            contentContainerStyle={{ paddingTop: 16, paddingBottom: 32 }}
            showsVerticalScrollIndicator={false}
          >
            {/* Booking number + status */}
            <View className="bg-card rounded-2xl p-5 mb-4 border border-dark-300">
              <View className="flex-row items-start justify-between">
                <View className="flex-1 mr-3">
                  <Text className="text-muted text-xs uppercase tracking-wide">
                    Booking Number
                  </Text>
                  <Text className="text-white text-lg font-bold mt-1">
                    {booking.bookingNumber}
                  </Text>
                </View>
                <StatusBadge status={booking.bookingStatus} type="booking" />
              </View>
            </View>

            {/* Venue & turf */}
            <View className="bg-card rounded-2xl p-5 mb-4 border border-dark-300">
              <DetailRow icon="location-outline" label="Venue" value={booking.venueName} />
              <DetailRow icon="football-outline" label="Turf" value={booking.turfName} />
              <DetailRow
                icon="calendar-outline"
                label="Date"
                value={formatDate(booking.bookingDate)}
              />
              <DetailRow
                icon="time-outline"
                label="Time"
                value={`${formatTime(booking.startTime)} – ${formatTime(booking.endTime)}`}
              />
            </View>

            {/* Status timeline */}
            <View className="bg-card rounded-2xl p-5 mb-4 border border-dark-300">
              <Text className="text-white text-base font-bold mb-4">Status</Text>
              <StatusTimeline status={booking.bookingStatus} />
            </View>

            {/* Payment */}
            <View className="bg-card rounded-2xl p-5 mb-4 border border-dark-300">
              <Text className="text-white text-base font-bold mb-4">Payment</Text>
              <View className="flex-row items-center justify-between mb-3">
                <Text className="text-muted text-sm">Payment Status</Text>
                <StatusBadge status={booking.paymentStatus} type="payment" size="sm" />
              </View>
              <View className="h-px bg-dark-300 mb-3" />
              <View className="flex-row items-center justify-between">
                <Text className="text-white text-base font-bold">Total Amount</Text>
                <Text className="text-primary text-xl font-bold">
                  {formatCurrency(booking.amount)}
                </Text>
              </View>
            </View>
          </ScrollView>

          {/* Cancel button (only when PENDING) */}
          {booking.bookingStatus === 'PENDING' && (
            <View className="px-4 py-4 border-t border-dark-300">
              <CustomButton
                title="Cancel Booking"
                onPress={() => setShowCancel(true)}
                variant="outline"
                fullWidth
                loading={isCancelling}
                disabled={isCancelling}
                icon={<Ionicons name="close-circle-outline" size={18} color="#1DB954" />}
              />
            </View>
          )}
        </>
      )}

      <ConfirmDialog
        visible={showCancel}
        title="Cancel Booking"
        message={`Are you sure you want to cancel booking ${booking?.bookingNumber ?? ''}? This action cannot be undone.`}
        confirmLabel="Yes, Cancel"
        cancelLabel="Keep Booking"
        destructive
        loading={isCancelling}
        onConfirm={handleCancel}
        onCancel={() => setShowCancel(false)}
      />
    </SafeAreaView>
  );
}

function DetailRow({
  icon,
  label,
  value,
}: {
  icon: React.ComponentProps<typeof Ionicons>['name'];
  label: string;
  value: string;
}) {
  return (
    <View className="flex-row items-center justify-between mb-3 last:mb-0">
      <View className="flex-row items-center">
        <View className="w-8 h-8 rounded-lg bg-dark-300 items-center justify-center mr-2.5">
          <Ionicons name={icon} size={15} color="#6B7280" />
        </View>
        <Text className="text-muted text-sm">{label}</Text>
      </View>
      <Text
        className="text-white text-sm font-medium flex-1 text-right ml-4"
        numberOfLines={1}
      >
        {value}
      </Text>
    </View>
  );
}