import { api } from './api';
import {
  ApiResponse,
  PageResponse,
  Venue,
  CreateVenueRequest,
  VenueSearchParams,
} from '@/types';

export const venueService = {
  getVenues: async (
    params?: VenueSearchParams
  ): Promise<ApiResponse<PageResponse<Venue>>> => {
    const response = await api.get<ApiResponse<PageResponse<Venue>>>(
      '/venues',
      { params }
    );
    return response.data;
  },

  getVenueById: async (id: string): Promise<ApiResponse<Venue>> => {
    const response = await api.get<ApiResponse<Venue>>(`/venues/${id}`);
    return response.data;
  },

  searchVenues: async (
    query: string,
    params?: Omit<VenueSearchParams, 'city' | 'sport'>
  ): Promise<ApiResponse<PageResponse<Venue>>> => {
    const response = await api.get<ApiResponse<PageResponse<Venue>>>(
      '/venues/search',
      {
        params: { q: query, ...params },
      }
    );
    return response.data;
  },

  getMyVenues: async (): Promise<ApiResponse<Venue[]>> => {
    const response = await api.get<ApiResponse<Venue[]>>('/venues/my-venues');
    return response.data;
  },

  createVenue: async (data: CreateVenueRequest): Promise<ApiResponse<Venue>> => {
    const response = await api.post<ApiResponse<Venue>>('/venues', data);
    return response.data;
  },

  updateVenue: async (
    id: string,
    data: Partial<CreateVenueRequest>
  ): Promise<ApiResponse<Venue>> => {
    const response = await api.put<ApiResponse<Venue>>(`/venues/${id}`, data);
    return response.data;
  },

  deleteVenue: async (id: string): Promise<ApiResponse<null>> => {
    const response = await api.delete<ApiResponse<null>>(`/venues/${id}`);
    return response.data;
  },

  uploadVenueImages: async (
    id: string,
    files: FormData
  ): Promise<ApiResponse<string[]>> => {
    const response = await api.post<ApiResponse<string[]>>(
      `/venues/${id}/images`,
      files,
      {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      }
    );
    return response.data;
  },

  approveVenue: async (id: string): Promise<ApiResponse<Venue>> => {
    const response = await api.patch<ApiResponse<Venue>>(
      `/venues/${id}/approve`
    );
    return response.data;
  },

  toggleVenueActive: async (id: string): Promise<ApiResponse<Venue>> => {
    const response = await api.patch<ApiResponse<Venue>>(
      `/venues/${id}/toggle-active`
    );
    return response.data;
  },
};
