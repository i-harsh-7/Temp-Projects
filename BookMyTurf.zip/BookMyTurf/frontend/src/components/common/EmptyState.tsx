import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

type IoniconName = React.ComponentProps<typeof Ionicons>['name'];

interface EmptyStateProps {
  icon: IoniconName;
  title: string;
  subtitle?: string;
  actionLabel?: string;
  onAction?: () => void;
}

const EmptyState: React.FC<EmptyStateProps> = ({
  icon,
  title,
  subtitle,
  actionLabel,
  onAction,
}) => {
  return (
    <View className="flex-1 items-center justify-center px-8 py-12">
      <View className="w-24 h-24 rounded-full bg-dark-200 items-center justify-center mb-6">
        <Ionicons name={icon} size={48} color="#1DB954" />
      </View>

      <Text className="text-white text-xl font-bold text-center mb-2">
        {title}
      </Text>

      {subtitle ? (
        <Text className="text-muted text-base text-center leading-6 mb-8 max-w-xs">
          {subtitle}
        </Text>
      ) : (
        <View className="mb-8" />
      )}

      {actionLabel && onAction ? (
        <TouchableOpacity
          onPress={onAction}
          className="bg-primary px-8 py-3.5 rounded-xl"
          activeOpacity={0.8}
        >
          <Text className="text-white font-semibold text-base">
            {actionLabel}
          </Text>
        </TouchableOpacity>
      ) : null}
    </View>
  );
};

export default EmptyState;
