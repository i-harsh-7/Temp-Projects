package com.bookmyturf.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UpdateProfileRequest {

    private String name;

    private String phone;

    private String profileImage;
}
