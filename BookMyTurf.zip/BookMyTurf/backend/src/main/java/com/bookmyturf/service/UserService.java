package com.bookmyturf.service;

import com.bookmyturf.cloudinary.CloudinaryService;
import com.bookmyturf.dto.*;
import com.bookmyturf.entity.User;
import com.bookmyturf.exception.ResourceNotFoundException;
import com.bookmyturf.mapper.UserMapper;
import com.bookmyturf.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserService {

    private final UserRepository userRepository;
    private final UserMapper userMapper;
    private final CloudinaryService cloudinaryService;

    public UserResponse getUserById(String id) {
        log.debug("Fetching user by id: {}", id);
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", id));
        return userMapper.toResponse(user);
    }

    public UserResponse updateProfile(String userId, UpdateProfileRequest req) {
        log.info("Updating profile for user: {}", userId);
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        if (req.getName() != null && !req.getName().isBlank()) {
            user.setName(req.getName());
        }
        if (req.getPhone() != null && !req.getPhone().isBlank()) {
            user.setPhone(req.getPhone());
        }
        if (req.getProfileImage() != null && !req.getProfileImage().isBlank()) {
            user.setProfileImage(req.getProfileImage());
        }

        user = userRepository.save(user);
        log.info("Profile updated for user: {}", userId);
        return userMapper.toResponse(user);
    }

    public UserResponse updateProfileImage(String userId, MultipartFile file) {
        log.info("Updating profile image for user: {}", userId);
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        String imageUrl = cloudinaryService.uploadImage(file, "avatars");
        user.setProfileImage(imageUrl);
        user = userRepository.save(user);

        log.info("Profile image updated for user: {}", userId);
        return userMapper.toResponse(user);
    }

    public PageResponse<UserResponse> getAllUsers(Pageable pageable) {
        log.debug("Fetching all users, page: {}", pageable.getPageNumber());
        Page<User> page = userRepository.findAll(pageable);
        List<UserResponse> content = page.getContent().stream()
                .map(userMapper::toResponse)
                .toList();

        return PageResponse.<UserResponse>builder()
                .content(content)
                .page(page.getNumber())
                .size(page.getSize())
                .totalElements(page.getTotalElements())
                .totalPages(page.getTotalPages())
                .last(page.isLast())
                .build();
    }

    public UserResponse toggleUserActive(String userId) {
        log.info("Toggling active status for user: {}", userId);
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        user.setActive(!user.isActive());
        user = userRepository.save(user);
        log.info("User {} active status toggled to: {}", userId, user.isActive());
        return userMapper.toResponse(user);
    }
}
