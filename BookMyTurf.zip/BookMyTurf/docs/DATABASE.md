# Database Schema

BookMyTurf uses **MongoDB**. Document classes live in `backend/src/main/java/com/bookmyturf/entity/`.
Timestamps (`createdAt`, `updatedAt`) are populated by Spring Data auditing (`@CreatedDate`,
`@LastModifiedDate`). IDs are MongoDB `_id` strings.

Collections: `users`, `venues`, `turfs`, `bookings`, `payments`, `refresh_tokens`.

---

## `users`

| Field | Type | Description | Constraints |
| --- | --- | --- | --- |
| `id` | String | Primary key (`_id`) | auto |
| `name` | String | Full name | — |
| `email` | String | Login email | **unique index** |
| `password` | String | BCrypt hash | never returned by API |
| `phone` | String | Phone number | — |
| `role` | String (enum) | `CUSTOMER` \| `VENUE_OWNER` \| `ADMIN` | — |
| `profileImage` | String | Cloudinary avatar URL | nullable |
| `active` | boolean | Account active flag | default `true` |
| `createdAt` | Instant | Created timestamp | auditing |
| `updatedAt` | Instant | Updated timestamp | auditing |

**Indexes:** unique on `email`.

**Example**
```json
{
  "_id": "665f1a2b3c4d5e6f7a8b9c0d",
  "name": "Asha Player",
  "email": "asha@example.com",
  "password": "$2a$10$...bcrypt...",
  "phone": "9876543210",
  "role": "CUSTOMER",
  "profileImage": "https://res.cloudinary.com/demo/image/upload/avatars/asha.jpg",
  "active": true,
  "createdAt": "2026-06-01T08:00:00Z",
  "updatedAt": "2026-06-01T08:00:00Z"
}
```

---

## `venues`

| Field | Type | Description | Constraints |
| --- | --- | --- | --- |
| `id` | String | Primary key | auto |
| `ownerId` | String | Ref → `users._id` (the VENUE_OWNER) | — |
| `name` | String | Venue name | — |
| `address` | String | Street address | — |
| `city` | String | City | — |
| `location` | GeoJsonPoint | `{ type: "Point", coordinates: [lng, lat] }` | — |
| `description` | String | Description | nullable |
| `images` | String[] | Cloudinary image URLs | — |
| `amenities` | String[] | Amenity labels | — |
| `sports` | String[] | Supported sports | — |
| `approved` | boolean | Admin approval flag | default `false` |
| `active` | boolean | Active flag | default `true` |
| `createdAt` | Instant | Created timestamp | auditing |
| `updatedAt` | Instant | Updated timestamp | auditing |

**Indexes:** none beyond the default `_id`. (Public listings filter on `approved`/`active`; geo queries use
the `location` `GeoJsonPoint`.)

**Example**
```json
{
  "_id": "v123",
  "ownerId": "665f...owner",
  "name": "Green Arena",
  "address": "12 MG Road",
  "city": "Bengaluru",
  "location": { "type": "Point", "coordinates": [77.5946, 12.9716] },
  "description": "Floodlit 5-a-side turf",
  "images": ["https://res.cloudinary.com/demo/image/upload/venues/green1.jpg"],
  "amenities": ["Parking", "Washroom"],
  "sports": ["Football", "Cricket"],
  "approved": true,
  "active": true,
  "createdAt": "2026-06-01T08:00:00Z",
  "updatedAt": "2026-06-01T08:00:00Z"
}
```

---

## `turfs`

| Field | Type | Description | Constraints |
| --- | --- | --- | --- |
| `id` | String | Primary key | auto |
| `venueId` | String | Ref → `venues._id` | — |
| `name` | String | Turf name | — |
| `sport` | String | Sport for this turf | — |
| `pricePerHour` | BigDecimal | Hourly price | > 0 |
| `openingTime` | LocalTime | Daily opening time | — |
| `closingTime` | LocalTime | Daily closing time | — |
| `images` | String[] | Cloudinary image URLs | — |
| `amenities` | String[] | Amenity labels | — |
| `active` | boolean | Active flag | default `true` |
| `createdAt` | Instant | Created timestamp | auditing |
| `updatedAt` | Instant | Updated timestamp | auditing |

**Indexes:** none beyond default `_id` (queried by `venueId`).

**Example**
```json
{
  "_id": "t1",
  "venueId": "v123",
  "name": "Turf A",
  "sport": "Football",
  "pricePerHour": "800",
  "openingTime": "06:00:00",
  "closingTime": "23:00:00",
  "images": ["https://res.cloudinary.com/demo/image/upload/turfs/turfA.jpg"],
  "amenities": ["Bibs", "Lights"],
  "active": true,
  "createdAt": "2026-06-01T08:05:00Z",
  "updatedAt": "2026-06-01T08:05:00Z"
}
```

---

## `bookings`

| Field | Type | Description | Constraints |
| --- | --- | --- | --- |
| `id` | String | Primary key | auto |
| `bookingNumber` | String | Human-friendly reference | generated |
| `userId` | String | Ref → `users._id` | — |
| `venueId` | String | Ref → `venues._id` | — |
| `turfId` | String | Ref → `turfs._id` | — |
| `bookingDate` | LocalDate | Date of play | today-or-future |
| `startTime` | LocalTime | Slot start | within turf hours |
| `endTime` | LocalTime | Slot end | after `startTime` |
| `amount` | BigDecimal | `pricePerHour × hours` | — |
| `paymentStatus` | String (enum) | `PENDING` \| `PAID` \| `FAILED` \| `REFUNDED` | — |
| `bookingStatus` | String (enum) | `PENDING` \| `CONFIRMED` \| `CANCELLED` | — |
| `createdAt` | Instant | Created timestamp | auditing |
| `updatedAt` | Instant | Updated timestamp | auditing |

**Indexes:** none beyond default `_id`. Queried by `userId`, `venueId`, and by
`turfId + bookingDate` (overlap detection via `findOverlappingBookings`).

**Example**
```json
{
  "_id": "b1",
  "bookingNumber": "BMT-7F3A21",
  "userId": "665f...",
  "venueId": "v123",
  "turfId": "t1",
  "bookingDate": "2026-07-01",
  "startTime": "18:00:00",
  "endTime": "19:00:00",
  "amount": "800",
  "paymentStatus": "PAID",
  "bookingStatus": "CONFIRMED",
  "createdAt": "2026-06-28T10:15:30Z",
  "updatedAt": "2026-06-28T10:18:02Z"
}
```

---

## `payments`

| Field | Type | Description | Constraints |
| --- | --- | --- | --- |
| `id` | String | Primary key | auto |
| `bookingId` | String | Ref → `bookings._id` | — |
| `razorpayOrderId` | String | Razorpay order id | looked up on verify/failure |
| `razorpayPaymentId` | String | Razorpay payment id | set after success |
| `razorpaySignature` | String | Razorpay signature | set after success |
| `amount` | BigDecimal | Order amount | — |
| `currency` | String | Currency (always `INR`) | — |
| `status` | String (enum) | `CREATED` \| `PAID` \| `FAILED` | — |
| `createdAt` | Instant | Created timestamp | auditing |

**Indexes:** none beyond default `_id` (queried by `razorpayOrderId`).

**Example**
```json
{
  "_id": "p1",
  "bookingId": "b1",
  "razorpayOrderId": "order_Nxxxxx",
  "razorpayPaymentId": "pay_Nyyyyy",
  "razorpaySignature": "9ef0c1...",
  "amount": "800",
  "currency": "INR",
  "status": "PAID",
  "createdAt": "2026-06-28T10:16:00Z"
}
```

---

## `refresh_tokens`

| Field | Type | Description | Constraints |
| --- | --- | --- | --- |
| `id` | String | Primary key | auto |
| `token` | String | Opaque refresh token value | **unique index** |
| `userId` | String | Ref → `users._id` | — |
| `expiryDate` | Instant | Expiry timestamp | — |
| `revoked` | boolean | Revoked on logout | default `false` |

**Indexes:** unique on `token`. A user's prior refresh tokens are deleted when new ones are issued.

**Example**
```json
{
  "_id": "rt1",
  "token": "f1c2a9...e9a0b3...",
  "userId": "665f...",
  "expiryDate": "2026-07-05T10:15:30Z",
  "revoked": false
}
```

---

## Relationships

- `users (1) → (N) venues` via `venues.ownerId` (owner).
- `venues (1) → (N) turfs` via `turfs.venueId`.
- `users (1) → (N) bookings`, `venues (1) → (N) bookings`, `turfs (1) → (N) bookings`
  (`bookings.userId`, `.venueId`, `.turfId`).
- `bookings (1) → (N) payments` via `payments.bookingId` (typically one CREATED payment per attempt).
- `users (1) → (N) refresh_tokens` via `refresh_tokens.userId`.

All relationships are **id references** (no DB-level foreign keys); the application layer enforces
integrity and ownership.

---

## ER diagram

```mermaid
erDiagram
    USERS ||--o{ VENUES : "owns (ownerId)"
    USERS ||--o{ BOOKINGS : "places (userId)"
    USERS ||--o{ REFRESH_TOKENS : "has (userId)"
    VENUES ||--o{ TURFS : "contains (venueId)"
    VENUES ||--o{ BOOKINGS : "for venue (venueId)"
    TURFS  ||--o{ BOOKINGS : "for turf (turfId)"
    BOOKINGS ||--o{ PAYMENTS : "paid via (bookingId)"

    USERS {
        string id PK
        string email UK
        Role role
        boolean active
    }
    VENUES {
        string id PK
        string ownerId FK
        boolean approved
        boolean active
    }
    TURFS {
        string id PK
        string venueId FK
        BigDecimal pricePerHour
    }
    BOOKINGS {
        string id PK
        string userId FK
        string venueId FK
        string turfId FK
        BookingStatus bookingStatus
        PaymentStatus paymentStatus
    }
    PAYMENTS {
        string id PK
        string bookingId FK
        string razorpayOrderId
        PaymentStatus status
    }
    REFRESH_TOKENS {
        string id PK
        string token UK
        string userId FK
        boolean revoked
    }
```