import React from 'react';
import { View, Text } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import CustomButton from '@/components/common/CustomButton';

export default function NotFoundScreen() {
  return (
    <SafeAreaView className="flex-1 bg-dark">
      <View className="flex-1 items-center justify-center px-6">
        <Ionicons name="compass-outline" size={64} color="#1DB954" />
        <Text className="text-white text-3xl font-bold mt-4">404</Text>
        <Text className="text-white text-xl font-semibold mt-2">
          Page Not Found
        </Text>
        <Text className="text-muted text-sm text-center mt-2 mb-8 max-w-xs">
          The screen you're looking for doesn't exist or has been moved.
        </Text>
        <CustomButton
          title="Go Home"
          onPress={() => router.replace('/(tabs)')}
          fullWidth
        />
      </View>
    </SafeAreaView>
  );
}
