package com.bookmyturf.dto;

import lombok.*;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DashboardResponse {

    private long totalUsers;

    private long totalVenues;

    private long pendingApprovalVenues;

    private long totalBookings;

    private BigDecimal totalRevenue;
}
