package com.bookmyturf.repository;

import com.bookmyturf.entity.Turf;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TurfRepository extends MongoRepository<Turf, String> {

    List<Turf> findByVenueId(String venueId);

    List<Turf> findByVenueIdAndActiveTrue(String venueId);

    List<Turf> findBySportAndActiveTrue(String sport);
}
