package com.bookmyturf.controller;

import com.bookmyturf.dto.*;
import com.bookmyturf.entity.Booking;
import com.bookmyturf.repository.BookingRepository;
import com.bookmyturf.repository.UserRepository;
import com.bookmyturf.repository.VenueRepository;
import com.bookmyturf.service.BookingService;
import com.bookmyturf.service.UserService;
import com.bookmyturf.service.VenueService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
@Slf4j
public class AdminController {

    private final UserService userService;
    private final VenueService venueService;
    private final BookingService bookingService;
    private final UserRepository userRepository;
    private final VenueRepository venueRepository;
    private final BookingRepository bookingRepository;

    @GetMapping("/dashboard")
    public ResponseEntity<ApiResponse<DashboardResponse>> getDashboard() {
        long totalUsers = userRepository.count();
        long totalVenues = venueRepository.count();
        long pendingApprovals = venueRepository.findAll().stream()
                .filter(v -> !v.isApproved() && v.isActive())
                .count();
        long totalBookings = bookingRepository.count();
        BigDecimal totalRevenue = bookingRepository.findAll().stream()
                .filter(b -> b.getBookingStatus() == Booking.BookingStatus.CONFIRMED)
                .map(Booking::getAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        DashboardResponse dashboard = DashboardResponse.builder()
                .totalUsers(totalUsers)
                .totalVenues(totalVenues)
                .pendingApprovalVenues(pendingApprovals)
                .totalBookings(totalBookings)
                .totalRevenue(totalRevenue)
                .build();

        return ResponseEntity.ok(ApiResponse.success("Dashboard data retrieved", dashboard));
    }

    @GetMapping("/users")
    public ResponseEntity<ApiResponse<PageResponse<UserResponse>>> getAllUsers(Pageable pageable) {
        PageResponse<UserResponse> response = userService.getAllUsers(pageable);
        return ResponseEntity.ok(ApiResponse.success("Users retrieved", response));
    }

    @GetMapping("/venues")
    public ResponseEntity<ApiResponse<PageResponse<VenueResponse>>> getAllVenues(Pageable pageable) {
        PageResponse<VenueResponse> response = venueService.getAllVenuesAdmin(pageable);
        return ResponseEntity.ok(ApiResponse.success("Venues retrieved", response));
    }

    @GetMapping("/bookings")
    public ResponseEntity<ApiResponse<PageResponse<BookingResponse>>> getAllBookings(Pageable pageable) {
        PageResponse<BookingResponse> response = bookingService.getAllBookingsAdmin(pageable);
        return ResponseEntity.ok(ApiResponse.success("Bookings retrieved", response));
    }
}
