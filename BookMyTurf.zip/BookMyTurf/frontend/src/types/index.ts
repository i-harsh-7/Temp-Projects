export type UserRole = 'CUSTOMER' | 'VENUE_OWNER' | 'ADMIN';
export type PaymentStatus = 'PENDING' | 'PAID' | 'FAILED' | 'REFUNDED';
export type BookingStatus = 'PENDING' | 'CONFIRMED' | 'CANCELLED';
export type PaymentStatusEnum = 'CREATED' | 'PAID' | 'FAILED';

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  profileImage?: string;
}

export interface VenueLocation {
  latitude: number;
  longitude: number;
}

export interface Venue {
  id: string;
  ownerId: string;
  name: string;
  address: string;
  city: string;
  location: VenueLocation;
  description: string;
  images: string[];
  amenities: string[];
  sports: string[];
  approved: boolean;
  active: boolean;
  turfCount: number;
  createdAt: string;
}

export interface Turf {
  id: string;
  venueId: string;
  name: string;
  sport: string;
  pricePerHour: number;
  openingTime: string;
  closingTime: string;
  images: string[];
  amenities: string[];
  active: boolean;
}

export interface Booking {
  id: string;
  bookingNumber: string;
  userId: string;
  venueId: string;
  turfId: string;
  bookingDate: string;
  startTime: string;
  endTime: string;
  amount: number;
  paymentStatus: PaymentStatus;
  bookingStatus: BookingStatus;
  venueName: string;
  turfName: string;
  createdAt: string;
}

export interface Payment {
  id: string;
  bookingId: string;
  razorpayOrderId: string;
  razorpayPaymentId: string;
  amount: number;
  status: PaymentStatusEnum;
}

export interface TimeSlot {
  startTime: string;
  endTime: string;
  available: boolean;
  price: number;
}

export interface SlotAvailability {
  turfId: string;
  date: string;
  availableSlots: TimeSlot[];
}

export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
  timestamp: string;
}

export interface PageResponse<T> {
  content: T[];
  page: number;
  size: number;
  totalElements: number;
  totalPages: number;
  last: boolean;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
}

export interface AuthResponse {
  user: User;
  accessToken: string;
  refreshToken: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  name: string;
  email: string;
  password: string;
  phone: string;
  role: UserRole;
}

export interface CreateVenueRequest {
  name: string;
  address: string;
  city: string;
  latitude: number;
  longitude: number;
  description: string;
  amenities: string[];
  sports: string[];
}

export interface CreateTurfRequest {
  venueId: string;
  name: string;
  sport: string;
  pricePerHour: number;
  openingTime: string;
  closingTime: string;
  amenities: string[];
}

export interface CreateBookingRequest {
  turfId: string;
  venueId: string;
  bookingDate: string;
  startTime: string;
  endTime: string;
}

export interface CreateOrderRequest {
  bookingId: string;
}

export interface VerifyPaymentRequest {
  razorpayOrderId: string;
  razorpayPaymentId: string;
  razorpaySignature: string;
  bookingId: string;
}

export interface VenueSearchParams {
  city?: string;
  sport?: string;
  minPrice?: number;
  maxPrice?: number;
  sortBy?: string;
  page?: number;
  size?: number;
}
