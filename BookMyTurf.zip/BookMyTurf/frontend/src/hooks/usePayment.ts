import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { paymentService } from '@/services/paymentService';
import { VerifyPaymentRequest } from '@/types';
import { QUERY_KEYS } from '@/utils/constants';

export const useCreateOrder = () => {
  return useMutation({
    mutationFn: (bookingId: string) => paymentService.createOrder(bookingId),
  });
};

export const useVerifyPayment = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: VerifyPaymentRequest) =>
      paymentService.verifyPayment(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.MY_BOOKINGS] });
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.BOOKING] });
    },
  });
};

export const usePaymentById = (id: string) => {
  return useQuery({
    queryKey: [QUERY_KEYS.PAYMENT, id],
    queryFn: () => paymentService.getPaymentById(id),
    enabled: !!id,
    staleTime: 5 * 60 * 1000,
    select: (data) => data.data,
  });
};

export const usePaymentByBookingId = (bookingId: string) => {
  return useQuery({
    queryKey: [QUERY_KEYS.PAYMENT, 'booking', bookingId],
    queryFn: () => paymentService.getPaymentByBookingId(bookingId),
    enabled: !!bookingId,
    staleTime: 5 * 60 * 1000,
    select: (data) => data.data,
  });
};

export const useInitiateRefund = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (paymentId: string) =>
      paymentService.initiateRefund(paymentId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.PAYMENT] });
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.MY_BOOKINGS] });
    },
  });
};
