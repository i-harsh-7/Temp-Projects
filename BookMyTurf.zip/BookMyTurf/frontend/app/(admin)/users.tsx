import React, { useState } from 'react';
import {
  View,
  Text,
  FlatList,
  Switch,
  RefreshControl,
  Pressable,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation, useQueryClient, keepPreviousData } from '@tanstack/react-query';
import Toast from 'react-native-toast-message';

import { api } from '@/services/api';
import { QUERY_KEYS } from '@/utils/constants';
import { getInitials } from '@/utils/helpers';
import { ApiResponse, PageResponse, User } from '@/types';
import CustomButton from '@/components/common/CustomButton';
import CustomInput from '@/components/common/CustomInput';
import EmptyState from '@/components/common/EmptyState';
import SkeletonLoader from '@/components/common/SkeletonLoader';

type RoleFilter = 'ALL' | 'CUSTOMER' | 'VENUE_OWNER' | 'ADMIN';

const ROLE_COLORS: Record<string, string> = {
  CUSTOMER: '#3B82F6',
  VENUE_OWNER: '#1DB954',
  ADMIN: '#F59E0B',
};

const ROLE_LABELS: Record<string, string> = {
  ALL: 'All',
  CUSTOMER: 'Customer',
  VENUE_OWNER: 'Owner',
  ADMIN: 'Admin',
};

const ROLE_FILTERS: RoleFilter[] = ['ALL', 'CUSTOMER', 'VENUE_OWNER', 'ADMIN'];

interface ExtendedUser extends User {
  active?: boolean;
}

export default function AdminUsers() {
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<RoleFilter>('ALL');
  const [page, setPage] = useState(0);
  const [refreshing, setRefreshing] = useState(false);

  const { data, isLoading, refetch } = useQuery({
    queryKey: [QUERY_KEYS.ADMIN_USERS, { search: searchQuery, role: roleFilter, page }],
    queryFn: async () => {
      const res = await api.get<ApiResponse<PageResponse<ExtendedUser>>>('/admin/users', {
        params: {
          page,
          size: 10,
          search: searchQuery || undefined,
          role: roleFilter === 'ALL' ? undefined : roleFilter,
        },
      });
      return res.data.data;
    },
    placeholderData: keepPreviousData,
  });

  const toggleUserMutation = useMutation({
    mutationFn: (userId: string) => api.patch(`/admin/users/${userId}/toggle-active`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.ADMIN_USERS] });
      Toast.show({ type: 'success', text1: 'User status updated' });
    },
    onError: () => {
      Toast.show({ type: 'error', text1: 'Failed to update user status' });
    },
  });

  const handleRefresh = async () => {
    setRefreshing(true);
    setPage(0);
    await refetch();
    setRefreshing(false);
  };

  const handleSearchChange = (text: string) => {
    setSearchQuery(text);
    setPage(0);
  };

  const handleRoleFilter = (role: RoleFilter) => {
    setRoleFilter(role);
    setPage(0);
  };

  const users = data?.content ?? [];

  const renderUser = ({ item }: { item: ExtendedUser }) => {
    const roleColor = ROLE_COLORS[item.role] ?? '#6B7280';
    const isActive = item.active !== false;

    return (
      <View className="bg-card rounded-xl p-4 mb-3 flex-row items-center">
        {/* Avatar */}
        <View
          className="w-11 h-11 rounded-full items-center justify-center mr-3"
          style={{ backgroundColor: roleColor + '33' }}
        >
          <Text className="font-bold text-sm" style={{ color: roleColor }}>
            {getInitials(item.name)}
          </Text>
        </View>

        {/* Info */}
        <View className="flex-1 mr-2">
          <Text className="text-white font-semibold text-sm" numberOfLines={1}>
            {item.name}
          </Text>
          <Text className="text-muted text-xs mt-0.5" numberOfLines={1}>
            {item.email}
          </Text>
          {/* Role Badge */}
          <View className="flex-row mt-1">
            <View
              className="px-2 py-0.5 rounded-full"
              style={{ backgroundColor: roleColor + '26' }}
            >
              <Text className="text-xs font-medium" style={{ color: roleColor }}>
                {ROLE_LABELS[item.role] ?? item.role}
              </Text>
            </View>
          </View>
        </View>

        {/* Toggle */}
        <View className="items-center">
          <Switch
            value={isActive}
            onValueChange={() => toggleUserMutation.mutate(item.id)}
            trackColor={{ false: '#303030', true: '#1DB95440' }}
            thumbColor={isActive ? '#1DB954' : '#6B7280'}
            disabled={toggleUserMutation.isPending}
          />
          <Text className="text-xs mt-1" style={{ color: isActive ? '#1DB954' : '#6B7280' }}>
            {isActive ? 'Active' : 'Inactive'}
          </Text>
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView className="flex-1 bg-dark">
      {/* Header */}
      <View className="px-4 pt-4 pb-2">
        <Text className="text-white text-2xl font-bold">Users</Text>
      </View>

      {/* Search */}
      <View className="px-4 mt-2">
        <CustomInput
          placeholder="Search users..."
          value={searchQuery}
          onChangeText={handleSearchChange}
          leftIcon={<Ionicons name="search-outline" size={18} color="#6B7280" />}
          containerClassName="mb-0"
        />
      </View>

      {/* Role Filter Tabs */}
      <View className="mt-3 mb-2">
        <FlatList
          horizontal
          data={ROLE_FILTERS}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: 16, gap: 8 }}
          keyExtractor={(item) => item}
          renderItem={({ item }) => (
            <Pressable
              onPress={() => handleRoleFilter(item)}
              className="px-4 py-2 rounded-full"
              style={{
                backgroundColor: roleFilter === item ? '#1DB954' : '#1A1A1A',
                borderWidth: 1,
                borderColor: roleFilter === item ? '#1DB954' : '#303030',
              }}
            >
              <Text
                className="text-sm font-medium"
                style={{ color: roleFilter === item ? '#0F0F0F' : '#6B7280' }}
              >
                {ROLE_LABELS[item]}
              </Text>
            </Pressable>
          )}
        />
      </View>

      {/* List */}
      {isLoading && !data ? (
        <View className="px-4 mt-2">
          <SkeletonLoader variant="list" count={6} />
        </View>
      ) : (
        <FlatList
          data={users}
          keyExtractor={(item) => item.id}
          renderItem={renderUser}
          contentContainerStyle={{ paddingHorizontal: 16, paddingTop: 8, paddingBottom: 24 }}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={handleRefresh}
              tintColor="#1DB954"
            />
          }
          ListEmptyComponent={
            <EmptyState
              icon="people-outline"
              title="No users found"
              subtitle={
                searchQuery
                  ? `No results for "${searchQuery}"`
                  : 'No users match the selected filter'
              }
            />
          }
          ListFooterComponent={
            data && !data.last ? (
              <CustomButton
                title="Load More"
                onPress={() => setPage((p) => p + 1)}
                variant="outline"
                size="sm"
                fullWidth
              />
            ) : null
          }
        />
      )}
    </SafeAreaView>
  );
}
