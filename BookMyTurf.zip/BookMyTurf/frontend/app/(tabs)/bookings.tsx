import React from 'react';
import { View, Text } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function BookingsScreen() {
  return (
    <SafeAreaView className="flex-1 bg-dark">
      <View className="flex-1 items-center justify-center">
        <Text className="text-white text-xl font-semibold">My Bookings</Text>
        <Text className="text-muted text-sm mt-2">Coming soon</Text>
      </View>
    </SafeAreaView>
  );
}
