package com.bookmyturf.mapper;

import com.bookmyturf.dto.CreateTurfRequest;
import com.bookmyturf.dto.TurfResponse;
import com.bookmyturf.dto.UpdateTurfRequest;
import com.bookmyturf.entity.Turf;
import org.mapstruct.BeanMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValuePropertyMappingStrategy;

@Mapper(componentModel = "spring")
public interface TurfMapper {

    TurfResponse toResponse(Turf turf);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "images", ignore = true)
    @Mapping(target = "active", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    Turf toTurf(CreateTurfRequest request);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "venueId", ignore = true)
    @Mapping(target = "images", ignore = true)
    @Mapping(target = "active", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    void updateTurf(UpdateTurfRequest request, @MappingTarget Turf turf);
}
