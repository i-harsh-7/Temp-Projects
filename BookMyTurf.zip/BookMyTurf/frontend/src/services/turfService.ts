import { api } from './api';
import {
  ApiResponse,
  Turf,
  CreateTurfRequest,
  SlotAvailability,
} from '@/types';

export const turfService = {
  getTurfsByVenue: async (venueId: string): Promise<ApiResponse<Turf[]>> => {
    const response = await api.get<ApiResponse<Turf[]>>(
      `/venues/${venueId}/turfs`
    );
    return response.data;
  },

  getTurfById: async (id: string): Promise<ApiResponse<Turf>> => {
    const response = await api.get<ApiResponse<Turf>>(`/turfs/${id}`);
    return response.data;
  },

  getAvailableSlots: async (
    turfId: string,
    date: string
  ): Promise<ApiResponse<SlotAvailability>> => {
    const response = await api.get<ApiResponse<SlotAvailability>>(
      `/turfs/${turfId}/slots`,
      {
        params: { date },
      }
    );
    return response.data;
  },

  createTurf: async (data: CreateTurfRequest): Promise<ApiResponse<Turf>> => {
    const response = await api.post<ApiResponse<Turf>>(
      `/venues/${data.venueId}/turfs`,
      data
    );
    return response.data;
  },

  updateTurf: async (
    id: string,
    data: Partial<CreateTurfRequest>
  ): Promise<ApiResponse<Turf>> => {
    const response = await api.put<ApiResponse<Turf>>(`/turfs/${id}`, data);
    return response.data;
  },

  deleteTurf: async (id: string): Promise<ApiResponse<null>> => {
    const response = await api.delete<ApiResponse<null>>(`/turfs/${id}`);
    return response.data;
  },

  uploadTurfImages: async (
    id: string,
    files: FormData
  ): Promise<ApiResponse<string[]>> => {
    const response = await api.post<ApiResponse<string[]>>(
      `/turfs/${id}/images`,
      files,
      {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      }
    );
    return response.data;
  },

  toggleTurfActive: async (id: string): Promise<ApiResponse<Turf>> => {
    const response = await api.patch<ApiResponse<Turf>>(
      `/turfs/${id}/toggle-active`
    );
    return response.data;
  },
};
