import React, { useMemo, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  RefreshControl,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { isToday, isFuture, parseISO } from 'date-fns';

import { useMyVenues } from '@/hooks/useVenues';
import { useVenueBookings } from '@/hooks/useBookings';
import { Booking } from '@/types';
import BookingCard from '@/components/booking/BookingCard';
import SkeletonLoader from '@/components/common/SkeletonLoader';
import EmptyState from '@/components/common/EmptyState';

// ---------------------------------------------------------------------------
// Filters
// ---------------------------------------------------------------------------
type FilterKey = 'all' | 'today' | 'upcoming' | 'completed' | 'cancelled';

const FILTERS: { key: FilterKey; label: string }[] = [
  { key: 'all', label: 'All' },
  { key: 'today', label: 'Today' },
  { key: 'upcoming', label: 'Upcoming' },
  { key: 'completed', label: 'Completed' },
  { key: 'cancelled', label: 'Cancelled' },
];

const EMPTY_COPY: Record<FilterKey, { title: string; subtitle: string }> = {
  all: { title: 'No bookings yet', subtitle: 'Bookings for this venue will appear here.' },
  today: { title: 'No bookings today', subtitle: 'There are no bookings scheduled for today.' },
  upcoming: { title: 'No upcoming bookings', subtitle: 'Future bookings will appear here.' },
  completed: { title: 'No completed bookings', subtitle: 'Confirmed past bookings will appear here.' },
  cancelled: { title: 'No cancelled bookings', subtitle: 'Cancelled bookings will appear here.' },
};

const isPastDate = (date: string): boolean => {
  try {
    const parsed = parseISO(date.includes('T') ? date : `${date}T00:00:00`);
    return !isToday(parsed) && !isFuture(parsed);
  } catch {
    return false;
  }
};

const matchesFilter = (booking: Booking, filter: FilterKey): boolean => {
  switch (filter) {
    case 'all':
      return true;
    case 'today':
      try {
        const parsed = parseISO(
          booking.bookingDate.includes('T')
            ? booking.bookingDate
            : `${booking.bookingDate}T00:00:00`
        );
        return isToday(parsed) && booking.bookingStatus !== 'CANCELLED';
      } catch {
        return false;
      }
    case 'upcoming':
      try {
        const parsed = parseISO(
          booking.bookingDate.includes('T')
            ? booking.bookingDate
            : `${booking.bookingDate}T00:00:00`
        );
        return (
          (isToday(parsed) || isFuture(parsed)) &&
          booking.bookingStatus !== 'CANCELLED'
        );
      } catch {
        return false;
      }
    case 'completed':
      return (
        booking.bookingStatus === 'CONFIRMED' && isPastDate(booking.bookingDate)
      );
    case 'cancelled':
      return booking.bookingStatus === 'CANCELLED';
    default:
      return true;
  }
};

// ---------------------------------------------------------------------------
// Screen
// ---------------------------------------------------------------------------
export default function OwnerBookingsScreen() {
  const { data: venues = [], isLoading: venuesLoading } = useMyVenues();

  const [selectedVenueId, setSelectedVenueId] = useState<string>('');
  const [filter, setFilter] = useState<FilterKey>('all');
  const [refreshing, setRefreshing] = useState(false);

  // Default to the first venue once venues are loaded.
  const activeVenueId = selectedVenueId || venues[0]?.id || '';

  const {
    data: page,
    isLoading: bookingsLoading,
    isError,
    refetch,
  } = useVenueBookings(activeVenueId, { size: 50 });

  const allBookings: Booking[] = page?.content ?? [];

  const filtered = useMemo(
    () => allBookings.filter((b) => matchesFilter(b, filter)),
    [allBookings, filter]
  );

  const onRefresh = async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  };

  // -------------------------------------------------------------------------
  // No venues at all
  // -------------------------------------------------------------------------
  if (!venuesLoading && venues.length === 0) {
    return (
      <SafeAreaView className="flex-1 bg-dark">
        <Header />
        <EmptyState
          icon="business-outline"
          title="No venues yet"
          subtitle="Add a venue first to start receiving bookings."
          actionLabel="Add Venue"
          onAction={() => router.push('/(owner)/venues/create' as any)}
        />
      </SafeAreaView>
    );
  }

  const emptyCopy = EMPTY_COPY[filter];

  return (
    <SafeAreaView className="flex-1 bg-dark">
      <Header />

      {/* Venue selector chips */}
      <View className="pb-2">
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ gap: 8, paddingHorizontal: 16, paddingVertical: 6 }}
        >
          {venuesLoading
            ? null
            : venues.map((venue) => {
                const selected = activeVenueId === venue.id;
                return (
                  <TouchableOpacity
                    key={venue.id}
                    onPress={() => setSelectedVenueId(venue.id)}
                    activeOpacity={0.75}
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      paddingHorizontal: 14,
                      paddingVertical: 8,
                      borderRadius: 999,
                      borderWidth: 1,
                      backgroundColor: selected ? '#1DB954' : '#1A1A1A',
                      borderColor: selected ? '#1DB954' : '#374151',
                      gap: 6,
                    }}
                  >
                    <Ionicons
                      name="business"
                      size={14}
                      color={selected ? '#FFFFFF' : '#6B7280'}
                    />
                    <Text
                      style={{
                        color: selected ? '#FFFFFF' : '#9CA3AF',
                        fontSize: 13,
                        fontWeight: '600',
                      }}
                    >
                      {venue.name}
                    </Text>
                  </TouchableOpacity>
                );
              })}
        </ScrollView>
      </View>

      {/* Filter tabs */}
      <View className="border-b border-dark-300 pb-2">
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ gap: 8, paddingHorizontal: 16, paddingVertical: 4 }}
        >
          {FILTERS.map((f) => {
            const selected = filter === f.key;
            return (
              <TouchableOpacity
                key={f.key}
                onPress={() => setFilter(f.key)}
                activeOpacity={0.75}
                style={{
                  paddingHorizontal: 14,
                  paddingVertical: 7,
                  borderRadius: 999,
                  backgroundColor: selected ? 'rgba(29,185,84,0.15)' : 'transparent',
                  borderWidth: 1,
                  borderColor: selected ? '#1DB954' : '#374151',
                }}
              >
                <Text
                  style={{
                    color: selected ? '#1DB954' : '#9CA3AF',
                    fontSize: 13,
                    fontWeight: '600',
                  }}
                >
                  {f.label}
                </Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>
      </View>

      {/* List */}
      {venuesLoading || bookingsLoading ? (
        <View className="px-4 pt-4">
          <SkeletonLoader variant="list" count={5} />
        </View>
      ) : isError ? (
        <EmptyState
          icon="alert-circle-outline"
          title="Couldn't load bookings"
          subtitle="Something went wrong. Pull down or tap retry to try again."
          actionLabel="Retry"
          onAction={() => refetch()}
        />
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{
            paddingHorizontal: 16,
            paddingTop: 16,
            paddingBottom: 32,
            flexGrow: 1,
          }}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => (
            <BookingCard
              booking={item}
              onPress={() => router.push(`/booking/${item.id}` as any)}
            />
          )}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              tintColor="#1DB954"
              colors={['#1DB954']}
            />
          }
          ListEmptyComponent={
            <EmptyState
              icon="calendar-outline"
              title={emptyCopy.title}
              subtitle={emptyCopy.subtitle}
            />
          }
        />
      )}
    </SafeAreaView>
  );
}

function Header() {
  return (
    <View className="flex-row items-center px-4 pt-2 pb-3">
      <TouchableOpacity
        onPress={() => router.back()}
        activeOpacity={0.7}
        className="w-10 h-10 rounded-full bg-card items-center justify-center mr-3"
      >
        <Ionicons name="arrow-back" size={20} color="#FFFFFF" />
      </TouchableOpacity>
      <Text className="text-white text-xl font-bold flex-1">Venue Bookings</Text>
    </View>
  );
}
