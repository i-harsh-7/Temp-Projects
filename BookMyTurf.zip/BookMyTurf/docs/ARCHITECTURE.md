# Architecture

BookMyTurf is a client–server system: a **React Native (Expo)** mobile app talking over HTTPS/JSON to a
**Spring Boot 3 / Java 21** REST API, backed by **MongoDB** for persistence and **Redis** for distributed
locking, integrating **Razorpay** (payments) and **Cloudinary** (images).

---

## System architecture

```mermaid
flowchart TB
    subgraph Client["React Native App (Expo)"]
        UI["Screens (Expo Router)"]
        Hooks["React Query hooks + Zustand store"]
        Axios["Axios client<br/>(Bearer token + auto-refresh)"]
        UI --> Hooks --> Axios
    end

    Axios -->|HTTPS / JSON<br/>base: /api| API

    subgraph Backend["Spring Boot 3 (Java 21) — context-path /api"]
        direction TB
        Filter["JwtAuthenticationFilter<br/>+ SecurityConfig (RBAC)"]
        Ctrl["Controllers<br/>Auth · Users · Venues · Turfs · Bookings · Payments · Admin"]
        Svc["Services<br/>Auth · User · Venue · Turf · Booking · Payment · Slot"]
        Repo["Repositories<br/>(Spring Data MongoDB)"]
        Lock["RedisLockService"]
        Cloud["CloudinaryService"]
        API --> Filter --> Ctrl --> Svc
        Svc --> Repo
        Svc --> Lock
        Svc --> Cloud
    end

    Repo --> Mongo[("MongoDB<br/>users, venues, turfs,<br/>bookings, payments,<br/>refresh_tokens")]
    Lock --> Redis[("Redis<br/>slot_lock:* keys")]
    Svc -->|orders + signature verify| Razorpay["Razorpay API"]
    Cloud -->|image upload/delete| Cloudinary["Cloudinary"]
```

---

## Clean / layered architecture

The backend separates concerns into clear layers so that business rules stay independent of transport and
persistence details.

| Layer | Package | Responsibility |
| --- | --- | --- |
| **Controller** | `controller` | HTTP mapping (`@RestController`), request validation (`@Valid`), role checks (`@PreAuthorize`), wrapping results in `ApiResponse`. **No business logic.** |
| **Service** | `service`, `redis`, `cloudinary` | All business logic: booking validation, price calc, slot generation, Redis locking, Razorpay order/verify, Cloudinary uploads, JWT issuance. |
| **Repository** | `repository` | Spring Data MongoDB interfaces — data access only. |
| **Entity / DTO** | `entity`, `dto` | Persistence documents vs. API contracts; MapStruct/ModelMapper map between them. |
| **Security** | `security`, `config` | JWT provider, auth filter, user details, security filter chain. |

**Why keep business logic out of controllers?**
- Controllers become thin and trivially testable; logic is unit-tested at the service layer without HTTP.
- The same service can be reused across endpoints (e.g. `PaymentService` calls `BookingService.confirmBooking`).
- Transport concerns (status codes, envelopes) don't leak into domain rules, and persistence can change
  without touching controllers.

---

## Authentication flow

Access tokens are short-lived JWTs (default 15 min); refresh tokens are opaque random strings persisted in
MongoDB (`refresh_tokens`, default 7 days). The mobile client auto-refreshes on `401`.

```mermaid
sequenceDiagram
    participant App as Mobile App
    participant API as AuthController
    participant Auth as AuthService
    participant DB as MongoDB

    App->>API: POST /api/auth/login {email, password}
    API->>Auth: login(req)
    Auth->>DB: findByEmail + verify password (BCrypt)
    Auth->>DB: delete old refresh token, save new RefreshToken
    Auth-->>API: AuthResponse {accessToken (JWT), refreshToken, user}
    API-->>App: 200 ApiResponse(data=AuthResponse)

    Note over App: store tokens (AsyncStorage / Zustand)

    App->>API: GET /api/users/me  (Authorization: Bearer <accessToken>)
    Note over API: JwtAuthenticationFilter validates JWT → sets SecurityContext
    API-->>App: 200 user profile

    Note over App,API: --- access token expires ---
    App->>API: GET /api/bookings/my (expired token)
    API-->>App: 401 Unauthorized
    App->>API: POST /api/auth/refresh {refreshToken}
    API->>Auth: refreshToken(token)
    Auth->>DB: find token → check not revoked / not expired
    Auth-->>API: AuthResponse {new accessToken}
    API-->>App: 200 new accessToken
    App->>API: retry original request with new token
    API-->>App: 200 OK
```

On `POST /api/auth/logout`, the refresh token is marked `revoked = true` so it can no longer be exchanged.

---

## Slot booking sequence (the critical flow)

This is the core anti-double-booking flow. A Redis `SET NX` lock (5-minute TTL) reserves the slot during
the payment window; the lock is released on confirmation, released early on cancellation of an unpaid
booking, or simply **expires** if payment never completes — automatically freeing the slot.

```mermaid
sequenceDiagram
    participant App as Mobile App
    participant BC as BookingController
    participant BS as BookingService
    participant Redis as Redis (slot_lock:*)
    participant DB as MongoDB
    participant PC as PaymentController
    participant PS as PaymentService
    participant RZP as Razorpay

    App->>BC: POST /api/bookings {turfId, venueId, date, start, end}
    BC->>BS: createBooking(req, userId)
    BS->>DB: validate turf/venue + check overlapping bookings
    BS->>Redis: SET NX slot_lock:{turfId}:{date}:{start}-{end} TTL=5m
    alt lock acquired
        Redis-->>BS: OK (true)
        BS->>DB: save Booking (PENDING, PENDING payment)
        BS-->>App: 201 BookingResponse (PENDING)
    else slot already locked
        Redis-->>BS: false
        BS-->>App: 409 "Slot temporarily locked"
    end

    App->>PC: POST /api/payments/create-order {bookingId}
    PC->>PS: createRazorpayOrder(bookingId, userId)
    PS->>RZP: orders.create(amount, INR, receipt)
    RZP-->>PS: razorpayOrderId
    PS->>DB: save Payment (CREATED)
    PS-->>App: 200 {razorpayOrderId, keyId, amount}

    App->>RZP: open Razorpay checkout (pay)

    alt payment success
        RZP-->>App: {orderId, paymentId, signature}
        App->>PC: POST /api/payments/verify {orderId, paymentId, signature, bookingId}
        PC->>PS: verifyAndCompletePayment(req)
        PS->>PS: HMAC-SHA256(orderId|paymentId) == signature ?
        PS->>DB: Payment → PAID
        PS->>BS: confirmBooking(bookingId)
        BS->>DB: Booking → CONFIRMED / PAID
        BS->>Redis: DEL slot_lock (release)
        PS-->>App: 200 BookingResponse (CONFIRMED)
    else payment fails / abandoned
        App->>PC: POST /api/payments/failure {razorpayOrderId}
        PC->>PS: handlePaymentFailure(orderId)
        PS->>DB: Payment → FAILED, Booking.payment → FAILED
        Note over Redis: lock NOT deleted here →<br/>auto-expires after 5-min TTL → slot freed
    end
```

---

## Database ER diagram

References between collections are by stored id strings (`ownerId`, `venueId`, `turfId`, `userId`,
`bookingId`) — there are no DB-level foreign keys (MongoDB).

```mermaid
erDiagram
    USERS ||--o{ VENUES : "owns (ownerId)"
    USERS ||--o{ BOOKINGS : "places (userId)"
    USERS ||--o{ REFRESH_TOKENS : "has (userId)"
    VENUES ||--o{ TURFS : "contains (venueId)"
    VENUES ||--o{ BOOKINGS : "for venue (venueId)"
    TURFS  ||--o{ BOOKINGS : "for turf (turfId)"
    BOOKINGS ||--o{ PAYMENTS : "paid via (bookingId)"

    USERS {
        string id PK
        string name
        string email UK
        string password
        string phone
        Role role "CUSTOMER|VENUE_OWNER|ADMIN"
        string profileImage
        boolean active
        Instant createdAt
        Instant updatedAt
    }
    VENUES {
        string id PK
        string ownerId FK
        string name
        string address
        string city
        GeoJsonPoint location
        string description
        string-list images
        string-list amenities
        string-list sports
        boolean approved
        boolean active
        Instant createdAt
        Instant updatedAt
    }
    TURFS {
        string id PK
        string venueId FK
        string name
        string sport
        BigDecimal pricePerHour
        LocalTime openingTime
        LocalTime closingTime
        string-list images
        string-list amenities
        boolean active
        Instant createdAt
        Instant updatedAt
    }
    BOOKINGS {
        string id PK
        string bookingNumber
        string userId FK
        string venueId FK
        string turfId FK
        LocalDate bookingDate
        LocalTime startTime
        LocalTime endTime
        BigDecimal amount
        PaymentStatus paymentStatus "PENDING|PAID|FAILED|REFUNDED"
        BookingStatus bookingStatus "PENDING|CONFIRMED|CANCELLED"
        Instant createdAt
        Instant updatedAt
    }
    PAYMENTS {
        string id PK
        string bookingId FK
        string razorpayOrderId
        string razorpayPaymentId
        string razorpaySignature
        BigDecimal amount
        string currency
        PaymentStatus status "CREATED|PAID|FAILED"
        Instant createdAt
    }
    REFRESH_TOKENS {
        string id PK
        string token UK
        string userId FK
        Instant expiryDate
        boolean revoked
    }
```

---

## Redis distributed locking

**Problem:** two customers could try to book the same turf, date, and time slot simultaneously. A pure
DB check-then-insert has a race window between "no overlap found" and "save".

**Solution:** `RedisLockService` uses an atomic **`SET key value NX PX 300000`** (set-if-absent with a
5-minute TTL). Only one caller can create the key; the other gets `false` and receives `409 Slot
temporarily locked`.

- **Key format:** `slot_lock:{turfId}:{date}:{startTime}-{endTime}`
  (e.g. `slot_lock:t1:2026-07-01:18:00-19:00`).
- **TTL:** `300000 ms` (5 minutes) — bounds how long an in-progress payment can hold a slot.
- **Acquire:** `redisTemplate.opsForValue().setIfAbsent(key, "locked", Duration.ofMillis(300000))`.
- **Release:** explicit `DEL` on booking confirmation, and on cancellation when the booking was still
  unpaid (`PENDING`). If payment is abandoned, the key simply expires — no manual cleanup needed, and the
  slot becomes bookable again.
- **Belt-and-suspenders:** the service also runs a DB overlap check (`findOverlappingBookings`) before
  acquiring the lock, so confirmed bookings are rejected even after a lock has long expired.

---

## Role-Based Access Control (RBAC)

Three roles defined on `User.Role`: **`CUSTOMER`**, **`VENUE_OWNER`**, **`ADMIN`**.

- **Stateless JWT auth:** `JwtAuthenticationFilter` validates the `Bearer` token on each request and
  populates the `SecurityContext`; sessions are `STATELESS`.
- **Public routes** (no token): `/auth/**`, `/venues/public/**`, `/turfs/public/**`, Swagger, and
  `/actuator/health`. Everything else requires authentication.
- **Method-level security:** `@EnableMethodSecurity(prePostEnabled = true)` enables `@PreAuthorize` on
  controller methods, e.g. `@PreAuthorize("hasRole('VENUE_OWNER')")`, `@PreAuthorize("hasRole('ADMIN')")`.
  `AdminController` applies it at the class level.
- **Ownership checks:** beyond role checks, services verify resource ownership (e.g. a `VENUE_OWNER` may
  only edit/delete their own venues/turfs and view their own venue's bookings; a `CUSTOMER` may only view
  or cancel their own bookings; `ADMIN` may act across all).