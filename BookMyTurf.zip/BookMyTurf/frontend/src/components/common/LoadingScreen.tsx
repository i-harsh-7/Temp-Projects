import React, { useEffect } from 'react';
import { View, Text } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
  Easing,
} from 'react-native-reanimated';

interface LoadingScreenProps {
  message?: string;
}

const LoadingScreen: React.FC<LoadingScreenProps> = ({
  message = 'Loading...',
}) => {
  const rotation = useSharedValue(0);
  const opacity = useSharedValue(0.4);

  useEffect(() => {
    rotation.value = withRepeat(
      withTiming(360, {
        duration: 1000,
        easing: Easing.linear,
      }),
      -1,
      false
    );
    opacity.value = withRepeat(
      withTiming(1, {
        duration: 800,
        easing: Easing.inOut(Easing.ease),
      }),
      -1,
      true
    );
  }, [opacity, rotation]);

  const spinnerStyle = useAnimatedStyle(() => ({
    transform: [{ rotate: `${rotation.value}deg` }],
  }));

  const brandStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
  }));

  return (
    <View className="flex-1 items-center justify-center bg-dark">
      <Animated.Text
        className="text-4xl font-bold text-primary mb-8 tracking-wider"
        style={brandStyle}
      >
        BookMyTurf
      </Animated.Text>

      <Animated.View
        className="w-12 h-12 rounded-full border-4 border-dark-300 border-t-primary"
        style={spinnerStyle}
      />

      {message ? (
        <Text className="text-muted text-sm mt-6">{message}</Text>
      ) : null}
    </View>
  );
};

export default LoadingScreen;
