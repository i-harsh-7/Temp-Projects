import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { format } from 'date-fns';
import { useAvailableSlots } from '@/hooks/useTurfs';
import { useTurfById } from '@/hooks/useTurfs';
import { useVenueById } from '@/hooks/useVenues';
import TimeSlotPicker from '@/components/booking/TimeSlotPicker';
import DateStrip from '@/components/common/DateStrip';
import EmptyState from '@/components/common/EmptyState';
import { TimeSlot } from '@/types';
import { formatCurrency, formatDate, formatTime } from '@/utils/helpers';

export default function SlotSelectionScreen() {
  const { turfId, venueId } = useLocalSearchParams<{
    turfId: string;
    venueId: string;
  }>();

  const today = format(new Date(), 'yyyy-MM-dd');
  const [selectedDate, setSelectedDate] = useState(today);
  const [selectedSlot, setSelectedSlot] = useState<TimeSlot | null>(null);

  const { data: turf } = useTurfById(turfId ?? '');
  const { data: venue } = useVenueById(venueId ?? '');

  const {
    data: slotsData,
    isLoading: slotsLoading,
    refetch: refetchSlots,
    error: slotsError,
  } = useAvailableSlots(turfId ?? '', selectedDate);

  const slots: TimeSlot[] = slotsData?.availableSlots ?? [];

  const handleDateChange = (date: string) => {
    setSelectedDate(date);
    setSelectedSlot(null);
  };

  const handleProceed = () => {
    if (!selectedSlot) return;
    router.push({
      pathname: '/booking/checkout',
      params: {
        turfId: turfId ?? '',
        venueId: venueId ?? '',
        bookingDate: selectedDate,
        startTime: selectedSlot.startTime,
        endTime: selectedSlot.endTime,
        amount: String(selectedSlot.price),
      },
    });
  };

  return (
    <SafeAreaView className="flex-1 bg-dark" edges={['top', 'bottom']}>
      {/* Header */}
      <View className="flex-row items-center px-5 pt-3 pb-4">
        <TouchableOpacity
          onPress={() => router.back()}
          className="w-10 h-10 rounded-full bg-dark-200 items-center justify-center mr-3"
        >
          <Ionicons name="arrow-back" size={20} color="#fff" />
        </TouchableOpacity>
        <View className="flex-1">
          <Text className="text-white text-lg font-bold">Select Slot</Text>
          {turf && (
            <Text className="text-muted text-xs mt-0.5">
              {turf.name} · {venue?.name ?? ''}
            </Text>
          )}
        </View>
      </View>

      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        {/* Date strip */}
        <View className="mb-5">
          <Text className="text-white text-sm font-semibold px-5 mb-3">
            Select Date
          </Text>
          <DateStrip
            selectedDate={selectedDate}
            onSelectDate={handleDateChange}
            numberOfDays={14}
          />
        </View>

        {/* Slot picker */}
        <View className="px-5">
          {slotsLoading ? (
            <View className="items-center py-10">
              <ActivityIndicator size="large" color="#1DB954" />
              <Text className="text-muted text-sm mt-3">Loading slots...</Text>
            </View>
          ) : slotsError ? (
            <View className="items-center py-10">
              <Ionicons name="alert-circle-outline" size={40} color="#EF4444" />
              <Text className="text-white text-base font-semibold mt-3">
                Failed to load slots
              </Text>
              <TouchableOpacity onPress={() => refetchSlots()} className="mt-3">
                <Text className="text-primary text-sm font-medium">Retry</Text>
              </TouchableOpacity>
            </View>
          ) : slots.length === 0 ? (
            <EmptyState
              icon="calendar-outline"
              title="No slots available"
              subtitle={`No slots available on ${formatDate(selectedDate)}`}
              actionLabel="Try another date"
              onAction={() => {}}
            />
          ) : (
            <TimeSlotPicker
              slots={slots}
              selectedSlot={selectedSlot}
              onSelectSlot={setSelectedSlot}
              bookingDate={selectedDate}
            />
          )}
        </View>

        {/* Summary card (when slot selected) */}
        {selectedSlot && (
          <View className="mx-5 mt-6 bg-dark-200 rounded-2xl p-4 border border-primary/30">
            <Text className="text-primary text-sm font-bold mb-3">
              Booking Summary
            </Text>

            <View className="flex-row items-center mb-2">
              <Ionicons name="location-outline" size={15} color="#6B7280" />
              <Text className="text-white text-sm ml-2">{venue?.name ?? '—'}</Text>
            </View>

            <View className="flex-row items-center mb-2">
              <Ionicons name="football-outline" size={15} color="#6B7280" />
              <Text className="text-white text-sm ml-2">{turf?.name ?? '—'}</Text>
            </View>

            <View className="flex-row items-center mb-2">
              <Ionicons name="calendar-outline" size={15} color="#6B7280" />
              <Text className="text-white text-sm ml-2">{formatDate(selectedDate)}</Text>
            </View>

            <View className="flex-row items-center mb-3">
              <Ionicons name="time-outline" size={15} color="#6B7280" />
              <Text className="text-white text-sm ml-2">
                {formatTime(selectedSlot.startTime)} – {formatTime(selectedSlot.endTime)}
              </Text>
            </View>

            <View className="h-px bg-dark-300 mb-3" />

            <View className="flex-row items-center justify-between">
              <Text className="text-muted text-sm">Total Amount</Text>
              <Text className="text-primary text-lg font-bold">
                {formatCurrency(selectedSlot.price)}
              </Text>
            </View>
          </View>
        )}

        <View className="h-28" />
      </ScrollView>

      {/* Proceed button */}
      <View className="absolute bottom-0 left-0 right-0 px-5 pb-6 pt-3 bg-dark border-t border-dark-200">
        <TouchableOpacity
          onPress={handleProceed}
          disabled={!selectedSlot}
          className="py-4 rounded-2xl items-center"
          style={{ backgroundColor: selectedSlot ? '#1DB954' : '#1A1A1A' }}
          activeOpacity={0.85}
        >
          <Text
            className="text-base font-bold"
            style={{ color: selectedSlot ? '#fff' : '#6B7280' }}
          >
            {selectedSlot ? 'Proceed to Checkout' : 'Select a Slot to Continue'}
          </Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}
