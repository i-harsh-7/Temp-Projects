package com.bookmyturf.controller;

import com.bookmyturf.dto.*;
import com.bookmyturf.security.CustomUserDetails;
import com.bookmyturf.service.TurfService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/turfs")
@RequiredArgsConstructor
@Slf4j
public class TurfController {

    private final TurfService turfService;

    @GetMapping("/public/venue/{venueId}")
    public ResponseEntity<ApiResponse<List<TurfResponse>>> getTurfsByVenue(@PathVariable String venueId) {
        List<TurfResponse> response = turfService.getTurfsByVenue(venueId);
        return ResponseEntity.ok(ApiResponse.success("Turfs retrieved", response));
    }

    @GetMapping("/public/{id}")
    public ResponseEntity<ApiResponse<TurfResponse>> getTurfById(@PathVariable String id) {
        TurfResponse response = turfService.getTurfById(id);
        return ResponseEntity.ok(ApiResponse.success("Turf retrieved", response));
    }

    @GetMapping("/public/{id}/slots")
    public ResponseEntity<ApiResponse<SlotAvailabilityResponse>> getAvailableSlots(
            @PathVariable String id,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        SlotAvailabilityResponse response = turfService.getAvailableSlots(id, date);
        return ResponseEntity.ok(ApiResponse.success("Slots retrieved", response));
    }

    @PostMapping("/")
    @PreAuthorize("hasRole('VENUE_OWNER')")
    public ResponseEntity<ApiResponse<TurfResponse>> createTurf(
            @Valid @RequestBody CreateTurfRequest req,
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        TurfResponse response = turfService.createTurf(req, userDetails.getId());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Turf created successfully", response));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('VENUE_OWNER')")
    public ResponseEntity<ApiResponse<TurfResponse>> updateTurf(
            @PathVariable String id,
            @Valid @RequestBody UpdateTurfRequest req,
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        TurfResponse response = turfService.updateTurf(id, req, userDetails.getId());
        return ResponseEntity.ok(ApiResponse.success("Turf updated successfully", response));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('VENUE_OWNER')")
    public ResponseEntity<ApiResponse<Void>> deleteTurf(
            @PathVariable String id,
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        turfService.deleteTurf(id, userDetails.getId());
        return ResponseEntity.ok(ApiResponse.success("Turf deleted successfully"));
    }

    @PostMapping("/{id}/images")
    @PreAuthorize("hasRole('VENUE_OWNER')")
    public ResponseEntity<ApiResponse<TurfResponse>> uploadTurfImages(
            @PathVariable String id,
            @RequestPart("files") List<MultipartFile> files,
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        TurfResponse response = turfService.uploadTurfImages(id, files, userDetails.getId());
        return ResponseEntity.ok(ApiResponse.success("Images uploaded successfully", response));
    }
}
